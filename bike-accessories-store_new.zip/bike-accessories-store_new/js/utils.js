/* utils.js — shared helpers: DOM, formatting, icons, placeholder images, toast, modal, tabs */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const Store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} },
  del(k) { try { localStorage.removeItem(k); } catch (e) {} }
};
const fmt = n => '₹' + Math.round(n).toLocaleString('en-IN');
const pct = (mrp, price) => (mrp > price ? Math.round((1 - price / mrp) * 100) : 0);
const debounce = (fn, ms = 250) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const params = () => Object.fromEntries(new URLSearchParams(location.search));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const emit = (n, d) => document.dispatchEvent(new CustomEvent(n, { detail: d }));

/* Modules register init functions; main.js runs them once every script has loaded. */
const App = { fns: [], init(f) { App.fns.push(f); }, run() { App.fns.forEach(f => { try { f(); } catch (e) { console.error(e); } }); } };

/* ---------- Icons (24px stroke set) ---------- */
const ICONS = {
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  heart: '<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7Z"/>',
  cart: '<circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/>',
  user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>',
  moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
  monitor: '<rect width="20" height="14" x="2" y="3" rx="2"/><path d="M8 21h8M12 17v4"/>',
  star: '<path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>',
  down: '<path d="m6 9 6 6 6-6"/>', right: '<path d="m9 18 6-6-6-6"/>', left: '<path d="m15 18-6-6 6-6"/>', up: '<path d="m18 15-6-6-6 6"/>',
  truck: '<path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M15 18H9"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.62l-3.48-4.35A1 1 0 0 0 17.52 8H14"/><circle cx="17" cy="18" r="2"/><circle cx="7" cy="18" r="2"/>',
  shield: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  refresh: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
  headset: '<path d="M3 14v-2a9 9 0 0 1 18 0v2"/><path d="M21 16v2a3 3 0 0 1-3 3h-4"/><rect x="2" y="13" width="4" height="6" rx="1"/><rect x="18" y="13" width="4" height="6" rx="1"/>',
  check: '<path d="M20 6 9 17l-5-5"/>', plus: '<path d="M5 12h14M12 5v14"/>', minus: '<path d="M5 12h14"/>',
  trash: '<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M10 11v6M14 11v6"/>',
  filter: '<path d="M21 4h-7M10 4H3M21 12h-9M8 12H3M21 20h-5M12 20H3M14 2v4M8 10v4M16 18v4"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
  compare: '<path d="M8 3 4 7l4 4M4 7h16M16 21l4-4-4-4M20 17H4"/>',
  maximize: '<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/>',
  zoom: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3M11 8v6M8 11h6"/>',
  package: '<path d="m7.5 4.27 9 5.15M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/>',
  pin: '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
  card: '<rect width="20" height="14" x="2" y="5" rx="2"/><path d="M2 10h20"/>',
  bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/>',
  dashboard: '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  tag: '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>',
  image: '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.09-3.09a2 2 0 0 0-2.82 0L6 21"/>',
  chart: '<path d="M3 3v18h18"/><path d="M18 17V9M13 17V5M8 17v-3"/>',
  message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
  copy: '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
  mail: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  grid: '<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  arrow: '<path d="M5 12h14M12 5l7 7-7 7"/>',
  home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
  layers: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
  file: '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5z"/><path d="M14 2v6h6"/>',
  help: '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3M12 17h.01"/>',
  rupee: '<path d="M6 3h12M6 8h12M6 13h3c4 0 6-2.5 6-5M9 13l7 8"/>',
  percent: '<path d="M19 5 5 19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
  instagram: '<rect width="20" height="20" x="2" y="2" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17.5 6.5h.01"/>',
  youtube: '<path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/><path d="m10 15 5-3-5-3z"/>',
  facebook: '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
  lock: '<rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  award: '<circle cx="12" cy="8" r="6"/><path d="M15.48 12.89 17 22l-5-3-5 3 1.52-9.11"/>',
  zap: '<path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/>',
  more: '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
  down2: '<path d="M12 5v14M19 12l-7 7-7-7"/>', up2: '<path d="M12 19V5M5 12l7-7 7 7"/>',
  store: '<path d="m2 7 2-4h16l2 4M2 7v2a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0V7M4 12v9h16v-9M9 21v-5h6v5"/>',
  bold: '<path d="M6 4h8a4 4 0 0 1 0 8H6zM6 12h9a4 4 0 0 1 0 8H6z"/>', italic: '<path d="M19 4h-9M14 20H5M15 4 9 20"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  drag: '<circle cx="9" cy="6" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="18" r="1"/><circle cx="15" cy="6" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="18" r="1"/>'
};
function icon(name, size = 20, cls = '') {
  return `<svg class="ic ${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ''}</svg>`;
}

/* ---------- Placeholder product art (replaced by Firebase Storage images later) ---------- */
const GLYPHS = {
  helmet: '<path d="M14 62C14 34 32 16 54 16c22 0 32 20 32 42v10c0 4-3 6-7 6H30c-9 0-16-5-16-12Z"/><path d="M46 42h40v16H42z"/><path d="M14 62h28"/>',
  glove: '<path d="M30 84V52l-6-14a4 4 0 0 1 7-3l6 12V24a4 4 0 0 1 8 0v22V20a4 4 0 0 1 8 0v26V24a4 4 0 0 1 8 0v30l6-8a4 4 0 0 1 6 5L68 70v14Z"/>',
  jacket: '<path d="M36 18 18 30l6 24 10-4v34h32V50l10 4 6-24-18-12-14 12Z"/><path d="M50 30v54"/>',
  pants: '<path d="M30 16h40l4 68H56L50 42l-6 42H26Z"/><path d="M30 26h40"/>',
  boot: '<path d="M34 16h22v34l24 10v22H28V50Z"/><path d="M28 74h52M34 30h22"/>',
  bag: '<rect x="18" y="38" width="64" height="42" rx="6"/><path d="M36 38V28h28v10M18 56h64M40 56v8h20v-8"/>',
  tank: '<path d="M18 74 28 42h44l10 32Z"/><path d="M40 42v-8h20v8M30 58h40"/>',
  roll: '<rect x="14" y="40" width="72" height="30" rx="15"/><path d="M30 40v30M70 40v30M14 55h72"/>',
  pack: '<path d="M30 34c0-14 40-14 40 0v46H30Z"/><rect x="38" y="54" width="24" height="16" rx="3"/><path d="M40 34v-6M60 34v-6"/>',
  phone: '<rect x="34" y="14" width="32" height="56" rx="5"/><path d="M50 70v14M38 84h24M46 22h8"/>',
  light: '<circle cx="50" cy="50" r="15"/><circle cx="50" cy="50" r="6"/><path d="M50 16v8M50 76v8M16 50h8M76 50h8M26 26l6 6M68 68l6 6M74 26l-6 6M32 68l-6 6"/>',
  rain: '<path d="M14 52c0-24 72-24 72 0Z"/><path d="M50 52v22c0 7-10 7-10 0M30 52c0-8 4-14 8-16M70 52c0-8-4-14-8-16"/>',
  cover: '<path d="M12 74c0-22 22-38 40-34l36 22v12Z"/><path d="M30 74v-8M70 74v-14"/>',
  tool: '<path d="M24 78 56 46"/><path d="M62 20a14 14 0 0 0-14 18l-2 2 14 14 2-2a14 14 0 0 0 18-14l-9 9-8-8 9-9a14 14 0 0 0-10-10Z"/>',
  compass: '<circle cx="50" cy="50" r="32"/><path d="m64 36-8 20-20 8 8-20Z"/><path d="M50 18v6M50 76v6M18 50h6M76 50h6"/>'
};
const TINTS = ['#3f4650', '#354a55', '#4a4640', '#3b3f52', '#38504a'];
function tile(glyph, i = 0, wide = false) {
  const g = GLYPHS[glyph] || GLYPHS.bag;
  const rot = [0, -8, 6, 0][i % 4], sc = [1.9, 2.1, 1.7, 2.25][i % 4];
  const W = wide ? 600 : 400, H = 400, tint = TINTS[(Math.floor(i / 4) + glyph.length) % 5];
  const cx = W / 2 - 50 * sc, cy = H / 2 - 50 * sc - 10;
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 ${W} ${H}'><defs><radialGradient id='g' cx='50%' cy='34%' r='85%'><stop offset='0' stop-color='${tint}'/><stop offset='1' stop-color='#14181D'/></radialGradient></defs><rect width='${W}' height='${H}' fill='url(#g)'/><path d='M0 ${H - 80}L${W} ${H - 150}V${H}H0Z' fill='#fff' opacity='.035'/><g transform='translate(${cx} ${cy}) rotate(${rot} ${50 * sc} ${50 * sc}) scale(${sc})' fill='none' stroke='#F1EEE6' stroke-width='${(3.6 / sc).toFixed(2)}' stroke-linecap='round' stroke-linejoin='round'>${g}</g><rect x='${W / 2 - 22}' y='${H - 48}' width='44' height='4' rx='2' fill='#F2A900'/><text x='${W / 2}' y='${H - 22}' text-anchor='middle' font-family='Arial' font-size='11' fill='#8b929c'>sample image</text></svg>`;
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
}
const imgSrc = (p, i = 0) => (p.images && p.images.length) ? (p.images[i] || p.images[0]) : (typeof PHOTOS !== 'undefined' && PHOTOS[p.id]) ? PHOTOS[p.id] : tile(getCat(p.cat).glyph, i + (Number(p.id.slice(1)) % 3) * 4);
const catImg = (c, wide = false) => tile(c.glyph, CATEGORIES.indexOf(c) % 4 + 4 * (CATEGORIES.indexOf(c) % 5), wide);

/* ---------- Small UI builders ---------- */
function stars(r) {
  return `<span class="stars" role="img" aria-label="Rated ${r} out of 5"><span aria-hidden="true">★★★★★</span><span class="stars-fg" aria-hidden="true" style="width:${(r / 5) * 100}%">★★★★★</span></span>`;
}
function skeletonCards(n = 8) {
  return Array.from({ length: n }, () => '<div class="pcard"><div class="pcard-media skeleton"></div><div class="skeleton sk-line"></div><div class="skeleton sk-line short"></div></div>').join('');
}
function emptyState({ ico = 'package', title, text, btn, href }) {
  return `<div class="empty"><div class="empty-art">${icon(ico, 36)}</div><h2>${title}</h2><p>${text}</p>${btn ? `<a class="btn btn-primary" href="${href}">${btn}</a>` : ''}</div>`;
}

/* ---------- Toast ---------- */
function toast(msg, type = 'success') {
  let root = $('#toastRoot');
  if (!root) { root = document.createElement('div'); root.id = 'toastRoot'; root.className = 'toast-root'; root.setAttribute('role', 'status'); root.setAttribute('aria-live', 'polite'); document.body.appendChild(root); }
  const el = document.createElement('div');
  el.className = 'toast toast-' + type;
  el.innerHTML = icon(type === 'error' ? 'x' : type === 'info' ? 'bell' : 'check', 18) + '<span>' + esc(msg) + '</span>';
  root.appendChild(el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, 3200);
}

/* ---------- Accessible modal (focus trap, Esc, backdrop) ---------- */
const Modal = {
  open(html, { label = 'Dialog', cls = '' } = {}) {
    const prev = document.activeElement;
    const back = document.createElement('div');
    back.className = 'modal-backdrop';
    back.innerHTML = `<div class="modal ${cls}" role="dialog" aria-modal="true" aria-label="${esc(label)}"><button class="icon-btn modal-close" aria-label="Close dialog">${icon('x')}</button>${html}</div>`;
    document.body.appendChild(back);
    document.body.classList.add('no-scroll');
    const box = back.firstElementChild;
    const focusable = () => $$('a[href],button:not([disabled]),input,select,textarea,[tabindex]:not([tabindex="-1"])', box).filter(e => e.offsetParent !== null);
    const close = () => { back.remove(); document.body.classList.remove('no-scroll'); document.removeEventListener('keydown', onKey); if (prev && prev.focus) prev.focus(); };
    const onKey = e => {
      if (e.key === 'Escape') close();
      if (e.key === 'Tab') { const f = focusable(); if (!f.length) return; const a = f[0], z = f[f.length - 1]; if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); } }
    };
    document.addEventListener('keydown', onKey);
    back.addEventListener('mousedown', e => { if (e.target === back) close(); });
    $('.modal-close', box).addEventListener('click', close);
    (focusable()[1] || focusable()[0] || box).focus();
    return { el: box, close };
  }
};

/* ---------- Tabs (WAI-ARIA pattern, arrow-key navigation) ---------- */
function initTabs(root) {
  const tabs = $$('[role="tab"]', root), panels = $$('[role="tabpanel"]', root);
  const show = t => {
    tabs.forEach(x => { const on = x === t; x.setAttribute('aria-selected', on); x.tabIndex = on ? 0 : -1; });
    panels.forEach(p => { p.hidden = p.id !== t.getAttribute('aria-controls'); });
  };
  tabs.forEach((t, i) => {
    t.addEventListener('click', () => show(t));
    t.addEventListener('keydown', e => {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length]; n.focus(); show(n);
    });
  });
  show(tabs[0]);
  return show;
}

/* Field validation helper: shows the browser message under the input */
function validateFields(scope) {
  let ok = true, first = null;
  $$('input[required],select[required],textarea[required]', scope).forEach(inp => {
    let err = inp.parentElement.querySelector('.field-error');
    if (!inp.checkValidity()) {
      ok = false; first = first || inp;
      inp.setAttribute('aria-invalid', 'true');
      if (!err) { err = document.createElement('span'); err.className = 'field-error'; inp.parentElement.appendChild(err); }
      err.textContent = inp.validity.valueMissing ? 'Fill in this field.' : (inp.validationMessage || 'Check this value.');
    } else { inp.removeAttribute('aria-invalid'); if (err) err.remove(); }
  });
  if (first) first.focus();
  return ok;
}
