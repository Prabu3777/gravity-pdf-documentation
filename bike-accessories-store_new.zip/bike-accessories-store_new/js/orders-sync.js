/* orders-sync.js — once signed in, replaces the sample ORDERS/ADDRESSES data
   (from data.js) with the customer's real orders from Firestore, mapped into
   the exact shape orders.js already expects, then fires 'orders:sync' so the
   already-loaded orders.js redraws. No changes needed to orders.js itself. */

document.addEventListener('auth:change', async user => {
  if (typeof FirebaseDB === 'undefined') return;
  if (!user) { ORDERS.length = 0; emit('orders:sync'); return; }
  try {
    const docs = await FirebaseDB.getUserOrders(user.uid);
    ORDERS.length = 0;
    docs.forEach(o => {
      const created = o.createdAt && o.createdAt.toDate ? o.createdAt.toDate() : new Date();
      ORDERS.push({
        id: o.orderNumber || o.id,
        date: created.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
        status: o.orderStatus || 'Pending',
        pay: o.paymentStatus || 'Pending',
        method: 'Online',
        items: (o.items || []).map(it => [it.productId, it.qty, it.variant || '']),
        address: o.shippingAddress || null
      });
    });
    emit('orders:sync');
  } catch (e) { console.error('Order history sync failed', e); }
});
