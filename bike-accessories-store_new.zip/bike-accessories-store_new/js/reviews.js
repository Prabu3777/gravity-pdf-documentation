/* reviews.js — renders reviews + Q&A on product.html and handles submission
   (spec §16, §17). Expects a #reviewsRoot and #qaRoot container on the page
   and window.CURRENT_PRODUCT_ID set by product-details.js. */

App.init(async () => {
  const root = $('#reviewsRoot'); if (!root || !window.CURRENT_PRODUCT_ID) return;
  const id = window.CURRENT_PRODUCT_ID;

  const draw = async () => {
    const reviews = await FirebaseDB.getReviews(id);
    const avg = reviews.length ? (reviews.reduce((n, r) => n + r.rating, 0) / reviews.length) : 0;
    const breakdown = [5, 4, 3, 2, 1].map(s => reviews.filter(r => r.rating === s).length);
    root.innerHTML = `
      <div class="review-summary">
        <div class="review-avg"><strong>${avg.toFixed(1)}</strong>${stars(avg)}<span class="muted">${reviews.length} reviews</span></div>
        <ul class="review-bars">${breakdown.map((n, i) => `<li>${5 - i}★ <span class="meter"><span style="width:${reviews.length ? n / reviews.length * 100 : 0}%"></span></span> ${n}</li>`).join('')}</ul>
      </div>
      <ul class="review-list">${reviews.map(r => `<li class="review"><header>${stars(r.rating)}${r.verified ? '<span class="badge-verified">Verified Purchase</span>' : ''}</header><h4>${esc(r.title || '')}</h4><p>${esc(r.text)}</p><footer class="muted">${esc(r.name)}</footer></li>`).join('') || '<p class="muted">No reviews yet — be the first to ride and review.</p>'}</ul>
      <form id="reviewForm" class="review-form">
        <h3>Write a review</h3>
        <label>Rating <select name="rating" required>${[5, 4, 3, 2, 1].map(n => `<option value="${n}">${n} star</option>`).join('')}</select></label>
        <label>Title <input class="input" name="title" maxlength="80"></label>
        <label>Review <textarea class="input" name="text" required maxlength="1000"></textarea></label>
        <button class="btn btn-primary">Submit review</button>
      </form>`;
  };
  await draw();

  root.addEventListener('submit', async e => {
    if (e.target.id !== 'reviewForm') return; e.preventDefault();
    if (!Auth.user) { toast('Sign in to leave a review.', 'error'); return; }
    const f = new FormData(e.target);
    try {
      await FirebaseDB.submitReview(id, { rating: +f.get('rating'), title: f.get('title'), text: f.get('text') });
      toast('Thanks — your review is pending approval.');
      e.target.reset();
    } catch (err) { toast(err.message || 'Could not submit review.', 'error'); }
  });

  const qaRoot = $('#qaRoot'); if (!qaRoot) return;
  const drawQA = async () => {
    const qs = await FirebaseDB.getQuestions(id);
    qaRoot.innerHTML = `
      <ul class="qa-list">${qs.map(q => `<li class="qa-item"><p class="qa-q"><strong>Q:</strong> ${esc(q.q)}</p>${q.a ? `<p class="qa-a"><strong>A:</strong> ${esc(q.a)}</p>` : '<p class="muted">Awaiting answer from our team.</p>'}</li>`).join('') || '<p class="muted">No questions yet.</p>'}</ul>
      <form id="askForm" class="review-form"><label>Ask a question <textarea class="input" name="q" required maxlength="300"></textarea></label><button class="btn btn-outline">Ask</button></form>`;
  };
  await drawQA();
  qaRoot.addEventListener('submit', async e => {
    if (e.target.id !== 'askForm') return; e.preventDefault();
    if (!Auth.user) { toast('Sign in to ask a question.', 'error'); return; }
    try { await FirebaseDB.askQuestion(id, new FormData(e.target).get('q')); toast('Question submitted.'); e.target.reset(); await drawQA(); }
    catch (err) { toast(err.message || 'Could not submit question.', 'error'); }
  });
});
