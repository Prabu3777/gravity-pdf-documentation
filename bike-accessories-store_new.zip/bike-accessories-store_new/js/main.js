/* main.js — global click actions, live counts, home page sections, forms. Runs last. */
function syncStates() {
  const cart = Cart.count(), wish = Wishlist.get().length;
  $$('[data-count="cart"]').forEach(e => { e.textContent = cart; e.hidden = !cart; });
  $$('[data-count="wish"]').forEach(e => { e.textContent = wish; e.hidden = !wish; });
  $$('[data-action="wish"]').forEach(b => { const on = Wishlist.has(b.dataset.id); b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', on); });
  $$('[data-action="compare"]').forEach(b => { const on = Compare.has(b.dataset.id); b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', on); });
}
document.addEventListener('store:change', syncStates);

document.addEventListener('click', e => {
  const b = e.target.closest('[data-action]'); if (!b) return;
  const id = b.dataset.id;
  switch (b.dataset.action) {
    case 'add-cart':
      if (Cart.add(id, 1)) {
        toast('Added to cart');
        const t = b.textContent; b.textContent = 'Added'; b.classList.add('is-done'); setTimeout(() => { b.textContent = t; b.classList.remove('is-done'); }, 1200);
      } break;
    case 'wish': Wishlist.toggle(id); break;
    case 'compare': Compare.toggle(id); break;
    case 'quickview': openQuickView(id); break;
  }
});

/* Home page */
App.init(() => {
  const cg = $('#catGrid'); if (!cg) return;
  cg.innerHTML = CATEGORIES.map(c => `<a class="cat-tile" href="shop.html?cat=${c.id}"><img src="${catImg(c)}" alt="" loading="lazy"><span class="cat-count">${PRODUCTS.filter(p => p.cat === c.id).length} products</span><span class="cat-info"><h3>${c.name}</h3><p>${c.desc}</p></span></a>`).join('');
  $('#featuredGrid').innerHTML = PRODUCTS.filter(p => p.isFeatured).slice(0, 4).map(productCard).join('');
  $('#newRail').innerHTML = PRODUCTS.filter(p => p.isNew).slice(0, 8).map(productCard).join('');
  $('#bestGrid').innerHTML = PRODUCTS.filter(p => p.isBest).slice(0, 4).map(productCard).join('');
  $('#collGrid').innerHTML = COLLECTIONS.map((c, i) => `<a class="coll" href="shop.html?collection=${c.id}"><img src="${tile(c.glyph, i * 5 + 1, true)}" alt="" loading="lazy"><span class="coll-info"><h3>${c.name}</h3><p>${c.desc}</p></span></a>`).join('');
  $('#reviewGrid').innerHTML = REVIEWS.slice(0, 3).map(r => `<figure class="quote">${stars(r.rating)}<blockquote>${esc(r.text)}</blockquote><figcaption><b>${esc(r.name)}</b>, ${esc(r.city)}<br><span class="muted">Bought ${esc(getProduct(r.product).name)}</span></figcaption></figure>`).join('');
  const rail = $('#newRail'), step = () => rail.clientWidth * .8;
  $('#railPrev').addEventListener('click', () => rail.scrollBy({ left: -step(), behavior: 'smooth' }));
  $('#railNext').addEventListener('click', () => rail.scrollBy({ left: step(), behavior: 'smooth' }));
});

/* Newsletter and other simple forms in the UI preview */
document.addEventListener('submit', e => {
  const f = e.target.closest('[data-demo-form]'); if (!f) return;
  e.preventDefault(); if (!validateFields(f)) return;
  const btn = $('button[type="submit"],button:not([type])', f); if (btn) { btn.classList.add('is-loading'); setTimeout(() => btn.classList.remove('is-loading'), 700); }
  setTimeout(() => { toast(f.dataset.demoForm || 'Done'); f.reset(); }, 700);
});

App.run();
syncStates();
