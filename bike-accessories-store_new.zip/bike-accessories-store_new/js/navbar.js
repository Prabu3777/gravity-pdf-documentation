/* navbar.js — sticky header, mega menu, mobile drawer, theme menu, footer */
App.init(() => {
  const hdr = $('#site-header'), ftr = $('#site-footer'); if (!hdr) return;
  const file = location.pathname.split('/').pop() || 'index.html';
  const here = file + location.search;
  const links = [['Home', 'index.html'], ['Shop', 'shop.html'], ['Categories', null], ['New Arrivals', 'shop.html?filter=new'], ['Best Sellers', 'shop.html?filter=best'], ['Offers', 'shop.html?filter=offers'], ['Compare', 'compare.html']];
  const active = h => h && (h === here || (h === 'shop.html' && here === 'shop.html') || (h === file && !h.includes('?') && !location.search));
  const themeOpts = [['light', 'Light', 'sun'], ['dark', 'Dark', 'moon'], ['system', 'System', 'monitor']];
  const themeBtns = cls => themeOpts.map(([v, t, i]) => `<button role="menuitemradio" class="${cls}" data-theme-set="${v}" aria-checked="${Theme.get() === v}">${icon(i, 18)}<span>${t}</span></button>`).join('');

  hdr.innerHTML = `<div class="announce">Free shipping above ₹2,999. Use code <b>RIDE10</b> for 10% off your first order.</div>
  <header class="site-header">
    <div class="container header-inner">
      <button class="icon-btn mobile-only" id="menuBtn" aria-label="Open menu" aria-expanded="false" aria-controls="drawer">${icon('menu', 24)}</button>
      <a class="logo" href="index.html" aria-label="${BRAND.name} home"><img src="${BRAND.logo}" alt="" width="40" height="40"><span>${BRAND.name}</span></a>
      <nav class="main-nav" aria-label="Primary">${links.map(([t, h]) => h
        ? `<a href="${h}" ${active(h) ? 'aria-current="page"' : ''}>${t}</a>`
        : `<div class="has-mega"><button id="megaBtn" aria-expanded="false" aria-controls="mega">${t} ${icon('down', 16)}</button>
            <div class="mega" id="mega"><div class="container"><ul class="mega-grid">${CATEGORIES.map(c => `<li><a href="shop.html?cat=${c.id}"><b>${c.name}</b><span>${PRODUCTS.filter(p => p.cat === c.id).length} products</span></a></li>`).join('')}</ul></div></div></div>`).join('')}</nav>
      <div class="header-actions">
        <button class="icon-btn" id="searchBtn" aria-label="Search" aria-expanded="false" aria-controls="searchPanel">${icon('search', 22)}</button>
        <a class="icon-btn hide-mobile" href="wishlist.html" aria-label="Wishlist">${icon('heart', 22)}<span class="count" data-count="wish" hidden>0</span></a>
        <a class="icon-btn" href="cart.html" aria-label="Cart">${icon('cart', 22)}<span class="count" data-count="cart" hidden>0</span></a>
        <a class="icon-btn hide-mobile" href="account.html" aria-label="Account">${icon('user', 22)}</a>
        <div class="theme-menu hide-mobile"><button class="icon-btn" id="themeBtn" aria-label="Change theme" aria-haspopup="menu" aria-expanded="false"><span data-theme-icon></span></button>
          <div class="theme-pop" id="themePop" role="menu" hidden>${themeBtns('theme-opt')}</div></div>
      </div>
    </div>
    <div class="search-panel" id="searchPanel" hidden><div class="container">
      <form class="search-box" id="searchForm" role="search">${icon('search', 22)}<label class="sr-only" for="searchInput">Search products</label>
        <input id="searchInput" type="search" placeholder="Search helmets, saddle bags, SKU..." autocomplete="off" aria-controls="suggest">
        <button type="button" class="icon-btn" id="searchClose" aria-label="Close search">${icon('x', 20)}</button></form>
      <div class="suggest" id="suggest" aria-live="polite"></div></div></div>
  </header>
  <div class="scrim" id="drawerScrim"></div>
  <aside class="drawer" id="drawer" aria-label="Menu" aria-hidden="true">
    <div class="drawer-head"><span class="logo"><img src="${BRAND.logo}" alt="" width="34" height="34"><span>${BRAND.name}</span></span><button class="icon-btn" id="drawerClose" aria-label="Close menu">${icon('x', 22)}</button></div>
    <nav class="drawer-nav" aria-label="Mobile">
      <a href="index.html">Home</a><a href="shop.html">Shop</a><a href="shop.html?filter=new">New Arrivals</a><a href="shop.html?filter=best">Best Sellers</a><a href="shop.html?filter=offers">Offers</a><a href="compare.html">Compare</a>
      <details><summary>Categories</summary>${CATEGORIES.map(c => `<a class="sub" href="shop.html?cat=${c.id}">${c.name}</a>`).join('')}</details>
      <a href="wishlist.html">Wishlist</a><a href="account.html">Account</a><a href="orders.html">Orders</a><a href="contact.html">Support</a></nav>
    <div class="drawer-theme"><p>Theme</p><div class="theme-row">${themeBtns('theme-opt')}</div></div>
  </aside>`;

  /* mega menu */
  const mb = $('#megaBtn'), mega = $('.has-mega');
  mb.addEventListener('click', () => { const o = mega.classList.toggle('is-open'); mb.setAttribute('aria-expanded', o); });
  document.addEventListener('click', e => { if (!mega.contains(e.target)) { mega.classList.remove('is-open'); mb.setAttribute('aria-expanded', 'false'); } });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { mega.classList.remove('is-open'); mb.setAttribute('aria-expanded', 'false'); } });

  /* drawer */
  const drawer = $('#drawer'), scrim = $('#drawerScrim');
  const setDrawer = on => { drawer.classList.toggle('is-open', on); scrim.classList.toggle('is-on', on); drawer.setAttribute('aria-hidden', !on); $('#menuBtn').setAttribute('aria-expanded', on); document.body.classList.toggle('no-scroll', on); if (on) $('#drawerClose').focus(); };
  $('#menuBtn').addEventListener('click', () => setDrawer(true));
  $('#drawerClose').addEventListener('click', () => setDrawer(false)); scrim.addEventListener('click', () => setDrawer(false));

  /* theme */
  const pop = $('#themePop'), tb = $('#themeBtn');
  const paintTheme = () => {
    $('[data-theme-icon]').innerHTML = icon(Theme.get() === 'system' ? 'monitor' : document.documentElement.dataset.theme === 'dark' ? 'moon' : 'sun', 22);
    $$('[data-theme-set]').forEach(b => b.setAttribute('aria-checked', b.dataset.themeSet === Theme.get()));
  };
  tb.addEventListener('click', e => { e.stopPropagation(); pop.hidden = !pop.hidden; tb.setAttribute('aria-expanded', !pop.hidden); });
  document.addEventListener('click', e => { if (!pop.contains(e.target) && e.target !== tb) { pop.hidden = true; tb.setAttribute('aria-expanded', 'false'); } });
  $$('[data-theme-set]').forEach(b => b.addEventListener('click', () => { Theme.set(b.dataset.themeSet); pop.hidden = true; paintTheme(); }));
  document.addEventListener('theme:change', paintTheme); paintTheme();

  /* footer */
  if (ftr) ftr.innerHTML = `<footer class="site-footer"><div class="container">
    <div class="foot-grid">
      <div class="foot-brand"><a class="logo" href="index.html"><img src="${BRAND.logo}" alt="" width="36" height="36" style="border-radius:6px"><span>${BRAND.name}</span></a>
        <p>Riding, touring and adventure gear tested on real roads. Built for riders who never stop at the horizon.</p>
        <div class="social"><a href="#" aria-label="Instagram">${icon('instagram', 20)}</a><a href="#" aria-label="YouTube">${icon('youtube', 20)}</a><a href="#" aria-label="Facebook">${icon('facebook', 20)}</a></div></div>
      <div><h4>Shop</h4><ul>${['helmets', 'jackets', 'saddle-bags', 'rain-gear', 'tools'].map(id => `<li><a href="shop.html?cat=${id}">${getCat(id).name}</a></li>`).join('')}<li><a href="shop.html">All products</a></li></ul></div>
      <div><h4>Support</h4><ul><li><a href="faq.html">FAQ</a></li><li><a href="contact.html">Contact us</a></li><li><a href="orders.html">Track an order</a></li><li><a href="faq.html#returns">Returns and refunds</a></li><li><a href="faq.html#shipping">Shipping</a></li></ul></div>
      <div><h4>Company</h4><ul><li><a href="about.html">About us</a></li><li><a href="account.html">My account</a></li><li><a href="wishlist.html">Wishlist</a></li><li><a href="compare.html">Compare</a></li></ul></div>
    </div>
    <div class="foot-bottom"><span>© 2026 ${BRAND.name}. All rights reserved.</span><span>Payments secured by Razorpay. UPI, cards, net banking, wallets.</span><a href="admin/login.html" style="opacity:.55">Admin</a></div></div></footer>`;
});
