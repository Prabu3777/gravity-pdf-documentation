/* cart.js — cart store (localStorage for this UI preview) + cart page.
   Backend phase: logged-in carts move to Firestore and totals are re-verified server-side. */
const COUPONS = {
  RIDE10: { type: 'percent', value: 10, min: 999, max: 500, label: '10% off, up to ₹500' },
  WELCOME200: { type: 'fixed', value: 200, min: 1999, label: '₹200 off' },
  MONSOON15: { type: 'percent', value: 15, min: 2499, max: 900, label: '15% off, up to ₹900' }
};
const FREE_SHIP = 2999, SHIP_FEE = 149, GST = 18;

const Cart = {
  KEY: 'at_cart', CKEY: 'at_coupon',
  get() { return Store.get(Cart.KEY, []); },
  set(v) { Store.set(Cart.KEY, v); emit('store:change'); },
  count() { return Cart.get().reduce((n, i) => n + i.qty, 0); },
  add(id, qty = 1, variant = '') {
    const p = getProduct(id);
    if (!p || p.stock <= 0) { toast('This item is out of stock.', 'error'); return false; }
    const items = Cart.get(), k = id + '|' + variant, it = items.find(i => i.k === k), max = Math.min(p.stock, 10);
    if (it) it.qty = Math.min(it.qty + qty, max); else items.push({ k, id, qty: Math.min(qty, max), variant });
    Cart.set(items); return true;
  },
  setQty(k, q) { const items = Cart.get(), it = items.find(i => i.k === k); if (!it) return; const p = getProduct(it.id); it.qty = Math.max(1, Math.min(q, Math.min(p.stock, 10))); Cart.set(items); },
  remove(k) { Cart.set(Cart.get().filter(i => i.k !== k)); },
  clear() { Store.del(Cart.KEY); Store.del(Cart.CKEY); emit('store:change'); },
  lines() { return Cart.get().map(i => { const p = getProduct(i.id); return p ? { ...i, p, total: p.price * i.qty } : null; }).filter(Boolean); },
  coupon() { return Store.get(Cart.CKEY, null); },
  applyCoupon(code) {
    const c = COUPONS[(code || '').trim().toUpperCase()], sub = Cart.lines().reduce((n, l) => n + l.total, 0);
    if (!c) return { ok: false, msg: 'That code is not valid.' };
    if (sub < c.min) return { ok: false, msg: 'Add ' + fmt(c.min - sub) + ' more to use this code.' };
    Store.set(Cart.CKEY, code.trim().toUpperCase()); emit('store:change'); return { ok: true, msg: 'Coupon applied: ' + c.label };
  },
  removeCoupon() { Store.del(Cart.CKEY); emit('store:change'); },
  summary(shipOverride) {
    const lines = Cart.lines(), subtotal = lines.reduce((n, l) => n + l.total, 0), mrp = lines.reduce((n, l) => n + l.p.mrp * l.qty, 0);
    const code = Cart.coupon(), c = code && COUPONS[code];
    let discount = 0;
    if (c && subtotal >= c.min) discount = c.type === 'percent' ? Math.min(Math.round(subtotal * c.value / 100), c.max || Infinity) : c.value;
    const after = subtotal - discount;
    const shipping = shipOverride != null ? shipOverride : (after === 0 || after >= FREE_SHIP ? 0 : SHIP_FEE);
    const tax = Math.round(after * GST / (100 + GST));
    return { lines, count: lines.reduce((n, l) => n + l.qty, 0), subtotal, savings: mrp - subtotal, code: c ? code : null, coupon: c, discount, shipping, tax, total: after + shipping };
  }
};

function summaryRows(s, { showCoupon = true } = {}) {
  return `<dl class="sum">
    <div><dt>Subtotal (${s.count} ${s.count === 1 ? 'item' : 'items'})</dt><dd>${fmt(s.subtotal)}</dd></div>
    ${s.savings ? `<div class="good"><dt>You save on MRP</dt><dd>${fmt(s.savings)}</dd></div>` : ''}
    ${showCoupon && s.discount ? `<div class="good"><dt>Coupon ${esc(s.code)}</dt><dd>- ${fmt(s.discount)}</dd></div>` : ''}
    <div><dt>Shipping</dt><dd>${s.shipping ? fmt(s.shipping) : 'Free'}</dd></div>
    <div><dt>GST (${GST}%, included)</dt><dd>${fmt(s.tax)}</dd></div>
    <div class="grand"><dt>Total</dt><dd>${fmt(s.total)}</dd></div></dl>`;
}

App.init(() => {
  const root = $('#cartRoot'); if (!root) return;
  const draw = () => {
    const s = Cart.summary();
    if (!s.lines.length) { root.innerHTML = emptyState({ ico: 'cart', title: 'Your next adventure starts here.', text: 'Your cart is empty. Pick up some gear and hit the road.', btn: 'Start shopping', href: 'shop.html' }); return; }
    const need = Math.max(0, FREE_SHIP - (s.subtotal - s.discount)), prog = Math.min(100, ((s.subtotal - s.discount) / FREE_SHIP) * 100);
    root.innerHTML = `<div class="cart-grid">
      <div>
        <div class="ship-meter"><p>${need ? `Add <b>${fmt(need)}</b> more for free shipping.` : '<b>You have free shipping.</b>'}</p><div class="meter"><span style="width:${prog}%"></span></div></div>
        <ul class="cart-list">${s.lines.map(l => `<li class="cart-line">
          <a class="cart-img" href="product.html?id=${l.p.id}"><img src="${imgSrc(l.p)}" alt="${esc(l.p.name)}" width="120" height="120"></a>
          <div class="cart-info">
            <span class="pcard-brand">${esc(getBrand(l.p.brand).name)}</span>
            <h3><a href="product.html?id=${l.p.id}">${esc(l.p.name)}</a></h3>
            ${l.variant ? `<p class="muted">${esc(l.variant)}</p>` : ''}
            <div class="price"><span class="price-now">${fmt(l.p.price)}</span><span class="price-mrp">${fmt(l.p.mrp)}</span></div>
          </div>
          <div class="qty" role="group" aria-label="Quantity for ${esc(l.p.name)}"><button data-q="${l.k}" data-d="-1" aria-label="Decrease quantity">${icon('minus', 16)}</button><output aria-live="polite">${l.qty}</output><button data-q="${l.k}" data-d="1" aria-label="Increase quantity">${icon('plus', 16)}</button></div>
          <strong class="cart-sub">${fmt(l.total)}</strong>
          <button class="icon-btn" data-rm="${l.k}" aria-label="Remove ${esc(l.p.name)}">${icon('trash', 18)}</button></li>`).join('')}</ul>
        <a class="link-u" href="shop.html">Continue shopping</a>
      </div>
      <aside class="summary-card"><h2>Order summary</h2>
        <form class="coupon" id="couponForm" novalidate><label class="sr-only" for="couponIn">Coupon code</label>
          <input class="input" id="couponIn" placeholder="Coupon code" value="${s.code || ''}" ${s.code ? 'readonly' : ''}>
          ${s.code ? '<button type="button" class="btn btn-outline btn-sm" id="couponRm">Remove</button>' : '<button class="btn btn-dark btn-sm">Apply</button>'}</form>
        <p class="coupon-msg" id="couponMsg">${s.code ? esc(s.coupon.label) : 'Try RIDE10 or WELCOME200.'}</p>
        ${summaryRows(s)}
        <a class="btn btn-primary btn-lg btn-block" href="checkout.html">Proceed to checkout</a>
        <p class="secure">${icon('lock', 15)} Secure checkout by Razorpay</p></aside></div>`;
  };
  draw();
  root.addEventListener('click', e => {
    const q = e.target.closest('[data-q]'), r = e.target.closest('[data-rm]');
    if (q) { const it = Cart.get().find(i => i.k === q.dataset.q); Cart.setQty(q.dataset.q, it.qty + +q.dataset.d); draw(); }
    if (r) { Cart.remove(r.dataset.rm); toast('Removed from cart', 'info'); draw(); }
    if (e.target.id === 'couponRm') { Cart.removeCoupon(); draw(); }
  });
  root.addEventListener('submit', e => {
    if (e.target.id !== 'couponForm') return; e.preventDefault();
    const r = Cart.applyCoupon($('#couponIn').value);
    if (r.ok) { toast(r.msg); draw(); } else { const m = $('#couponMsg'); m.textContent = r.msg; m.className = 'coupon-msg err'; }
  });
});
