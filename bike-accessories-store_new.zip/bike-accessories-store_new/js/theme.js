/* theme.js — light / dark / system. Loaded in <head> so there is no flash. */
(function () {
  var KEY = 'at_theme';
  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  function pref() { try { return localStorage.getItem(KEY) || 'system'; } catch (e) { return 'system'; } }
  function resolve(p) { return p === 'system' ? (mq && mq.matches ? 'dark' : 'light') : p; }
  function apply(p) {
    document.documentElement.dataset.theme = resolve(p);
    document.documentElement.dataset.themePref = p;
  }
  window.Theme = {
    get: pref,
    set: function (p) {
      try { localStorage.setItem(KEY, p); } catch (e) {}
      apply(p);
      document.dispatchEvent(new CustomEvent('theme:change', { detail: p }));
    }
  };
  apply(pref());
  if (mq && mq.addEventListener) mq.addEventListener('change', function () { if (pref() === 'system') apply('system'); });
})();
