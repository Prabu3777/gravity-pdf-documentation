initAdminPage('orders', 'Order details');

const order = AdminDB.orders.get(params().id);
if (!order) {
  $('#odContent').innerHTML = `<div class="admin-empty">${icon('package', 32)}<h2>Order not found</h2><a class="btn btn-primary" href="orders.html">Back to orders</a></div>`;
} else {
  const flowIdx = ADMIN_ORDER_STATUSES.indexOf(order.orderStatus);
  const mainFlow = ['Pending', 'Confirmed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];
  const curFlowIdx = mainFlow.indexOf(order.orderStatus);

  $('#odContent').innerHTML = `
    <div class="admin-page-head">
      <div><h1>${order.orderNumber}</h1><p class="muted">Placed on ${order.createdAt} · ${esc(order.customer.name)}</p></div>
      <div class="admin-page-actions">
        <a class="btn btn-outline" href="orders.html">Back to orders</a>
        <select id="statusSel">${ADMIN_ORDER_STATUSES.map(s => `<option ${s === order.orderStatus ? 'selected' : ''}>${s}</option>`).join('')}</select>
      </div>
    </div>

    <div class="admin-grid-2">
      <div>
        <div class="admin-card">
          <div class="admin-card-head"><h2>Items</h2></div>
          <div class="table-wrap"><table class="admin-table">
            <thead><tr><th>Product</th><th>Variant</th><th>Qty</th><th>Unit price</th><th>Total</th></tr></thead>
            <tbody>${order.items.map(it => `
              <tr>
                <td class="cell-main"><img class="cell-img" src="${it.image}" alt=""><span class="cell-title">${esc(it.name)}</span></td>
                <td class="cell-sub">${esc(it.variant)}</td>
                <td>${it.qty}</td>
                <td>${fmt(it.price)}</td>
                <td>${fmt(it.price * it.qty)}</td>
              </tr>`).join('')}</tbody>
          </table></div>
          <div class="admin-card-body" style="border-top:1px solid var(--border)">
            <div style="display:flex;justify-content:space-between;margin-bottom:6px"><span class="muted">Subtotal</span><span>${fmt(order.subtotal)}</span></div>
            ${order.discount ? `<div style="display:flex;justify-content:space-between;margin-bottom:6px"><span class="muted">Discount (${order.couponCode})</span><span>-${fmt(order.discount)}</span></div>` : ''}
            <div style="display:flex;justify-content:space-between;margin-bottom:6px"><span class="muted">Tax</span><span>${fmt(order.tax)}</span></div>
            <div style="display:flex;justify-content:space-between;margin-bottom:6px"><span class="muted">Shipping</span><span>${order.shipping ? fmt(order.shipping) : 'Free'}</span></div>
            <div style="display:flex;justify-content:space-between;font-weight:700;font-size:1.05rem;margin-top:8px;padding-top:8px;border-top:1px solid var(--border)"><span>Grand total</span><span>${fmt(order.total)}</span></div>
          </div>
        </div>

        <div class="admin-card">
          <div class="admin-card-head"><h2>Order timeline</h2></div>
          <div class="admin-card-body">
            <div class="admin-timeline">
              ${mainFlow.map((s, i) => `
                <div class="tl-step ${i <= curFlowIdx ? 'done' : ''}">
                  <div class="tl-dot-col"><div class="tl-dot"></div>${i < mainFlow.length - 1 ? '<div class="tl-line"></div>' : ''}</div>
                  <div class="tl-content"><b>${s}</b><span>${i <= curFlowIdx ? order.updatedAt : 'Pending'}</span></div>
                </div>`).join('')}
            </div>
          </div>
        </div>
      </div>

      <div>
        <div class="admin-card">
          <div class="admin-card-head"><h2>Customer</h2></div>
          <div class="admin-card-body">
            <p><strong>${esc(order.customer.name)}</strong></p>
            <p class="cell-sub">${esc(order.customer.email)}</p>
            <p class="cell-sub">${esc(order.customer.phone)}</p>
          </div>
        </div>
        <div class="admin-card">
          <div class="admin-card-head"><h2>Shipping address</h2></div>
          <div class="admin-card-body">
            <p>${esc(order.shippingAddress.name)}</p>
            <p class="cell-sub">${esc(order.shippingAddress.line)}, ${esc(order.shippingAddress.city)}, ${esc(order.shippingAddress.state)} - ${esc(order.shippingAddress.pin)}</p>
            <p class="cell-sub">${esc(order.shippingAddress.phone)}</p>
          </div>
        </div>
        <div class="admin-card">
          <div class="admin-card-head"><h2>Payment</h2></div>
          <div class="admin-card-body">
            <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span class="muted">Method</span><span>${order.paymentMethod}</span></div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span class="muted">Status</span>${paymentPill(order.paymentStatus)}</div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span class="muted">Razorpay Order</span><span class="cell-sub">${order.razorpayOrderId}</span></div>
            <div style="display:flex;justify-content:space-between"><span class="muted">Razorpay Payment</span><span class="cell-sub">${order.razorpayPaymentId || '—'}</span></div>
          </div>
        </div>
      </div>
    </div>`;

  $('#statusSel').addEventListener('change', e => {
    order.orderStatus = e.target.value; order.updatedAt = '2026-09-21';
    AdminDB.orders.save(order); toast('Status updated to ' + order.orderStatus);
    setTimeout(() => location.reload(), 500);
  });
}
