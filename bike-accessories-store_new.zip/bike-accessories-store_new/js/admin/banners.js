initAdminPage('banners', 'Banners');

function render() {
  const list = AdminDB.banners.all();
  $('#bnTable').innerHTML = `
    <thead><tr><th></th><th>Banner</th><th>Button</th><th>Validity</th><th>Status</th><th></th></tr></thead>
    <tbody>${list.map((b, i) => `
      <tr>
        <td><img class="cell-img" src="${b.image}" alt="" style="width:64px;height:40px;object-fit:cover"></td>
        <td><div class="cell-title">${esc(b.title)}</div><div class="cell-sub">${esc(b.subtitle)}</div></td>
        <td class="cell-sub">${esc(b.btnText)} → ${esc(b.btnUrl)}</td>
        <td class="cell-sub">${b.start} → ${b.end}</td>
        <td>${activePill(b.active)}</td>
        <td>
          <div class="row-actions">
            ${i > 0 ? `<button class="icon-btn btn-icon-only" data-up="${b.id}" title="Move up">${icon('up', 16)}</button>` : ''}
            ${i < list.length - 1 ? `<button class="icon-btn btn-icon-only" data-down="${b.id}" title="Move down">${icon('down', 16)}</button>` : ''}
            <button class="icon-btn btn-icon-only" data-edit="${b.id}" title="Edit">${icon('edit', 17)}</button>
            <button class="icon-btn btn-icon-only" data-toggle="${b.id}" title="Toggle active">${icon(b.active ? 'x' : 'check', 17)}</button>
            <button class="icon-btn btn-icon-only" data-del="${b.id}" title="Delete">${icon('trash', 17)}</button>
          </div>
        </td>
      </tr>`).join('')}</tbody>`;

  $$('#bnTable [data-edit]').forEach(x => x.addEventListener('click', () => openForm(list.find(b => b.id === x.dataset.edit))));
  $$('#bnTable [data-toggle]').forEach(x => x.addEventListener('click', () => { const b = list.find(y => y.id === x.dataset.toggle); b.active = !b.active; AdminDB.banners.save(b); render(); }));
  $$('#bnTable [data-del]').forEach(x => x.addEventListener('click', () => confirmAction('Delete this banner?', () => { AdminDB.banners.remove(x.dataset.del); toast('Banner deleted'); render(); })));
  $$('#bnTable [data-up]').forEach(x => x.addEventListener('click', () => { reorder(x.dataset.up, -1); }));
  $$('#bnTable [data-down]').forEach(x => x.addEventListener('click', () => { reorder(x.dataset.down, 1); }));
}

function reorder(id, dir) {
  const list = AdminDB.banners.all();
  const i = list.findIndex(b => b.id === id), j = i + dir;
  if (j < 0 || j >= list.length) return;
  [list[i], list[j]] = [list[j], list[i]];
  Store.set('adm_banners', list); render();
}

function openForm(b) {
  const editing = !!b;
  b = b || { id: 'bn' + Date.now().toString(36), title: '', subtitle: '', image: 'assets/hero-banner.png', btnText: 'Shop now', btnUrl: 'shop.html', start: '2026-09-21', end: '2026-10-21', active: true };
  const { close } = Modal.open(`
    <div class="admin-card-body">
      <h2 style="margin-bottom:16px">${editing ? 'Edit banner' : 'Add banner'}</h2>
      <div class="form-grid">
        <div class="form-field span-2"><label>Title *</label><input type="text" id="m-title" value="${esc(b.title)}" required></div>
        <div class="form-field span-2"><label>Subtitle</label><input type="text" id="m-sub" value="${esc(b.subtitle)}"></div>
        <div class="form-field"><label>Button text</label><input type="text" id="m-btntext" value="${esc(b.btnText)}"></div>
        <div class="form-field"><label>Button URL</label><input type="text" id="m-btnurl" value="${esc(b.btnUrl)}"></div>
        <div class="form-field"><label>Start date</label><input type="date" id="m-start" value="${b.start}"></div>
        <div class="form-field"><label>End date</label><input type="date" id="m-end" value="${b.end}"></div>
      </div>
      <label class="switch" style="margin:16px 0"><input type="checkbox" id="m-active" ${b.active ? 'checked' : ''}><span class="switch-track"></span> Active</label>
      <div style="display:flex;gap:10px;justify-content:flex-end"><button class="btn btn-outline" id="m-cancel" type="button">Cancel</button><button class="btn btn-primary" id="m-save" type="button">Save</button></div>
    </div>`, { label: 'Banner form' });
  $('#m-cancel').addEventListener('click', close);
  $('#m-save').addEventListener('click', () => {
    if (!$('#m-title').value.trim()) { toast('Title is required', 'error'); return; }
    Object.assign(b, { title: $('#m-title').value.trim(), subtitle: $('#m-sub').value.trim(), btnText: $('#m-btntext').value.trim(), btnUrl: $('#m-btnurl').value.trim(), start: $('#m-start').value, end: $('#m-end').value, active: $('#m-active').checked });
    AdminDB.banners.save(b); toast('Banner saved'); close(); render();
  });
}
$('#btnAdd').addEventListener('click', () => openForm(null));
render();
