initAdminPage('faq', 'FAQ');

function render() {
  const list = AdminDB.faqs.all().slice().sort((a, b) => a.order - b.order);
  $('#fqTable').innerHTML = `
    <thead><tr><th>Question</th><th>Answer</th><th>Status</th><th></th></tr></thead>
    <tbody>${list.map((f, i) => `
      <tr>
        <td class="cell-title" style="max-width:260px">${esc(f.q)}</td>
        <td class="cell-sub" style="max-width:340px">${esc(f.a)}</td>
        <td>${activePill(f.active)}</td>
        <td>
          <div class="row-actions">
            ${i > 0 ? `<button class="icon-btn btn-icon-only" data-up="${f.id}" title="Move up">${icon('up', 15)}</button>` : ''}
            ${i < list.length - 1 ? `<button class="icon-btn btn-icon-only" data-down="${f.id}" title="Move down">${icon('down', 15)}</button>` : ''}
            <button class="icon-btn btn-icon-only" data-edit="${f.id}" title="Edit">${icon('edit', 17)}</button>
            <button class="icon-btn btn-icon-only" data-toggle="${f.id}" title="Toggle active">${icon(f.active ? 'x' : 'check', 17)}</button>
            <button class="icon-btn btn-icon-only" data-del="${f.id}" title="Delete">${icon('trash', 17)}</button>
          </div>
        </td>
      </tr>`).join('')}</tbody>`;
  $$('#fqTable [data-edit]').forEach(b => b.addEventListener('click', () => openForm(list.find(f => f.id === b.dataset.edit))));
  $$('#fqTable [data-toggle]').forEach(b => b.addEventListener('click', () => { const f = list.find(x => x.id === b.dataset.toggle); f.active = !f.active; AdminDB.faqs.save(f); render(); }));
  $$('#fqTable [data-del]').forEach(b => b.addEventListener('click', () => confirmAction('Delete this FAQ?', () => { AdminDB.faqs.remove(b.dataset.del); toast('FAQ deleted'); render(); })));
  $$('#fqTable [data-up]').forEach(b => b.addEventListener('click', () => move(b.dataset.up, -1)));
  $$('#fqTable [data-down]').forEach(b => b.addEventListener('click', () => move(b.dataset.down, 1)));
}
function move(id, dir) {
  const list = AdminDB.faqs.all().slice().sort((a, b) => a.order - b.order);
  const i = list.findIndex(f => f.id === id), j = i + dir;
  if (j < 0 || j >= list.length) return;
  [list[i].order, list[j].order] = [list[j].order, list[i].order];
  list.forEach(f => AdminDB.faqs.save(f)); render();
}
function openForm(f) {
  const editing = !!f;
  f = f || { id: 'fq' + Date.now().toString(36), q: '', a: '', active: true, order: AdminDB.faqs.all().length + 1 };
  const { close } = Modal.open(`
    <div class="admin-card-body">
      <h2 style="margin-bottom:16px">${editing ? 'Edit FAQ' : 'Add FAQ'}</h2>
      <div class="form-field" style="margin-bottom:14px"><label>Question *</label><input type="text" id="m-q" value="${esc(f.q)}" required></div>
      <div class="form-field"><label>Answer *</label><textarea id="m-a" style="min-height:100px" required>${esc(f.a)}</textarea></div>
      <label class="switch" style="margin:16px 0"><input type="checkbox" id="m-active" ${f.active ? 'checked' : ''}><span class="switch-track"></span> Active</label>
      <div style="display:flex;gap:10px;justify-content:flex-end"><button class="btn btn-outline" id="m-cancel" type="button">Cancel</button><button class="btn btn-primary" id="m-save" type="button">Save</button></div>
    </div>`, { label: 'FAQ form' });
  $('#m-cancel').addEventListener('click', close);
  $('#m-save').addEventListener('click', () => {
    if (!$('#m-q').value.trim() || !$('#m-a').value.trim()) { toast('Question and answer are required', 'error'); return; }
    f.q = $('#m-q').value.trim(); f.a = $('#m-a').value.trim(); f.active = $('#m-active').checked;
    AdminDB.faqs.save(f); toast('FAQ saved'); close(); render();
  });
}
$('#btnAdd').addEventListener('click', () => openForm(null));
render();
