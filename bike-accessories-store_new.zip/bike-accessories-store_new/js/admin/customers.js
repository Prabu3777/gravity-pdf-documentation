initAdminPage('customers', 'Customers');
$('#custSearchIco').innerHTML = icon('search', 16);

function render() {
  const q = $('#custSearch').value.trim().toLowerCase();
  const list = AdminDB.customers.all().filter(c => !q || c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q));
  $('#custTable').innerHTML = `
    <thead><tr><th>Customer</th><th>Phone</th><th>Orders</th><th>Total spent</th><th>Joined</th><th>Status</th><th></th></tr></thead>
    <tbody>${list.map(c => `
      <tr>
        <td class="cell-main"><span class="admin-avatar" style="width:32px;height:32px;font-size:.75rem">${c.name.split(' ').map(w => w[0]).join('').slice(0, 2)}</span><div><div class="cell-title">${esc(c.name)}</div><div class="cell-sub">${esc(c.email)}</div></div></td>
        <td>${esc(c.phone)}</td>
        <td>${c.orders}</td>
        <td>${fmt(c.totalSpent)}</td>
        <td>${c.joined}</td>
        <td>${statusPill(c.status)}</td>
        <td>
          <div class="row-actions">
            <button class="icon-btn btn-icon-only" data-view="${c.id}" title="View history">${icon('eye', 17)}</button>
            <button class="icon-btn btn-icon-only" data-block="${c.id}" title="${c.status === 'Blocked' ? 'Unblock' : 'Block'}">${icon(c.status === 'Blocked' ? 'check' : 'x', 17)}</button>
          </div>
        </td>
      </tr>`).join('') || '<tr><td colspan="7" class="admin-empty">No customers match.</td></tr>'}</tbody>`;
  $$('#custTable [data-view]').forEach(b => b.addEventListener('click', () => openDetail(list.find(c => c.id === b.dataset.view))));
  $$('#custTable [data-block]').forEach(b => b.addEventListener('click', () => {
    const c = list.find(x => x.id === b.dataset.block); c.status = c.status === 'Blocked' ? 'Active' : 'Blocked'; AdminDB.customers.save(c); toast('Customer ' + (c.status === 'Blocked' ? 'blocked' : 'unblocked')); render();
  }));
}

function openDetail(c) {
  const orders = AdminDB.orders.all().filter(o => o.customer.email === c.email);
  const reviews = AdminDB.reviews.all().filter(r => r.name && r.name.split(' ')[0] === c.name.split(' ')[0]);
  Modal.open(`
    <div class="admin-card-body">
      <h2 style="margin-bottom:2px">${esc(c.name)}</h2>
      <p class="muted small" style="margin-bottom:18px">${esc(c.email)} · ${esc(c.phone)} · Joined ${c.joined}</p>
      <h3 style="font-size:.95rem;margin-bottom:8px">Order history</h3>
      <div class="table-wrap" style="margin-bottom:18px"><table class="admin-table">
        <thead><tr><th>Order</th><th>Date</th><th>Amount</th><th>Status</th></tr></thead>
        <tbody>${orders.map(o => `<tr><td>${o.orderNumber}</td><td>${o.createdAt}</td><td>${fmt(o.total)}</td><td>${statusPill(o.orderStatus)}</td></tr>`).join('') || '<tr><td colspan="4" class="admin-empty">No orders yet.</td></tr>'}</tbody>
      </table></div>
      <h3 style="font-size:.95rem;margin-bottom:8px">Reviews</h3>
      <p class="cell-sub">${reviews.length ? reviews.map(r => `"${esc(r.title)}" — ${r.rating}★`).join('<br>') : 'No reviews yet.'}</p>
    </div>`, { label: 'Customer detail', cls: 'modal-lg' });
}

$('#custSearch').addEventListener('input', render);
render();
