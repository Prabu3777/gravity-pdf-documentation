initAdminPage('brands', 'Brands');

function render() {
  const list = AdminDB.brands.all();
  $('#brandTable').innerHTML = `
    <thead><tr><th>Brand</th><th>Description</th><th>Website</th><th>Products</th><th>Status</th><th></th></tr></thead>
    <tbody>${list.map(b => `
      <tr>
        <td class="cell-main"><span class="admin-avatar" style="width:34px;height:34px;font-size:.8rem">${esc(b.name.slice(0, 2).toUpperCase())}</span><span class="cell-title">${esc(b.name)}</span></td>
        <td class="cell-sub">${esc(b.desc || '')}</td>
        <td class="cell-sub">${b.website ? esc(b.website) : '—'}</td>
        <td>${AdminDB.products.all().filter(p => p.brand === b.id).length}</td>
        <td>${activePill(b.active !== false)}</td>
        <td>
          <div class="row-actions">
            <button class="icon-btn btn-icon-only" data-edit="${b.id}" title="Edit">${icon('edit', 17)}</button>
            <button class="icon-btn btn-icon-only" data-toggle="${b.id}" title="Toggle active">${icon(b.active === false ? 'check' : 'x', 17)}</button>
            <button class="icon-btn btn-icon-only" data-del="${b.id}" title="Delete">${icon('trash', 17)}</button>
          </div>
        </td>
      </tr>`).join('')}</tbody>`;
  $$('#brandTable [data-edit]').forEach(x => x.addEventListener('click', () => openForm(list.find(b => b.id === x.dataset.edit))));
  $$('#brandTable [data-toggle]').forEach(x => x.addEventListener('click', () => { const b = list.find(y => y.id === x.dataset.toggle); b.active = b.active === false ? true : false; AdminDB.brands.save(b); render(); }));
  $$('#brandTable [data-del]').forEach(x => x.addEventListener('click', () => confirmAction('Delete this brand?', () => { AdminDB.brands.remove(x.dataset.del); toast('Brand deleted'); render(); })));
}

function openForm(b) {
  const editing = !!b;
  b = b || { id: 'br' + Date.now().toString(36), name: '', desc: '', website: '', active: true };
  const { close } = Modal.open(`
    <div class="admin-card-body">
      <h2 style="margin-bottom:16px">${editing ? 'Edit brand' : 'Add brand'}</h2>
      <div class="form-grid">
        <div class="form-field span-2"><label>Brand name *</label><input type="text" id="m-name" value="${esc(b.name)}" required></div>
        <div class="form-field span-2"><label>Description</label><textarea id="m-desc" style="min-height:60px">${esc(b.desc || '')}</textarea></div>
        <div class="form-field span-2"><label>Website</label><input type="url" id="m-web" value="${esc(b.website || '')}" placeholder="https://"></div>
      </div>
      <label class="switch" style="margin:16px 0"><input type="checkbox" id="m-active" ${b.active !== false ? 'checked' : ''}><span class="switch-track"></span> Active</label>
      <div style="display:flex;gap:10px;justify-content:flex-end"><button class="btn btn-outline" id="m-cancel" type="button">Cancel</button><button class="btn btn-primary" id="m-save" type="button">Save</button></div>
    </div>`, { label: 'Brand form' });
  $('#m-cancel').addEventListener('click', close);
  $('#m-save').addEventListener('click', () => {
    if (!$('#m-name').value.trim()) { toast('Brand name is required', 'error'); return; }
    b.name = $('#m-name').value.trim(); b.desc = $('#m-desc').value.trim(); b.website = $('#m-web').value.trim(); b.active = $('#m-active').checked;
    AdminDB.brands.save(b); toast('Brand saved'); close(); render();
  });
}
$('#btnAdd').addEventListener('click', () => openForm(null));
render();
