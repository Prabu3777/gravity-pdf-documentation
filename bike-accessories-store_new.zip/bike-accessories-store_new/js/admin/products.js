initAdminPage('products', 'Products');
$('#searchIco').innerHTML = icon('search', 16);

let pList = AdminDB.products.all();
let page = 1;
const PAGE_SIZE = 10;

$('#fCategory').innerHTML = '<option value="">All categories</option>' + CATEGORIES.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
$('#fBrand').innerHTML = '<option value="">All brands</option>' + BRANDS.map(b => `<option value="${b.id}">${b.name}</option>`).join('');

const initialQ = params().q || '';
if (initialQ) $('#fSearch').value = initialQ;

function getFiltered() {
  const q = $('#fSearch').value.trim().toLowerCase();
  const cat = $('#fCategory').value, brand = $('#fBrand').value, status = $('#fStatus').value, sort = $('#fSort').value;
  let list = pList.filter(p => {
    if (q && !(p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q) || getBrand(p.brand).name.toLowerCase().includes(q))) return false;
    if (cat && p.cat !== cat) return false;
    if (brand && p.brand !== brand) return false;
    if (status === 'active' && p.active === false) return false;
    if (status === 'inactive' && p.active !== false) return false;
    if (status === 'low' && !(p.stock > 0 && p.stock <= (p.low || 5))) return false;
    if (status === 'out' && p.stock > 0) return false;
    return true;
  });
  const sorters = {
    newest: (a, b) => b.created.localeCompare(a.created),
    name: (a, b) => a.name.localeCompare(b.name),
    'price-asc': (a, b) => a.price - b.price,
    'price-desc': (a, b) => b.price - a.price,
    'stock-asc': (a, b) => a.stock - b.stock,
    rating: (a, b) => b.rating - a.rating
  };
  list = list.slice().sort(sorters[sort] || sorters.newest);
  return list;
}

function stockStatus(p) {
  if (p.stock <= 0) return '<span class="pill pill-bad">Out of stock</span>';
  if (p.stock <= (p.low || 5)) return '<span class="pill pill-warn">Low stock</span>';
  return '<span class="pill pill-good">In stock</span>';
}

function render() {
  const list = getFiltered();
  $('#prodCount').textContent = list.length + ' product' + (list.length === 1 ? '' : 's');
  const totalPages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  page = Math.min(page, totalPages);
  const pageItems = list.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  $('#prodTable').innerHTML = `
    <thead><tr><th class="row-check"><input type="checkbox" aria-label="Select all"></th><th>Product</th><th>SKU</th><th>Brand</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th></th></tr></thead>
    <tbody>${pageItems.map(p => `
      <tr>
        <td class="row-check"><input type="checkbox" aria-label="Select ${esc(p.name)}"></td>
        <td class="cell-main"><img class="cell-img" src="${imgSrc(p)}" alt=""><div><div class="cell-title">${esc(p.name)}</div><div class="cell-sub">${p.created}</div></div></td>
        <td>${p.sku}</td>
        <td>${getBrand(p.brand).name}</td>
        <td>${getCat(p.cat).name}</td>
        <td>${fmt(p.price)}${p.mrp > p.price ? `<div class="cell-sub" style="text-decoration:line-through">${fmt(p.mrp)}</div>` : ''}</td>
        <td>${p.stock}</td>
        <td>${p.active === false ? '<span class="pill pill-neutral">Inactive</span>' : stockStatus(p)}</td>
        <td>
          <div class="row-actions">
            <a class="icon-btn btn-icon-only" href="../product.html?id=${p.id}" target="_blank" title="View on storefront">${icon('eye', 17)}</a>
            <a class="icon-btn btn-icon-only" href="product-form.html?id=${p.id}" title="Edit">${icon('edit', 17)}</a>
            <button class="icon-btn btn-icon-only" data-act="dup" data-id="${p.id}" title="Duplicate">${icon('copy', 17)}</button>
            <button class="icon-btn btn-icon-only" data-act="toggle" data-id="${p.id}" title="${p.active === false ? 'Activate' : 'Deactivate'}">${icon(p.active === false ? 'check' : 'x', 17)}</button>
            <button class="icon-btn btn-icon-only" data-act="del" data-id="${p.id}" title="Delete">${icon('trash', 17)}</button>
          </div>
        </td>
      </tr>`).join('') || `<tr><td colspan="9" class="admin-empty">${icon('tag', 32)}<div>No products match these filters.</div></td></tr>`}</tbody>`;

  $('#prodPagination').innerHTML = `
    <span>Page ${page} of ${totalPages}</span>
    <div class="pg-btns">
      <button ${page <= 1 ? 'disabled' : ''} id="pgPrev">${icon('left', 16)}</button>
      <button ${page >= totalPages ? 'disabled' : ''} id="pgNext">${icon('right', 16)}</button>
    </div>`;
  $('#pgPrev')?.addEventListener('click', () => { page--; render(); });
  $('#pgNext')?.addEventListener('click', () => { page++; render(); });

  $$('#prodTable [data-act]').forEach(btn => btn.addEventListener('click', () => {
    const id = btn.dataset.id, p = pList.find(x => x.id === id);
    if (btn.dataset.act === 'del') {
      confirmAction(`Delete "${p.name}"? This cannot be undone.`, () => { AdminDB.products.remove(id); pList = AdminDB.products.all(); toast('Product deleted'); render(); });
    } else if (btn.dataset.act === 'toggle') {
      p.active = p.active === false ? true : false;
      AdminDB.products.save(p); toast(p.active ? 'Product activated' : 'Product deactivated'); render();
    } else if (btn.dataset.act === 'dup') {
      const copy = { ...p, id: 'p' + Date.now().toString(36), name: p.name + ' (Copy)', sku: p.sku + '-COPY', created: '2026-09-21' };
      AdminDB.products.save(copy); pList = AdminDB.products.all(); toast('Product duplicated'); render();
    }
  }));
}

['fSearch', 'fCategory', 'fBrand', 'fStatus', 'fSort'].forEach(id => {
  $('#' + id).addEventListener('input', () => { page = 1; render(); });
});
$('#btnExport').addEventListener('click', () => toast('CSV export runs server-side once Firebase Cloud Functions are connected.', 'info'));

render();
