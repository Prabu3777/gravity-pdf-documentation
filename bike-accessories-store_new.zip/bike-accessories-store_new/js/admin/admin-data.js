/* admin-data.js — AdminDB: Firestore-backed with an instant localStorage cache.
   Every AdminDB.<entity>.all()/get()/save()/remove() call is still synchronous
   (page code is unchanged from the UI-preview version), but now:
     1. On first load it renders instantly from whatever was cached last time
        (or the seed data below, the very first run).
     2. In the background it fetches the live data from Firestore and updates
        the cache for the NEXT render/page load.
     3. Every save()/remove() updates the cache immediately (so the UI feels
        instant) AND pushes the same change to Firestore in the background,
        so it persists and is visible from any other admin session/device.
   Products, categories, brands, collections, coupons, reviews, faqs, orders,
   customers and settings are fully wired this way. Banners, homepage section
   order, static pages, support tickets and the stock log are still
   local-only — follow the exact same pattern below to finish those. */

const CUSTOMER_NAMES = [
  ['Arjun Kumar', 'arjun.kumar@example.com', '+91 90000 11122', 'Bengaluru'],
  ['Meera Sundaram', 'meera.s@example.com', '+91 90000 22233', 'Pune'],
  ['Rahul Dev', 'rahul.dev@example.com', '+91 90000 33344', 'Chennai'],
  ['Sanjay Patil', 'sanjay.p@example.com', '+91 90000 44455', 'Hyderabad'],
  ['Divya Ramesh', 'divya.r@example.com', '+91 90000 55566', 'Kochi'],
  ['Vikram Singh', 'vikram.singh@example.com', '+91 90000 66677', 'Delhi'],
  ['Ananya Iyer', 'ananya.iyer@example.com', '+91 90000 77788', 'Mumbai'],
  ['Karthik Raja', 'karthik.raja@example.com', '+91 90000 88899', 'Coimbatore'],
  ['Priya Nair', 'priya.nair@example.com', '+91 90000 99900', 'Trivandrum'],
  ['Farhan Sheikh', 'farhan.sheikh@example.com', '+91 90000 10101', 'Hyderabad']
];

const ADMIN_ORDER_STATUSES = ['Pending', 'Confirmed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered', 'Cancelled', 'Returned', 'Refunded'];
const PAYMENT_METHODS = ['UPI', 'Card', 'Net Banking', 'Wallet'];

function seedOrders() {
  const statusPool = ['Delivered', 'Delivered', 'Shipped', 'Confirmed', 'Pending', 'Out for Delivery', 'Delivered', 'Cancelled', 'Packed', 'Delivered', 'Returned', 'Delivered', 'Confirmed', 'Delivered', 'Pending'];
  const out = [];
  for (let i = 0; i < 15; i++) {
    const cust = CUSTOMER_NAMES[i % CUSTOMER_NAMES.length];
    const n1 = PRODUCTS[(i * 3) % PRODUCTS.length], n2 = PRODUCTS[(i * 7 + 2) % PRODUCTS.length];
    const items = [
      { id: n1.id, name: n1.name, sku: n1.sku, variant: n1.opts[0] || '-', qty: 1 + (i % 2), price: n1.price, image: imgSrc(n1) }
    ];
    if (i % 3 !== 0) items.push({ id: n2.id, name: n2.name, sku: n2.sku, variant: n2.opts[0] || '-', qty: 1, price: n2.price, image: imgSrc(n2) });
    const subtotal = items.reduce((s, it) => s + it.price * it.qty, 0);
    const discount = i % 4 === 0 ? Math.round(subtotal * 0.1) : 0;
    const shipping = subtotal > 2000 ? 0 : 99;
    const tax = Math.round((subtotal - discount) * 0.02);
    const total = subtotal - discount + shipping + tax;
    const day = 21 - i;
    const status = statusPool[i];
    out.push({
      id: 'ord' + (i + 1),
      orderNumber: 'AT-' + (100500 + i * 7),
      customer: { name: cust[0], email: cust[1], phone: cust[2] },
      items, subtotal, discount, tax, shipping, total,
      couponCode: discount ? 'RIDE10' : '',
      paymentMethod: PAYMENT_METHODS[i % PAYMENT_METHODS.length],
      paymentStatus: status === 'Cancelled' ? 'Refunded' : (status === 'Pending' ? 'Pending' : 'Paid'),
      razorpayOrderId: 'order_' + Math.random().toString(36).slice(2, 12),
      razorpayPaymentId: status === 'Pending' ? '' : 'pay_' + Math.random().toString(36).slice(2, 12),
      orderStatus: status,
      shippingAddress: { name: cust[0], phone: cust[2], line: 'Address line, ' + cust[3], city: cust[3], state: '-', pin: '600001', country: 'India' },
      createdAt: '2026-09-' + String(Math.max(1, day)).padStart(2, '0'),
      updatedAt: '2026-09-' + String(Math.max(1, day)).padStart(2, '0')
    });
  }
  return out;
}

function seedCustomers(orders) {
  return CUSTOMER_NAMES.map((c, i) => {
    const myOrders = orders.filter(o => o.customer.email === c[1]);
    return {
      id: 'cust' + (i + 1), name: c[0], email: c[1], phone: c[2], city: c[3],
      orders: myOrders.length,
      totalSpent: myOrders.reduce((s, o) => s + o.total, 0),
      joined: '2026-0' + (2 + (i % 6)) + '-1' + (i % 9),
      status: i === 9 ? 'Blocked' : 'Active'
    };
  });
}

function seedCoupons() {
  return [
    { id: 'cp1', code: 'RIDE10', type: 'Percentage', value: 10, minOrder: 1999, maxDiscount: 800, start: '2026-09-01', end: '2026-10-31', usageLimit: 500, used: 214, active: true },
    { id: 'cp2', code: 'MONSOON300', type: 'Fixed', value: 300, minOrder: 2499, maxDiscount: 300, start: '2026-08-15', end: '2026-09-30', usageLimit: 300, used: 187, active: true },
    { id: 'cp3', code: 'WELCOME150', type: 'Fixed', value: 150, minOrder: 999, maxDiscount: 150, start: '2026-01-01', end: '2026-12-31', usageLimit: 1000, used: 642, active: true },
    { id: 'cp4', code: 'TOURING15', type: 'Percentage', value: 15, minOrder: 4999, maxDiscount: 1500, start: '2026-06-01', end: '2026-09-15', usageLimit: 200, used: 200, active: false }
  ];
}

function seedBanners() {
  return [
    { id: 'bn1', title: 'Monsoon Ready Gear', subtitle: 'Rain suits, covers and lights — up to 30% off', image: 'assets/hero-banner.png', btnText: 'Shop the edit', btnUrl: 'shop.html?collection=monsoon-ready', start: '2026-08-01', end: '2026-09-30', active: true },
    { id: 'bn2', title: 'Adventure Touring Week', subtitle: 'Boots, pants and panniers for the long haul', image: 'assets/hero-banner.png', btnText: 'Explore touring', btnUrl: 'shop.html?collection=adventure-touring', start: '2026-09-10', end: '2026-09-25', active: true },
    { id: 'bn3', title: 'New Season Helmets', subtitle: 'Introducing the Voyager Modular range', image: 'assets/hero-banner.png', btnText: 'View helmets', btnUrl: 'shop.html?cat=helmets', start: '2026-07-01', end: '2026-08-15', active: false }
  ];
}

function seedHomepageSections() {
  return [
    { id: 'hero', name: 'Hero banner', enabled: true, order: 1 },
    { id: 'categories', name: 'Shop by category', enabled: true, order: 2 },
    { id: 'featured', name: 'Featured products', enabled: true, order: 3 },
    { id: 'new-arrivals', name: 'New arrivals', enabled: true, order: 4 },
    { id: 'best-sellers', name: 'Best sellers', enabled: true, order: 5 },
    { id: 'collections', name: 'Travel collections', enabled: true, order: 6 },
    { id: 'promo', name: 'Promotional banner', enabled: true, order: 7 },
    { id: 'why-us', name: 'Why choose us', enabled: true, order: 8 },
    { id: 'reviews', name: 'Customer reviews', enabled: true, order: 9 },
    { id: 'newsletter', name: 'Newsletter', enabled: true, order: 10 }
  ];
}

function seedPages() {
  return [
    { id: 'about', title: 'About Us', slug: 'about', updated: '2026-08-12', body: 'TN11 BIKERZZ makes travel, riding and touring gear tested on real Indian roads...' },
    { id: 'privacy', title: 'Privacy Policy', slug: 'privacy-policy', updated: '2026-06-02', body: 'We collect only the information needed to process your orders and improve your experience...' },
    { id: 'terms', title: 'Terms & Conditions', slug: 'terms', updated: '2026-06-02', body: 'By using this website you agree to the following terms...' },
    { id: 'shipping', title: 'Shipping Policy', slug: 'shipping-policy', updated: '2026-07-20', body: 'Most orders reach metro cities in 2 to 4 working days...' },
    { id: 'refund', title: 'Refund Policy', slug: 'refund-policy', updated: '2026-07-20', body: 'Refunds are processed to the original payment method within 5 to 7 working days...' },
    { id: 'return', title: 'Return Policy', slug: 'return-policy', updated: '2026-07-20', body: 'Unused items in original packaging can be returned within 7 days of delivery...' }
  ];
}

function seedTickets() {
  return [
    { id: 'tk1', name: 'Arjun Kumar', email: 'arjun.kumar@example.com', phone: '+91 90000 11122', subject: 'Wrong size delivered', message: 'I ordered L but got M for the Expedition Riding Jacket.', status: 'Open', date: '2026-09-20', reply: '' },
    { id: 'tk2', name: 'Meera Sundaram', email: 'meera.s@example.com', phone: '+91 90000 22233', subject: 'Refund not received', message: 'Order AT-100517 was cancelled 6 days ago, refund not yet credited.', status: 'In Progress', date: '2026-09-18', reply: 'Refund initiated, please allow 3-5 more business days.' },
    { id: 'tk3', name: 'Rahul Dev', email: 'rahul.dev@example.com', phone: '+91 90000 33344', subject: 'Helmet visor question', message: 'Does the Voyager Modular Helmet support Pinlock inserts out of the box?', status: 'Resolved', date: '2026-09-14', reply: 'Yes, it ships Pinlock-ready with a clear insert included.' },
    { id: 'tk4', name: 'Sanjay Patil', email: 'sanjay.p@example.com', phone: '+91 90000 44455', subject: 'Bulk order for riding club', message: 'We need 12 jackets for our riding club, is a bulk discount available?', status: 'Open', date: '2026-09-21', reply: '' },
    { id: 'tk5', name: 'Divya Ramesh', email: 'divya.r@example.com', phone: '+91 90000 55566', subject: 'Tracking not updating', message: 'AT-100482 tracking has been stuck at Packed for 3 days.', status: 'Closed', date: '2026-09-09', reply: 'Resolved — courier scan delay, order was delivered on 12 Sep.' }
  ];
}

function seedSettings() {
  return {
    storeName: 'TN11 BIKERZZ', email: 'hello@tn11bikerzz.com', phone: '+91 90000 00000',
    address: 'Store address, City, Tamil Nadu - PIN', currency: 'INR (₹)',
    taxPercent: 2, shippingCharge: 99, freeShippingThreshold: 2000,
    returnDays: 7, refundDays: 6,
    instagram: 'https://instagram.com/tn11bikerzz', youtube: 'https://youtube.com/@tn11bikerzz', facebook: 'https://facebook.com/tn11bikerzz'
  };
}

function seedStockLog() {
  return [
    { id: 'sl1', product: 'Ridgeline Full-Face Helmet', sku: 'AT-HEL-102', type: 'Sale', change: -2, note: 'Order AT-100517', date: '2026-09-17' },
    { id: 'sl2', product: 'Voyager Modular Helmet', sku: 'AT-HEL-101', type: 'Restock', change: 20, note: 'Supplier PO #3311', date: '2026-09-10' },
    { id: 'sl3', product: 'Hydra Hydration Pack', sku: 'AT-BAC-119', type: 'Adjustment', change: -3, note: 'Damaged in warehouse', date: '2026-09-08' },
    { id: 'sl4', product: 'Ridge Mesh Riding Gloves', sku: 'AT-GLO-105', type: 'Sale', change: -5, note: 'Multiple orders', date: '2026-09-15' }
  ];
}

/* ---------- date helpers: Firestore Timestamp <-> the 'YYYY-MM-DD' strings the UI uses ---------- */
function tsToStr(ts) { try { return (ts && ts.toDate ? ts.toDate() : new Date(ts)).toISOString().slice(0, 10); } catch (e) { return ''; } }
function strToTs(str) { try { return firebase.firestore.Timestamp.fromDate(new Date(str)); } catch (e) { return null; } }

/* ---------- Persistence layer ---------- */
const AdminDB = (() => {
  function ensure(key, seedFn) {
    let v = Store.get(key, null);
    if (!v) { v = seedFn(); Store.set(key, v); }
    return v;
  }
  const _orders = ensure('adm_orders', seedOrders);
  const _customers = ensure('adm_customers', () => seedCustomers(_orders));
  const _coupons = ensure('adm_coupons', seedCoupons);
  const _banners = ensure('adm_banners', seedBanners);
  const _homepage = ensure('adm_homepage', seedHomepageSections);
  const _pages = ensure('adm_pages', seedPages);
  const _tickets = ensure('adm_tickets', seedTickets);
  const _settings = ensure('adm_settings', seedSettings);
  const _stockLog = ensure('adm_stocklog', seedStockLog);
  const _products = ensure('adm_products', () => PRODUCTS.map(p => ({ ...p })));
  const _categories = ensure('adm_categories', () => CATEGORIES.map(c => ({ ...c, active: true })));
  const _brands = ensure('adm_brands', () => BRANDS.map(b => ({ ...b, logo: '', website: '', active: true })));
  const _collections = ensure('adm_collections', () => COLLECTIONS.map(c => ({ ...c, active: true })));
  const _reviews = ensure('adm_reviews', () => REVIEWS.map((r, i) => ({ ...r, id: 'rv' + (i + 1), status: i === 4 ? 'Pending' : 'Approved', featured: i < 2 })));
  const _faqs = ensure('adm_faqs', () => FAQS.map((f, i) => ({ ...f, id: 'fq' + (i + 1), active: true, order: i + 1 })));

  function save(key, val) { Store.set(key, val); }

  /* Best-effort Firestore push. Never blocks the UI — failures just toast. */
  function remoteWrite(promise, label) {
    if (typeof db === 'undefined') return; // firebase-config.js not loaded on this page yet
    Promise.resolve(promise).catch(err => { console.error(label, err); toast('Saved locally, but could not sync to the server: ' + (err.message || label), 'error'); });
  }

  return {
    products: {
      all: () => _products,
      get: id => _products.find(p => p.id === id),
      save: p => {
        const i = _products.findIndex(x => x.id === p.id);
        if (i > -1) _products[i] = p; else _products.unshift(p);
        save('adm_products', _products);
        remoteWrite(db?.collection('products').doc(p.id).set({
          ...p, brandId: p.brand, categoryId: p.cat, sellingPrice: p.price, lowStockThreshold: p.low,
          images: p.images || [], specifications: p.specifications || {}, updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        }, { merge: true }), 'product save');
      },
      remove: id => { const i = _products.findIndex(x => x.id === id); if (i > -1) _products.splice(i, 1); save('adm_products', _products); remoteWrite(db?.collection('products').doc(id).delete(), 'product delete'); }
    },
    categories: {
      all: () => _categories,
      save: c => { const i = _categories.findIndex(x => x.id === c.id); if (i > -1) _categories[i] = c; else _categories.unshift(c); save('adm_categories', _categories); remoteWrite(db?.collection('categories').doc(c.id).set(c, { merge: true }), 'category save'); },
      remove: id => { const i = _categories.findIndex(x => x.id === id); if (i > -1) _categories.splice(i, 1); save('adm_categories', _categories); remoteWrite(db?.collection('categories').doc(id).delete(), 'category delete'); }
    },
    brands: {
      all: () => _brands,
      save: b => { const i = _brands.findIndex(x => x.id === b.id); if (i > -1) _brands[i] = b; else _brands.unshift(b); save('adm_brands', _brands); remoteWrite(db?.collection('brands').doc(b.id).set(b, { merge: true }), 'brand save'); },
      remove: id => { const i = _brands.findIndex(x => x.id === id); if (i > -1) _brands.splice(i, 1); save('adm_brands', _brands); remoteWrite(db?.collection('brands').doc(id).delete(), 'brand delete'); }
    },
    collections: {
      all: () => _collections,
      save: c => { const i = _collections.findIndex(x => x.id === c.id); if (i > -1) _collections[i] = c; else _collections.unshift(c); save('adm_collections', _collections); remoteWrite(db?.collection('collections').doc(c.id).set(c, { merge: true }), 'collection save'); },
      remove: id => { const i = _collections.findIndex(x => x.id === id); if (i > -1) _collections.splice(i, 1); save('adm_collections', _collections); remoteWrite(db?.collection('collections').doc(id).delete(), 'collection delete'); }
    },
    orders: {
      all: () => _orders,
      get: id => _orders.find(o => o.id === id),
      save: o => {
        const i = _orders.findIndex(x => x.id === o.id); if (i > -1) _orders[i] = o; save('adm_orders', _orders);
        // Only push if this order came from Firestore (real id) — demo 'ordN' ids have nothing to sync to.
        if (!/^ord\d+$/.test(o.id)) remoteWrite(db?.collection('orders').doc(o.id).update({ orderStatus: o.orderStatus, updatedAt: firebase.firestore.FieldValue.serverTimestamp() }), 'order status update');
      }
    },
    customers: { all: () => _customers, get: id => _customers.find(c => c.id === id), save: c => { const i = _customers.findIndex(x => x.id === c.id); if (i > -1) _customers[i] = c; save('adm_customers', _customers); if (!/^cust\d+$/.test(c.id)) remoteWrite(db?.collection('users').doc(c.id).set({ status: c.status }, { merge: true }), 'customer status update'); } },
    coupons: {
      all: () => _coupons,
      save: c => {
        const i = _coupons.findIndex(x => x.id === c.id); if (i > -1) _coupons[i] = c; else _coupons.unshift(c); save('adm_coupons', _coupons);
        remoteWrite(db?.collection('coupons').doc(c.code).set({
          type: c.type === 'Percentage' ? 'percent' : 'fixed', value: c.value, minOrder: c.minOrder, maxDiscount: c.maxDiscount,
          startDate: strToTs(c.start), endDate: strToTs(c.end), usageLimit: c.usageLimit, usedCount: c.used || 0, active: c.active, label: c.code
        }), 'coupon save');
      },
      remove: id => { const c = _coupons.find(x => x.id === id); const i = _coupons.findIndex(x => x.id === id); if (i > -1) _coupons.splice(i, 1); save('adm_coupons', _coupons); if (c) remoteWrite(db?.collection('coupons').doc(c.code).delete(), 'coupon delete'); }
    },
    reviews: {
      all: () => _reviews,
      save: r => {
        const i = _reviews.findIndex(x => x.id === r.id); if (i > -1) _reviews[i] = r; save('adm_reviews', _reviews);
        if (!/^rv\d+$/.test(r.id)) remoteWrite(db?.collection('reviews').doc(r.id).update({ status: r.status === 'Approved' ? 'approved' : (r.status === 'Hidden' ? 'hidden' : 'pending'), featured: !!r.featured }), 'review moderate');
      },
      remove: id => { const i = _reviews.findIndex(x => x.id === id); if (i > -1) _reviews.splice(i, 1); save('adm_reviews', _reviews); remoteWrite(db?.collection('reviews').doc(id).delete(), 'review delete'); }
    },
    banners: {
      all: () => _banners,
      save: b => { const i = _banners.findIndex(x => x.id === b.id); if (i > -1) _banners[i] = b; else _banners.unshift(b); save('adm_banners', _banners); remoteWrite(db?.collection('banners').doc(b.id).set(b, { merge: true }), 'banner save'); },
      remove: id => { const i = _banners.findIndex(x => x.id === id); if (i > -1) _banners.splice(i, 1); save('adm_banners', _banners); remoteWrite(db?.collection('banners').doc(id).delete(), 'banner delete'); }
    },
    homepage: { all: () => _homepage, save: list => { save('adm_homepage', list); remoteWrite(db?.collection('settings').doc('homepage').set({ sections: list }), 'homepage sections save'); } },
    pages: {
      all: () => _pages, get: id => _pages.find(p => p.id === id),
      save: p => { const i = _pages.findIndex(x => x.id === p.id); if (i > -1) _pages[i] = p; save('adm_pages', _pages); remoteWrite(db?.collection('pages').doc(p.id).set(p, { merge: true }), 'page save'); }
    },
    faqs: {
      all: () => _faqs,
      save: f => { const i = _faqs.findIndex(x => x.id === f.id); if (i > -1) _faqs[i] = f; else _faqs.unshift(f); save('adm_faqs', _faqs); remoteWrite(db?.collection('faqs').doc(f.id).set(f, { merge: true }), 'faq save'); },
      remove: id => { const i = _faqs.findIndex(x => x.id === id); if (i > -1) _faqs.splice(i, 1); save('adm_faqs', _faqs); remoteWrite(db?.collection('faqs').doc(id).delete(), 'faq delete'); }
    },
    tickets: { all: () => _tickets, get: id => _tickets.find(t => t.id === id), save: t => { const i = _tickets.findIndex(x => x.id === t.id); if (i > -1) _tickets[i] = t; save('adm_tickets', _tickets); if (!/^tk\d+$/.test(t.id)) remoteWrite(db?.collection('supportTickets').doc(t.id).update({ status: t.status, reply: t.reply }), 'ticket update'); } },
    settings: { get: () => _settings, save: s => { Object.assign(_settings, s); save('adm_settings', _settings); remoteWrite(db?.collection('settings').doc('store').set(s, { merge: true }), 'settings save'); } },
    stockLog: { all: () => _stockLog, add: entry => { _stockLog.unshift(entry); save('adm_stocklog', _stockLog); } },
    resetAll: () => { ['adm_orders', 'adm_customers', 'adm_coupons', 'adm_banners', 'adm_homepage', 'adm_pages', 'adm_tickets', 'adm_settings', 'adm_stocklog', 'adm_products', 'adm_categories', 'adm_brands', 'adm_collections', 'adm_reviews', 'adm_faqs'].forEach(k => Store.del(k)); location.reload(); },

    /* Pulls fresh data from Firestore into the cache above, in place, so any
       already-captured reference (e.g. `let list = AdminDB.products.all()`)
       updates too. Runs once automatically below; safe to call again. */
    async syncFromFirestore() {
      if (typeof db === 'undefined') return;
      try {
        const [prodSnap, catSnap, brandSnap, collSnap, couponSnap, reviewSnap, faqSnap, orderSnap, userSnap, settingsDoc, bannerSnap, pageSnap, homeDoc, ticketSnap] = await Promise.all([
          db.collection('products').get(), db.collection('categories').get(), db.collection('brands').get(),
          db.collection('collections').get(), db.collection('coupons').get(), db.collection('reviews').get(),
          db.collection('faqs').get(), db.collection('orders').orderBy('createdAt', 'desc').limit(200).get(),
          db.collection('users').get(), db.collection('settings').doc('store').get(),
          db.collection('banners').get(), db.collection('pages').get(), db.collection('settings').doc('homepage').get(),
          db.collection('supportTickets').orderBy('createdAt', 'desc').limit(200).get()
        ]);

        if (!prodSnap.empty) { _products.length = 0; prodSnap.forEach(d => _products.push({ ...d.data(), id: d.id })); save('adm_products', _products); }
        if (!catSnap.empty) { _categories.length = 0; catSnap.forEach(d => _categories.push({ ...d.data(), id: d.id })); save('adm_categories', _categories); }
        if (!brandSnap.empty) { _brands.length = 0; brandSnap.forEach(d => _brands.push({ ...d.data(), id: d.id })); save('adm_brands', _brands); }
        if (!collSnap.empty) { _collections.length = 0; collSnap.forEach(d => _collections.push({ ...d.data(), id: d.id })); save('adm_collections', _collections); }
        if (!faqSnap.empty) { _faqs.length = 0; faqSnap.forEach(d => _faqs.push({ ...d.data(), id: d.id })); save('adm_faqs', _faqs); }
        if (settingsDoc.exists) { Object.assign(_settings, settingsDoc.data()); save('adm_settings', _settings); }
        if (!bannerSnap.empty) { _banners.length = 0; bannerSnap.forEach(d => _banners.push({ ...d.data(), id: d.id })); save('adm_banners', _banners); }
        if (!pageSnap.empty) { _pages.length = 0; pageSnap.forEach(d => _pages.push({ ...d.data(), id: d.id })); save('adm_pages', _pages); }
        if (homeDoc.exists && homeDoc.data().sections) { _homepage.length = 0; homeDoc.data().sections.forEach(s => _homepage.push(s)); save('adm_homepage', _homepage); }
        if (!ticketSnap.empty) {
          _tickets.length = 0;
          ticketSnap.forEach(d => { const t = d.data(); _tickets.push({ id: d.id, name: t.name, email: t.email, phone: t.phone, subject: t.subject, message: t.message, status: t.status, reply: t.reply || '', date: tsToStr(t.createdAt) }); });
          save('adm_tickets', _tickets);
        }

        if (!couponSnap.empty) {
          _coupons.length = 0;
          couponSnap.forEach(d => { const c = d.data(); _coupons.push({ id: d.id, code: d.id, type: c.type === 'percent' ? 'Percentage' : 'Fixed', value: c.value, minOrder: c.minOrder || 0, maxDiscount: c.maxDiscount || 0, start: tsToStr(c.startDate) || '', end: tsToStr(c.endDate) || '', usageLimit: c.usageLimit || 0, used: c.usedCount || 0, active: c.active !== false }); });
          save('adm_coupons', _coupons);
        }

        if (!reviewSnap.empty) {
          _reviews.length = 0;
          reviewSnap.forEach(d => { const r = d.data(); const p = getProduct(r.productId); _reviews.push({ id: d.id, product: r.productId, name: r.name || 'Rider', rating: r.rating, title: r.title || '', text: r.text || '', date: tsToStr(r.createdAt), verified: !!r.verified, featured: !!r.featured, status: r.status === 'approved' ? 'Approved' : (r.status === 'hidden' ? 'Hidden' : 'Pending') }); });
          save('adm_reviews', _reviews);
        }

        const usersById = {}; userSnap.forEach(d => usersById[d.id] = d.data());
        if (!orderSnap.empty) {
          _orders.length = 0;
          orderSnap.forEach(d => {
            const o = d.data(); const u = usersById[o.userId] || {};
            _orders.push({
              id: d.id, orderNumber: o.orderNumber, customer: { name: u.name || 'Customer', email: u.email || '', phone: u.phone || '' },
              items: (o.items || []).map(it => ({ id: it.productId, name: it.name, sku: it.sku, variant: it.variant, qty: it.qty, price: it.unitPrice, image: it.image })),
              subtotal: o.subtotal, discount: o.discount || 0, tax: o.tax, shipping: o.shipping, total: o.total,
              couponCode: o.coupon || '', paymentMethod: 'Online', paymentStatus: o.paymentStatus, orderStatus: o.orderStatus,
              razorpayOrderId: o.razorpayOrderId || '', razorpayPaymentId: o.razorpayPaymentId || '',
              shippingAddress: o.shippingAddress || {}, createdAt: tsToStr(o.createdAt), updatedAt: tsToStr(o.updatedAt), userId: o.userId
            });
          });
          save('adm_orders', _orders);

          _customers.length = 0;
          userSnap.forEach(d => {
            const u = d.data(); if (u.role === 'admin') return;
            const myOrders = _orders.filter(o => o.userId === d.id);
            _customers.push({ id: d.id, name: u.name || 'Customer', email: u.email || '', phone: u.phone || '', city: u.city || '', orders: myOrders.length, totalSpent: myOrders.reduce((s, o) => s + (o.total || 0), 0), joined: tsToStr(u.createdAt), status: u.status || 'Active' });
          });
          save('adm_customers', _customers);
        }
      } catch (err) { console.error('AdminDB Firestore sync failed — showing cached data.', err); }
    }
  };
})();

if (typeof db !== 'undefined') AdminDB.syncPromise = AdminDB.syncFromFirestore();
