initAdminPage('homepage', 'Homepage');

function renderSections() {
  const list = AdminDB.homepage.all().slice().sort((a, b) => a.order - b.order);
  $('#sectionList').innerHTML = list.map((s, i) => `
    <div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border)">
      <span class="muted" style="cursor:grab">${icon('drag', 16)}</span>
      <span style="flex:1">${esc(s.name)}</span>
      ${i > 0 ? `<button class="icon-btn btn-icon-only" data-up="${s.id}" title="Move up">${icon('up', 15)}</button>` : '<span style="width:38px"></span>'}
      ${i < list.length - 1 ? `<button class="icon-btn btn-icon-only" data-down="${s.id}" title="Move down">${icon('down', 15)}</button>` : '<span style="width:38px"></span>'}
      <label class="switch"><input type="checkbox" data-toggle="${s.id}" ${s.enabled ? 'checked' : ''}><span class="switch-track"></span></label>
    </div>`).join('');

  $$('#sectionList [data-toggle]').forEach(inp => inp.addEventListener('change', () => {
    const list2 = AdminDB.homepage.all(); const s = list2.find(x => x.id === inp.dataset.toggle); s.enabled = inp.checked;
    AdminDB.homepage.save(list2); toast(s.name + (s.enabled ? ' enabled' : ' disabled'));
  }));
  $$('#sectionList [data-up]').forEach(b => b.addEventListener('click', () => move(b.dataset.up, -1)));
  $$('#sectionList [data-down]').forEach(b => b.addEventListener('click', () => move(b.dataset.down, 1)));
}
function move(id, dir) {
  const list = AdminDB.homepage.all().slice().sort((a, b) => a.order - b.order);
  const i = list.findIndex(s => s.id === id), j = i + dir;
  if (j < 0 || j >= list.length) return;
  [list[i].order, list[j].order] = [list[j].order, list[i].order];
  AdminDB.homepage.save(list); renderSections();
}
$('#h-save').addEventListener('click', () => toast('Hero content saved'));
renderSections();
