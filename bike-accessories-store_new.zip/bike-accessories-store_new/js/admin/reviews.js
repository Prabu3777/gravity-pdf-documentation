initAdminPage('reviews', 'Reviews');

function render() {
  const status = $('#rvStatus').value;
  const list = AdminDB.reviews.all().filter(r => !status || r.status === status);
  $('#rvTable').innerHTML = `
    <thead><tr><th>Product</th><th>Customer</th><th>Rating</th><th>Review</th><th>Date</th><th>Status</th><th></th></tr></thead>
    <tbody>${list.map(r => { const p = getProduct(r.product); return `
      <tr>
        <td class="cell-sub">${p ? esc(p.name) : r.product}</td>
        <td>${esc(r.name)} ${r.verified ? '<span class="pill pill-info" style="margin-left:4px">Verified</span>' : ''}</td>
        <td>${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</td>
        <td class="cell-sub" style="max-width:320px"><strong>${esc(r.title)}</strong><br>${esc(r.text)}</td>
        <td>${r.date}</td>
        <td>${statusPill(r.status)}${r.featured ? ' <span class="pill pill-info">Featured</span>' : ''}</td>
        <td>
          <div class="row-actions">
            ${r.status !== 'Approved' ? `<button class="icon-btn btn-icon-only" data-act="approve" data-id="${r.id}" title="Approve">${icon('check', 17)}</button>` : ''}
            ${r.status !== 'Hidden' ? `<button class="icon-btn btn-icon-only" data-act="hide" data-id="${r.id}" title="Hide">${icon('x', 17)}</button>` : ''}
            <button class="icon-btn btn-icon-only" data-act="feature" data-id="${r.id}" title="${r.featured ? 'Unfeature' : 'Feature'}">${icon('star', 17)}</button>
            <button class="icon-btn btn-icon-only" data-act="del" data-id="${r.id}" title="Delete">${icon('trash', 17)}</button>
          </div>
        </td>
      </tr>`; }).join('') || '<tr><td colspan="7" class="admin-empty">No reviews match this filter.</td></tr>'}</tbody>`;

  $$('#rvTable [data-act]').forEach(b => b.addEventListener('click', () => {
    const r = AdminDB.reviews.all().find(x => x.id === b.dataset.id);
    if (b.dataset.act === 'approve') { r.status = 'Approved'; AdminDB.reviews.save(r); toast('Review approved'); }
    if (b.dataset.act === 'hide') { r.status = 'Hidden'; AdminDB.reviews.save(r); toast('Review hidden'); }
    if (b.dataset.act === 'feature') { r.featured = !r.featured; AdminDB.reviews.save(r); toast(r.featured ? 'Review featured' : 'Review unfeatured'); }
    if (b.dataset.act === 'del') { confirmAction('Delete this review permanently?', () => { AdminDB.reviews.remove(r.id); toast('Review deleted'); render(); }); return; }
    render();
  }));
}
$('#rvStatus').addEventListener('change', render);
render();
