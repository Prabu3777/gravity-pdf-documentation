initAdminPage('inventory', 'Inventory');
$('#invSearchIco').innerHTML = icon('search', 16);

function renderStats() {
  const products = AdminDB.products.all();
  const inStock = products.filter(p => p.stock > (p.low || 5)).length;
  const low = products.filter(p => p.stock > 0 && p.stock <= (p.low || 5)).length;
  const out = products.filter(p => p.stock <= 0).length;
  const totalUnits = products.reduce((s, p) => s + p.stock, 0);
  $('#invStats').innerHTML = [
    { l: 'Total stock units', v: totalUnits, i: 'package' },
    { l: 'In stock products', v: inStock, i: 'check' },
    { l: 'Low stock products', v: low, i: 'clock' },
    { l: 'Out of stock products', v: out, i: 'x' }
  ].map(s => `<div class="stat-card"><div class="stat-card-top"><span class="stat-card-ico">${icon(s.i, 18)}</span></div><div class="stat-value">${s.v}</div><div class="stat-label">${s.l}</div></div>`).join('');
}

function renderTable() {
  const q = $('#invSearch').value.trim().toLowerCase(), status = $('#invStatus').value;
  let list = AdminDB.products.all().filter(p => {
    if (q && !(p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q))) return false;
    if (status === 'in' && p.stock <= (p.low || 5)) return false;
    if (status === 'low' && !(p.stock > 0 && p.stock <= (p.low || 5))) return false;
    if (status === 'out' && p.stock > 0) return false;
    return true;
  });
  $('#invTable').innerHTML = `
    <thead><tr><th>Product</th><th>SKU</th><th>Stock</th><th>Reserved</th><th>Available</th><th>Threshold</th><th>Status</th><th></th></tr></thead>
    <tbody>${list.map(p => {
      const reserved = 0;
      return `<tr>
        <td class="cell-main"><img class="cell-img" src="${imgSrc(p)}" alt=""><span class="cell-title">${esc(p.name)}</span></td>
        <td>${p.sku}</td>
        <td>${p.stock}</td>
        <td>${reserved}</td>
        <td>${p.stock - reserved}</td>
        <td>${p.low || 5}</td>
        <td>${p.stock <= 0 ? '<span class="pill pill-bad">Out of stock</span>' : p.stock <= (p.low || 5) ? '<span class="pill pill-warn">Low stock</span>' : '<span class="pill pill-good">In stock</span>'}</td>
        <td><button class="btn btn-outline btn-sm" data-adj="${p.id}">Adjust stock</button></td>
      </tr>`;
    }).join('') || '<tr><td colspan="8" class="admin-empty">No products match.</td></tr>'}</tbody>`;
  $$('#invTable [data-adj]').forEach(b => b.addEventListener('click', () => openAdjust(b.dataset.adj)));
}

function openAdjust(id) {
  const p = AdminDB.products.get(id);
  const { close } = Modal.open(`
    <div class="admin-card-body">
      <h2 style="margin-bottom:4px">Adjust stock</h2>
      <p class="muted small" style="margin-bottom:16px">${esc(p.name)} · current stock ${p.stock}</p>
      <div class="form-grid" style="margin-bottom:14px">
        <div class="form-field"><label>Action</label><select id="m-type"><option value="Restock">Add stock</option><option value="Adjustment">Remove stock</option><option value="Adjustment">Correction</option></select></div>
        <div class="form-field"><label>Quantity</label><input type="number" id="m-qty" min="1" value="1"></div>
      </div>
      <div class="form-field" style="margin-bottom:16px"><label>Note</label><input type="text" id="m-note" placeholder="Reason for this adjustment"></div>
      <div style="display:flex;gap:10px;justify-content:flex-end"><button class="btn btn-outline" id="m-cancel" type="button">Cancel</button><button class="btn btn-primary" id="m-save" type="button">Save</button></div>
    </div>`, { label: 'Adjust stock' });
  $('#m-cancel').addEventListener('click', close);
  $('#m-save').addEventListener('click', () => {
    const qty = Number($('#m-qty').value) || 0;
    const isAdd = $('#m-type').value === 'Restock';
    const change = isAdd ? qty : -qty;
    p.stock = Math.max(0, p.stock + change);
    AdminDB.products.save(p);
    AdminDB.stockLog.add({ id: 'sl' + Date.now().toString(36), product: p.name, sku: p.sku, type: isAdd ? 'Restock' : 'Adjustment', change, note: $('#m-note').value.trim() || (isAdd ? 'Manual restock' : 'Manual adjustment'), date: '2026-09-21' });
    toast('Stock updated'); close(); renderStats(); renderTable(); renderLog();
  });
}

function renderLog() {
  const log = AdminDB.stockLog.all();
  $('#invLog').innerHTML = `
    <thead><tr><th>Product</th><th>SKU</th><th>Type</th><th>Change</th><th>Note</th><th>Date</th></tr></thead>
    <tbody>${log.slice(0, 12).map(l => `
      <tr><td class="cell-title">${esc(l.product)}</td><td>${l.sku}</td><td>${l.type}</td><td style="color:${l.change < 0 ? 'var(--rust)' : 'var(--good)'}">${l.change > 0 ? '+' : ''}${l.change}</td><td class="cell-sub">${esc(l.note)}</td><td>${l.date}</td></tr>`).join('')}</tbody>`;
}

$('#invSearch').addEventListener('input', renderTable);
$('#invStatus').addEventListener('change', renderTable);
renderStats(); renderTable(); renderLog();
