/* admin-common.js — renders the sidebar + topbar shell into every admin page
   and wires up the interactions common to all of them (mobile nav, theme
   toggle, user menu, logout, notification badges from live demo data). */

const ADMIN_NAV = [
  { label: 'Overview', items: [
    { id: 'dashboard', label: 'Dashboard', icon: 'dashboard', href: 'index.html' }
  ]},
  { label: 'Catalog', items: [
    { id: 'products', label: 'Products', icon: 'tag', href: 'products.html' },
    { id: 'categories', label: 'Categories', icon: 'grid', href: 'categories.html' },
    { id: 'brands', label: 'Brands', icon: 'award', href: 'brands.html' },
    { id: 'collections', label: 'Collections', icon: 'layers', href: 'collections.html' }
  ]},
  { label: 'Stock', items: [
    { id: 'inventory', label: 'Inventory', icon: 'package', href: 'inventory.html', badge: () => AdminDB.products.all().filter(p => p.stock <= (p.low || 5)).length }
  ]},
  { label: 'Sales', items: [
    { id: 'orders', label: 'Orders', icon: 'truck', href: 'orders.html', badge: () => AdminDB.orders.all().filter(o => o.orderStatus === 'Pending').length },
    { id: 'payments', label: 'Payments', icon: 'card', href: 'orders.html?tab=payments' },
    { id: 'customers', label: 'Customers', icon: 'users', href: 'customers.html' }
  ]},
  { label: 'Marketing', items: [
    { id: 'coupons', label: 'Coupons', icon: 'percent', href: 'coupons.html' },
    { id: 'reviews', label: 'Reviews', icon: 'star', href: 'reviews.html', badge: () => AdminDB.reviews.all().filter(r => r.status === 'Pending').length }
  ]},
  { label: 'Content', items: [
    { id: 'banners', label: 'Banners', icon: 'image', href: 'banners.html' },
    { id: 'homepage', label: 'Homepage', icon: 'home', href: 'homepage.html' },
    { id: 'pages', label: 'Pages', icon: 'file', href: 'pages.html' },
    { id: 'faq', label: 'FAQ', icon: 'help', href: 'faq.html' },
    { id: 'support', label: 'Support', icon: 'headset', href: 'support.html', badge: () => AdminDB.tickets.all().filter(t => t.status === 'Open').length }
  ]},
  { label: 'Insights', items: [
    { id: 'analytics', label: 'Analytics', icon: 'chart', href: 'analytics.html' },
    { id: 'settings', label: 'Settings', icon: 'settings', href: 'settings.html' }
  ]}
];

function renderAdminShell(activeId, crumb) {
  const sideEl = $('#admin-sidebar'), topEl = $('#admin-topbar');
  if (!sideEl || !topEl) return;

  sideEl.innerHTML = `
    <div class="admin-brand">
      <img src="../assets/logo.png" alt="">
      <div><strong>TN11 BIKERZZ</strong><span>Admin panel</span></div>
      <button class="icon-btn admin-sidebar-close" aria-label="Close menu">${icon('x')}</button>
    </div>
    <nav class="admin-nav" aria-label="Admin sections">
      ${ADMIN_NAV.map(g => `
        <div class="admin-nav-group">
          <div class="admin-nav-label">${g.label}</div>
          ${g.items.map(it => {
            const count = it.badge ? it.badge() : 0;
            return `<a class="admin-link${it.id === activeId ? ' active' : ''}" href="${it.href}">${icon(it.icon, 18)}<span>${it.label}</span>${count ? `<span class="admin-link-badge">${count}</span>` : ''}</a>`;
          }).join('')}
        </div>`).join('')}
    </nav>
    <div class="admin-sidebar-foot">
      <a class="admin-link" href="../index.html">${icon('arrow', 18, 'ic-flip')}<span>View storefront</span></a>
      <button class="admin-link" id="adm-logout" style="width:100%">${icon('logout', 18)}<span>Logout</span></button>
    </div>`;

  const session = AdminAuth.session();
  const initials = (session && session.name || 'Admin').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
  topEl.innerHTML = `
    <button class="icon-btn admin-menu-btn" id="adm-menu-btn" aria-label="Open menu">${icon('menu')}</button>
    <div class="admin-crumbs"><strong>${crumb || ''}</strong></div>
    <span class="admin-sync-pill" id="adm-sync-pill" title="Data source">${icon('package', 13)}<span>Loading…</span></span>
    <div class="admin-search">${icon('search', 16)}<input type="search" placeholder="Search orders, products, customers…" id="adm-global-search"></div>
    <div class="admin-topbar-actions">
      <button class="icon-btn" id="adm-theme-btn" title="Toggle theme" aria-label="Toggle theme">${icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon')}</button>
      <button class="icon-btn admin-notif-btn" id="adm-notif-btn" title="Notifications" aria-label="Notifications">${icon('bell')}<span class="admin-notif-dot"></span></button>
      <div class="admin-user-menu">
        <button class="admin-user-btn" id="adm-user-btn"><span class="admin-avatar">${initials}</span></button>
        <div class="admin-user-pop" id="adm-user-pop">
          <div style="padding:8px 10px 10px;border-bottom:1px solid var(--border);margin-bottom:4px">
            <div style="font-weight:600;font-size:.88rem">${session ? session.name : 'Store Admin'}</div>
            <div style="font-size:.78rem;color:var(--text-dim)">${session ? session.email : ''}</div>
          </div>
          <a href="settings.html">${icon('settings', 16)}<span>Store settings</span></a>
          <button id="adm-logout-2">${icon('logout', 16)}<span>Logout</span></button>
        </div>
      </div>
    </div>`;

  const overlay = document.createElement('div');
  overlay.className = 'admin-overlay';
  overlay.id = 'adm-overlay';
  document.body.appendChild(overlay);

  const openMenu = () => { sideEl.classList.add('open'); overlay.classList.add('open'); };
  const closeMenu = () => { sideEl.classList.remove('open'); overlay.classList.remove('open'); };
  $('#adm-menu-btn')?.addEventListener('click', openMenu);
  $('.admin-sidebar-close', sideEl)?.addEventListener('click', closeMenu);
  overlay.addEventListener('click', closeMenu);

  $('#adm-theme-btn').addEventListener('click', () => {
    const cur = Theme.get();
    const resolved = document.documentElement.dataset.theme;
    Theme.set(resolved === 'dark' ? 'light' : 'dark');
    $('#adm-theme-btn').innerHTML = icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon');
  });

  $('#adm-user-btn').addEventListener('click', () => $('#adm-user-pop').classList.toggle('open'));
  document.addEventListener('click', e => { if (!e.target.closest('.admin-user-menu')) $('#adm-user-pop')?.classList.remove('open'); });

  const doLogout = () => AdminAuth.logout();
  $('#adm-logout')?.addEventListener('click', doLogout);
  $('#adm-logout-2')?.addEventListener('click', doLogout);

  $('#adm-notif-btn')?.addEventListener('click', () => toast('Low stock: ' + AdminDB.products.all().filter(p => p.stock <= (p.low || 5)).length + ' products need restocking', 'info'));

  $('#adm-global-search')?.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.value.trim()) location.href = 'products.html?q=' + encodeURIComponent(e.target.value.trim());
  });

  const pill = $('#adm-sync-pill');
  if (pill) {
    if (typeof db === 'undefined') { pill.innerHTML = icon('package', 13) + '<span>Offline preview</span>'; pill.classList.add('is-offline'); }
    else if (AdminDB.syncPromise) {
      AdminDB.syncPromise
        .then(() => { pill.innerHTML = icon('check', 13) + '<span>Synced</span>'; pill.classList.add('is-live'); })
        .catch(() => { pill.innerHTML = icon('package', 13) + '<span>Cached data</span>'; pill.classList.add('is-offline'); });
    }
  }
}

function initAdminPage(activeId, crumb) {
  AdminAuth.guard();
  if (!AdminAuth.session()) return;
  renderAdminShell(activeId, crumb);
}

function statusPill(status) {
  const map = { Delivered: 'good', Confirmed: 'info', Packed: 'info', Shipped: 'info', 'Out for Delivery': 'info', Pending: 'warn', Cancelled: 'bad', Returned: 'bad', Refunded: 'neutral', Active: 'good', Blocked: 'bad', Open: 'warn', 'In Progress': 'info', Resolved: 'good', Closed: 'neutral', Approved: 'good', Hidden: 'neutral' };
  return `<span class="pill pill-${map[status] || 'neutral'}">${esc(status)}</span>`;
}
function paymentPill(status) {
  const map = { Paid: 'good', Pending: 'warn', Failed: 'bad', Refunded: 'neutral' };
  return `<span class="pill pill-${map[status] || 'neutral'}">${esc(status)}</span>`;
}
function activePill(isActive) {
  return isActive ? '<span class="pill pill-good">Active</span>' : '<span class="pill pill-neutral">Inactive</span>';
}

function confirmAction(msg, onYes) {
  const { close } = Modal.open(`
    <div class="admin-card-body">
      <h2 style="margin-bottom:8px">Please confirm</h2>
      <p class="muted" style="margin-bottom:20px">${esc(msg)}</p>
      <div style="display:flex;gap:10px;justify-content:flex-end">
        <button class="btn btn-outline" id="cf-no">Cancel</button>
        <button class="btn btn-danger" id="cf-yes">Confirm</button>
      </div>
    </div>`, { label: 'Confirm action' });
  $('#cf-no').addEventListener('click', close);
  $('#cf-yes').addEventListener('click', () => { close(); onYes(); });
}
