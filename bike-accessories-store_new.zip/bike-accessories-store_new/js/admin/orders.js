initAdminPage('orders', 'Orders');
$('#oSearchIco').innerHTML = icon('search', 16);
$('#oStatus').innerHTML = '<option value="">All status</option>' + ADMIN_ORDER_STATUSES.map(s => `<option>${s}</option>`).join('');

const tabShow = initTabs($('#oTabs').parentElement);
if (params().tab === 'payments') { const t = $('#t-payments'); t.click(); }

function renderOrders() {
  const q = $('#oSearch').value.trim().toLowerCase(), status = $('#oStatus').value;
  let list = AdminDB.orders.all().filter(o => {
    if (q && !(o.orderNumber.toLowerCase().includes(q) || o.customer.name.toLowerCase().includes(q) || o.customer.email.toLowerCase().includes(q))) return false;
    if (status && o.orderStatus !== status) return false;
    return true;
  }).sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  $('#ordersTable').innerHTML = `
    <thead><tr><th>Order</th><th>Customer</th><th>Products</th><th>Amount</th><th>Payment</th><th>Date</th><th>Status</th><th></th></tr></thead>
    <tbody>${list.map(o => `
      <tr>
        <td class="cell-title"><a href="order-details.html?id=${o.id}">${o.orderNumber}</a></td>
        <td>${esc(o.customer.name)}<div class="cell-sub">${esc(o.customer.email)}</div></td>
        <td class="cell-sub">${o.items.length} item${o.items.length > 1 ? 's' : ''}</td>
        <td>${fmt(o.total)}</td>
        <td>${paymentPill(o.paymentStatus)}</td>
        <td>${o.createdAt}</td>
        <td>
          <select data-status="${o.id}" class="oStatusSelect">
            ${ADMIN_ORDER_STATUSES.map(s => `<option ${s === o.orderStatus ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
        </td>
        <td><a class="btn btn-outline btn-sm" href="order-details.html?id=${o.id}">View</a></td>
      </tr>`).join('') || '<tr><td colspan="8" class="admin-empty">No orders match these filters.</td></tr>'}</tbody>`;

  $$('.oStatusSelect').forEach(sel => sel.addEventListener('change', () => {
    const o = AdminDB.orders.get(sel.dataset.status);
    o.orderStatus = sel.value; o.updatedAt = '2026-09-21';
    AdminDB.orders.save(o); toast('Order ' + o.orderNumber + ' marked ' + sel.value);
  }));
}

function renderPayments() {
  const status = $('#payStatus').value;
  let list = AdminDB.orders.all().filter(o => !status || o.paymentStatus === status).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  $('#paymentsTable').innerHTML = `
    <thead><tr><th>Order</th><th>Payment ID</th><th>Razorpay Order ID</th><th>Amount</th><th>Method</th><th>Status</th><th>Date</th></tr></thead>
    <tbody>${list.map(o => `
      <tr>
        <td class="cell-title"><a href="order-details.html?id=${o.id}">${o.orderNumber}</a></td>
        <td class="cell-sub">${o.razorpayPaymentId || '—'}</td>
        <td class="cell-sub">${o.razorpayOrderId}</td>
        <td>${fmt(o.total)}</td>
        <td>${o.paymentMethod}</td>
        <td>${paymentPill(o.paymentStatus)}</td>
        <td>${o.createdAt}</td>
      </tr>`).join('') || '<tr><td colspan="7" class="admin-empty">No payments match this filter.</td></tr>'}</tbody>`;
}

['oSearch'].forEach(id => $('#' + id).addEventListener('input', renderOrders));
$('#oStatus').addEventListener('change', renderOrders);
$('#payStatus').addEventListener('change', renderPayments);
renderOrders(); renderPayments();
