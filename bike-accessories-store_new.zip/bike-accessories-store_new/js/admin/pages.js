initAdminPage('pages', 'Pages');

function render() {
  const list = AdminDB.pages.all();
  $('#pgTable').innerHTML = `
    <thead><tr><th>Page</th><th>Slug</th><th>Last updated</th><th></th></tr></thead>
    <tbody>${list.map(p => `
      <tr>
        <td class="cell-title">${esc(p.title)}</td>
        <td class="cell-sub">/${p.slug}</td>
        <td class="cell-sub">${p.updated}</td>
        <td><button class="btn btn-outline btn-sm" data-edit="${p.id}">Edit content</button></td>
      </tr>`).join('')}</tbody>`;
  $$('#pgTable [data-edit]').forEach(b => b.addEventListener('click', () => openForm(list.find(p => p.id === b.dataset.edit))));
}

function openForm(p) {
  const { close } = Modal.open(`
    <div class="admin-card-body">
      <h2 style="margin-bottom:16px">${esc(p.title)}</h2>
      <div class="form-field" style="margin-bottom:14px"><label>Slug</label><input type="text" id="m-slug" value="${esc(p.slug)}"></div>
      <div class="form-field"><label>Body content</label><textarea id="m-body" style="min-height:220px">${esc(p.body)}</textarea></div>
      <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px"><button class="btn btn-outline" id="m-cancel" type="button">Cancel</button><button class="btn btn-primary" id="m-save" type="button">Save page</button></div>
    </div>`, { label: 'Edit page', cls: 'modal-lg' });
  $('#m-cancel').addEventListener('click', close);
  $('#m-save').addEventListener('click', () => {
    p.slug = $('#m-slug').value.trim(); p.body = $('#m-body').value; p.updated = '2026-09-21';
    AdminDB.pages.save(p); toast('Page saved'); close(); render();
  });
}
render();
