initAdminPage('collections', 'Collections');

function render() {
  const list = AdminDB.collections.all();
  $('#colTable').innerHTML = `
    <thead><tr><th>Collection</th><th>Description</th><th>Categories included</th><th>Status</th><th></th></tr></thead>
    <tbody>${list.map(c => `
      <tr>
        <td class="cell-title">${esc(c.name)}</td>
        <td class="cell-sub">${esc(c.desc || '')}</td>
        <td class="cell-sub">${(c.cats || []).map(id => getCat(id) ? getCat(id).name : id).join(', ')}</td>
        <td>${activePill(c.active !== false)}</td>
        <td>
          <div class="row-actions">
            <button class="icon-btn btn-icon-only" data-edit="${c.id}" title="Edit">${icon('edit', 17)}</button>
            <button class="icon-btn btn-icon-only" data-toggle="${c.id}" title="Toggle active">${icon(c.active === false ? 'check' : 'x', 17)}</button>
            <button class="icon-btn btn-icon-only" data-del="${c.id}" title="Delete">${icon('trash', 17)}</button>
          </div>
        </td>
      </tr>`).join('')}</tbody>`;
  $$('#colTable [data-edit]').forEach(x => x.addEventListener('click', () => openForm(list.find(c => c.id === x.dataset.edit))));
  $$('#colTable [data-toggle]').forEach(x => x.addEventListener('click', () => { const c = list.find(y => y.id === x.dataset.toggle); c.active = c.active === false ? true : false; AdminDB.collections.save(c); render(); }));
  $$('#colTable [data-del]').forEach(x => x.addEventListener('click', () => confirmAction('Delete this collection?', () => { AdminDB.collections.remove(x.dataset.del); toast('Collection deleted'); render(); })));
}

function openForm(c) {
  const editing = !!c;
  c = c || { id: 'col' + Date.now().toString(36), name: '', desc: '', cats: [], active: true };
  const { close } = Modal.open(`
    <div class="admin-card-body">
      <h2 style="margin-bottom:16px">${editing ? 'Edit collection' : 'Add collection'}</h2>
      <div class="form-grid">
        <div class="form-field span-2"><label>Collection name *</label><input type="text" id="m-name" value="${esc(c.name)}" required></div>
        <div class="form-field span-2"><label>Description</label><textarea id="m-desc" style="min-height:60px">${esc(c.desc || '')}</textarea></div>
        <div class="form-field span-2"><label>Categories included</label>
          <div style="display:flex;flex-wrap:wrap;gap:8px">
            ${CATEGORIES.map(cat => `<label class="checkbox-row" style="background:var(--surface-2);padding:6px 10px;border-radius:20px;font-size:.82rem"><input type="checkbox" value="${cat.id}" ${c.cats.includes(cat.id) ? 'checked' : ''} class="m-cat"> ${esc(cat.name)}</label>`).join('')}
          </div>
        </div>
      </div>
      <label class="switch" style="margin:16px 0"><input type="checkbox" id="m-active" ${c.active !== false ? 'checked' : ''}><span class="switch-track"></span> Active</label>
      <div style="display:flex;gap:10px;justify-content:flex-end"><button class="btn btn-outline" id="m-cancel" type="button">Cancel</button><button class="btn btn-primary" id="m-save" type="button">Save</button></div>
    </div>`, { label: 'Collection form' });
  $('#m-cancel').addEventListener('click', close);
  $('#m-save').addEventListener('click', () => {
    if (!$('#m-name').value.trim()) { toast('Collection name is required', 'error'); return; }
    c.name = $('#m-name').value.trim(); c.desc = $('#m-desc').value.trim(); c.active = $('#m-active').checked;
    c.cats = $$('.m-cat').filter(x => x.checked).map(x => x.value);
    AdminDB.collections.save(c); toast('Collection saved'); close(); render();
  });
}
$('#btnAdd').addEventListener('click', () => openForm(null));
render();
