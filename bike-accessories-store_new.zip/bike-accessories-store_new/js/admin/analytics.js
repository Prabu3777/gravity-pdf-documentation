initAdminPage('analytics', 'Analytics');

const orders = AdminDB.orders.all().filter(o => o.paymentStatus === 'Paid');
const products = AdminDB.products.all();
const customers = AdminDB.customers.all();

const todayRev = orders.filter(o => o.createdAt === '2026-09-21').reduce((s, o) => s + o.total, 0);
const weekDays = ['2026-09-15', '2026-09-16', '2026-09-17', '2026-09-18', '2026-09-19', '2026-09-20', '2026-09-21'];
const weekRev = orders.filter(o => weekDays.includes(o.createdAt)).reduce((s, o) => s + o.total, 0);
const monthRev = orders.reduce((s, o) => s + o.total, 0);
const yearRev = monthRev;
const totalRev = monthRev;
const aov = orders.length ? Math.round(totalRev / orders.length) : 0;

$('#anStats').innerHTML = [
  { l: "Today's revenue", v: fmt(todayRev), i: 'rupee' },
  { l: 'Weekly revenue', v: fmt(weekRev), i: 'chart' },
  { l: 'Monthly revenue', v: fmt(monthRev), i: 'chart' },
  { l: 'Total revenue', v: fmt(totalRev), i: 'chart' },
  { l: 'Orders', v: orders.length, i: 'truck' },
  { l: 'Average order value', v: fmt(aov), i: 'rupee' }
].map(s => `<div class="stat-card"><div class="stat-card-top"><span class="stat-card-ico">${icon(s.i, 18)}</span></div><div class="stat-value">${s.v}</div><div class="stat-label">${s.l}</div></div>`).join('');

const byDay = weekDays.map(d => orders.filter(o => o.createdAt === d).reduce((s, o) => s + o.total, 0));
const max1 = Math.max(...byDay, 1);
$('#anRevChart').innerHTML = byDay.map((v, i) => `<div class="bar-col"><div class="bar" style="height:${Math.max(4, v / max1 * 100)}%" title="${fmt(v)}"></div><span>${weekDays[i].slice(8)} Sep</span></div>`).join('');

const catTotals = {};
orders.forEach(o => o.items.forEach(it => { const p = getProduct(it.id); if (!p) return; catTotals[p.cat] = (catTotals[p.cat] || 0) + it.price * it.qty; }));
const catMax = Math.max(...Object.values(catTotals), 1);
$('#anCatChart').innerHTML = Object.entries(catTotals).sort((a, b) => b[1] - a[1]).map(([cat, v]) => `
  <div class="mini-bar-row"><span class="mb-label">${getCat(cat) ? getCat(cat).name : cat}</span><span class="mini-bar-track"><span class="mini-bar-fill" style="width:${v / catMax * 100}%"></span></span><span class="mini-bar-val">${fmt(v)}</span></div>`).join('');

const unitsById = {};
orders.forEach(o => o.items.forEach(it => { unitsById[it.id] = (unitsById[it.id] || 0) + it.qty; }));
const topP = Object.entries(unitsById).sort((a, b) => b[1] - a[1]).slice(0, 6);
const topPMax = Math.max(...topP.map(x => x[1]), 1);
$('#anTopProducts').innerHTML = topP.map(([id, u]) => { const p = getProduct(id); return p ? `<div class="mini-bar-row"><span class="mb-label">${esc(p.name)}</span><span class="mini-bar-track"><span class="mini-bar-fill" style="width:${u / topPMax * 100}%"></span></span><span class="mini-bar-val">${u} sold</span></div>` : ''; }).join('');

const brandTotals = {};
orders.forEach(o => o.items.forEach(it => { const p = getProduct(it.id); if (!p) return; brandTotals[p.brand] = (brandTotals[p.brand] || 0) + it.price * it.qty; }));
const brandMax = Math.max(...Object.values(brandTotals), 1);
$('#anTopBrands').innerHTML = Object.entries(brandTotals).sort((a, b) => b[1] - a[1]).map(([b, v]) => `
  <div class="mini-bar-row"><span class="mb-label">${getBrand(b) ? getBrand(b).name : b}</span><span class="mini-bar-track"><span class="mini-bar-fill" style="width:${v / brandMax * 100}%"></span></span><span class="mini-bar-val">${fmt(v)}</span></div>`).join('');

const months = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'];
const growthByMonth = months.map((m, i) => customers.filter(c => Number(c.joined.split('-')[1]) === i + 4).length);
const gmax = Math.max(...growthByMonth, 1);
$('#anCustChart').innerHTML = growthByMonth.map((v, i) => `<div class="bar-col"><div class="bar" style="height:${Math.max(4, v / gmax * 100)}%" title="${v}"></div><span>${months[i]}</span></div>`).join('');
