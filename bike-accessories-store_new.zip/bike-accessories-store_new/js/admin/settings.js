initAdminPage('settings', 'Settings');

const s = AdminDB.settings.get();
$('#s-name').value = s.storeName; $('#s-email').value = s.email; $('#s-phone').value = s.phone; $('#s-address').value = s.address;
$('#s-currency').value = s.currency; $('#s-tax').value = s.taxPercent; $('#s-shipping').value = s.shippingCharge; $('#s-freeship').value = s.freeShippingThreshold;
$('#s-return').value = s.returnDays; $('#s-refund').value = s.refundDays;
$('#s-insta').value = s.instagram; $('#s-yt').value = s.youtube; $('#s-fb').value = s.facebook;
const sess = AdminAuth.session();
$('#s-currentadmin').value = sess ? `${sess.name} (${sess.email})` : '';

$('#s-save').addEventListener('click', () => {
  AdminDB.settings.save({
    storeName: $('#s-name').value.trim(), email: $('#s-email').value.trim(), phone: $('#s-phone').value.trim(), address: $('#s-address').value.trim(),
    currency: $('#s-currency').value.trim(), taxPercent: Number($('#s-tax').value), shippingCharge: Number($('#s-shipping').value), freeShippingThreshold: Number($('#s-freeship').value),
    returnDays: Number($('#s-return').value), refundDays: Number($('#s-refund').value),
    instagram: $('#s-insta').value.trim(), youtube: $('#s-yt').value.trim(), facebook: $('#s-fb').value.trim()
  });
  toast('Settings saved');
});

$('#s-reset').addEventListener('click', () => confirmAction('Reset all admin demo data? This cannot be undone.', () => AdminDB.resetAll()));
