/* admin-auth.js — Firebase Authentication + custom claim "admin: true" check
   (spec §32/§56: role lives in the Firebase Auth ID token, set server-side by
   the setAdminClaim Cloud Function, never a client-side flag).

   To keep every existing admin/*.js page working unchanged, AdminAuth.session()
   stays a SYNCHRONOUS read (same shape as the old demo version) backed by a
   small localStorage cache written on successful login. AdminAuth.guard()
   checks that cache immediately (instant redirect if never logged in) AND
   re-verifies against the real Firebase ID token in the background, signing
   out and redirecting if the token turns out invalid, expired, or missing
   the admin claim. */

const AdminAuth = {
  KEY: 'adm_session',

  ADMIN_EMAIL: 'joshvajoshva392@gmail.com',

  session() {
    return Store.get(this.KEY, null);
  },

  isAdmin(user) {
    return (
      user &&
      user.email &&
      user.email.toLowerCase() === this.ADMIN_EMAIL.toLowerCase()
    );
  },

  async login(email, pass) {
    const cred = await auth.signInWithEmailAndPassword(
      email.trim(),
      pass
    );

    // Admin is identified by Firebase Authentication email.
    if (!this.isAdmin(cred.user)) {
      await auth.signOut();
      throw new Error('This account does not have admin access.');
    }

    Store.set(this.KEY, {
      uid: cred.user.uid,
      email: cred.user.email,
      name: cred.user.displayName || 'Store Admin',
      since: Date.now()
    });

    return cred.user;
  },

  logout() {
    Store.del(this.KEY);

    auth.signOut().finally(() => {
      location.href = 'login.html';
    });
  },

  guard() {
    if (!this.session()) {
      location.href = 'login.html';
      return;
    }

    if (typeof auth === 'undefined') {
      return;
    }

    auth.onAuthStateChanged(user => {
      if (!user) {
        Store.del(this.KEY);
        location.href = 'login.html';
        return;
      }

      // IMPORTANT:
      // Do NOT check token.claims.admin here.
      if (!this.isAdmin(user)) {
        Store.del(this.KEY);
        auth.signOut();
        location.href = 'login.html';
        return;
      }

      console.log('Admin authenticated:', user.email);
    });
  }
};
