initAdminPage('dashboard', 'Dashboard');

(function () {
  const orders = AdminDB.orders.all();
  const products = AdminDB.products.all();
  const customers = AdminDB.customers.all();

  const today = '2026-09-21';
  const todaysOrders = orders.filter(o => o.createdAt === today);
  const todaysSales = todaysOrders.reduce((s, o) => s + o.total, 0);
  const totalRevenue = orders.filter(o => o.paymentStatus === 'Paid').reduce((s, o) => s + o.total, 0);
  const lowStock = products.filter(p => p.stock > 0 && p.stock <= (p.low || 5)).length;
  const outStock = products.filter(p => p.stock <= 0).length;

  const stats = [
    { label: "Today's sales", value: fmt(todaysSales), ico: 'rupee', trend: '+' + todaysOrders.length + ' orders today' },
    { label: 'Total revenue', value: fmt(totalRevenue), ico: 'chart', trend: 'All-time, paid orders' },
    { label: 'Orders', value: orders.length, ico: 'truck', trend: orders.filter(o => o.orderStatus === 'Pending').length + ' pending' },
    { label: 'Customers', value: customers.length, ico: 'users', trend: 'Registered accounts' },
    { label: 'Products', value: products.length, ico: 'tag', trend: products.filter(p => p.active !== false).length + ' active' },
    { label: 'Low stock', value: lowStock, ico: 'package', trend: 'Needs restocking' },
    { label: 'Out of stock', value: outStock, ico: 'x', trend: 'Unavailable to buy' }
  ];
  $('#statGrid').innerHTML = stats.map(s => `
    <div class="stat-card">
      <div class="stat-card-top"><span class="stat-card-ico">${icon(s.ico, 18)}</span></div>
      <div class="stat-value">${s.value}</div>
      <div class="stat-label">${s.label}</div>
      <div class="stat-label" style="margin-top:6px;font-size:.76rem">${s.trend}</div>
    </div>`).join('');

  // Revenue last 7 days
  const days = ['15', '16', '17', '18', '19', '20', '21'];
  const byDay = days.map(d => orders.filter(o => o.createdAt === '2026-09-' + d).reduce((s, o) => s + o.total, 0));
  const max = Math.max(...byDay, 1);
  $('#revenueChart').innerHTML = byDay.map((v, i) => `
    <div class="bar-col">
      <div class="bar" style="height:${Math.max(4, (v / max) * 100)}%" title="${fmt(v)}"></div>
      <span>${days[i]} Sep</span>
    </div>`).join('');

  // Category sales
  const catTotals = {};
  orders.forEach(o => o.items.forEach(it => {
    const p = getProduct(it.id); if (!p) return;
    catTotals[p.cat] = (catTotals[p.cat] || 0) + it.price * it.qty;
  }));
  const catMax = Math.max(...Object.values(catTotals), 1);
  $('#categoryChart').innerHTML = Object.entries(catTotals).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([cat, v]) => `
    <div class="mini-bar-row">
      <span class="mb-label">${getCat(cat) ? getCat(cat).name : cat}</span>
      <span class="mini-bar-track"><span class="mini-bar-fill" style="width:${(v / catMax) * 100}%"></span></span>
      <span class="mini-bar-val">${fmt(v)}</span>
    </div>`).join('');

  // Recent orders
  const recent = [...orders].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 6);
  $('#recentOrdersTable').innerHTML = `
    <thead><tr><th>Order</th><th>Customer</th><th>Amount</th><th>Status</th></tr></thead>
    <tbody>${recent.map(o => `
      <tr>
        <td><a href="order-details.html?id=${o.id}" class="cell-title">${o.orderNumber}</a><div class="cell-sub">${o.createdAt}</div></td>
        <td>${esc(o.customer.name)}</td>
        <td>${fmt(o.total)}</td>
        <td>${statusPill(o.orderStatus)}</td>
      </tr>`).join('')}</tbody>`;

  // Top products by units sold
  const unitsById = {};
  orders.forEach(o => o.items.forEach(it => { unitsById[it.id] = (unitsById[it.id] || 0) + it.qty; }));
  const top = Object.entries(unitsById).sort((a, b) => b[1] - a[1]).slice(0, 5);
  $('#topProducts').innerHTML = top.map(([id, units]) => {
    const p = getProduct(id); if (!p) return '';
    return `<div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
      <img src="${imgSrc(p)}" alt="" style="width:42px;height:42px;border-radius:8px;object-fit:cover">
      <div style="flex:1;min-width:0"><div class="cell-title" style="font-size:.87rem">${esc(p.name)}</div><div class="cell-sub">${units} sold · ${fmt(p.price)}</div></div>
    </div>`;
  }).join('');

  // Low stock table
  const low = products.filter(p => p.stock <= (p.low || 5)).sort((a, b) => a.stock - b.stock).slice(0, 8);
  $('#lowStockTable').innerHTML = `
    <thead><tr><th>Product</th><th>SKU</th><th>Stock</th><th>Threshold</th><th>Status</th></tr></thead>
    <tbody>${low.map(p => `
      <tr>
        <td class="cell-main"><img class="cell-img" src="${imgSrc(p)}" alt=""><span class="cell-title">${esc(p.name)}</span></td>
        <td>${p.sku}</td>
        <td>${p.stock}</td>
        <td>${p.low || 5}</td>
        <td>${p.stock <= 0 ? '<span class="pill pill-bad">Out of stock</span>' : '<span class="pill pill-warn">Low stock</span>'}</td>
      </tr>`).join('') || '<tr><td colspan="5" class="admin-empty">All products are well stocked.</td></tr>'}</tbody>`;
})();
