initAdminPage('products', 'Products');

const editId = params().id;
const editing = !!editId;
let current = editing ? { ...AdminDB.products.get(editId) } : {
  id: 'p' + Date.now().toString(36), name: '', sku: '', brand: BRANDS[0].id, cat: CATEGORIES[0].id, subcat: '',
  short: '', desc: [''], mrp: 0, price: 0, tax: 2, stock: 0, low: 5,
  images: [], optLabel: '', opts: [], variants: [], specifications: [], features: [],
  weight: '', dimensions: '', warranty: '', seoTitle: '', seoDesc: '', slug: '',
  active: true, isFeatured: false, isNew: false, isBest: false, rating: 0, reviews: 0,
  created: '2026-09-21'
};

$('#formTitle').textContent = editing ? 'Edit product — ' + current.name : 'Add product';
$('#f-brand').innerHTML = BRANDS.map(b => `<option value="${b.id}">${b.name}</option>`).join('');
$('#f-cat').innerHTML = CATEGORIES.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
$('#uploaderIcoWrap').innerHTML = icon('upload', 30);
$('#rt-bold').innerHTML = icon('bold', 16);
$('#rt-italic').innerHTML = icon('italic', 16);

initTabs($('#pTabs').closest('form'));

// ---------- populate basic fields ----------
$('#f-name').value = current.name || '';
$('#f-sku').value = current.sku || '';
$('#f-brand').value = current.brand;
$('#f-cat').value = current.cat;
$('#f-subcat').value = current.subcat || '';
$('#f-short').value = current.short || '';
$('#f-full').value = Array.isArray(current.desc) ? current.desc.join('\n\n') : (current.desc || '');
$('#f-mrp').value = current.mrp || '';
$('#f-price').value = current.price || '';
$('#f-tax').value = current.tax != null ? current.tax : 2;
$('#f-stock').value = current.stock != null ? current.stock : '';
$('#f-low').value = current.low != null ? current.low : 5;
$('#f-optlabel').value = current.optLabel || '';
$('#f-opts').value = (current.opts || []).join(', ');
$('#f-weight').value = current.weight || '';
$('#f-warranty').value = current.warranty || '';
$('#f-seotitle').value = current.seoTitle || current.name || '';
$('#f-seodesc').value = current.seoDesc || current.short || '';
$('#f-slug').value = current.slug || (current.name ? current.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') : '');
$('#f-active').checked = current.active !== false;
$('#f-featured').checked = !!current.isFeatured;
$('#f-new').checked = !!current.isNew;
$('#f-best').checked = !!current.isBest;

function updateDiscountPreview() {
  const mrp = Number($('#f-mrp').value), price = Number($('#f-price').value);
  $('#discountPreview').textContent = mrp > price && price > 0 ? `${Math.round((1 - price / mrp) * 100)}% off — customer saves ${fmt(mrp - price)}` : 'Enter both MRP and selling price to preview the discount.';
}
$('#f-mrp').addEventListener('input', updateDiscountPreview);
$('#f-price').addEventListener('input', updateDiscountPreview);
updateDiscountPreview();

// ---------- images ----------
let images = (current.images && current.images.length ? current.images : (imgSrcExisting(current))).slice();
function imgSrcExisting(p) { try { return p.name ? [imgSrc(p)] : []; } catch (e) { return []; } }
function renderImages() {
  $('#imgGrid').innerHTML = images.map((src, i) => `
    <div class="upload-thumb">
      <img src="${src}" alt="">
      ${i === 0 ? '<span class="primary-badge">Primary</span>' : ''}
      <div class="thumb-actions">
        ${i !== 0 ? `<button type="button" data-act="primary" data-i="${i}" title="Set primary">${icon('star', 13)}</button>` : ''}
        <button type="button" data-act="remove" data-i="${i}" title="Remove">${icon('trash', 13)}</button>
      </div>
    </div>`).join('');
  $$('#imgGrid [data-act]').forEach(b => b.addEventListener('click', () => {
    const i = Number(b.dataset.i);
    if (b.dataset.act === 'remove') images.splice(i, 1);
    if (b.dataset.act === 'primary') { const [x] = images.splice(i, 1); images.unshift(x); }
    renderImages();
  }));
}
renderImages();
const fileInput = document.createElement('input');
fileInput.type = 'file'; fileInput.accept = 'image/*'; fileInput.multiple = true; fileInput.hidden = true;
document.body.appendChild(fileInput);
$('#imgUploader').addEventListener('click', () => fileInput.click());
$('#imgUploader').addEventListener('dragover', e => e.preventDefault());
$('#imgUploader').addEventListener('drop', e => { e.preventDefault(); handleFiles(e.dataTransfer.files); });
fileInput.addEventListener('change', () => handleFiles(fileInput.files));
function handleFiles(files) {
  Array.from(files).slice(0, 8).forEach(f => {
    if (!f.type.startsWith('image/')) return;
    if (f.size > 8 * 1024 * 1024) { toast(f.name + ' is over 8MB — skipped.', 'error'); return; }
    // Instant local preview while the real upload runs in the background.
    const reader = new FileReader();
    const placeholderIdx = images.length;
    reader.onload = e => { images.push(e.target.result); renderImages(); };
    reader.readAsDataURL(f);

    if (typeof storage === 'undefined') return; // firebase-config.js not loaded
    const path = `products/${current.id}/images/${Date.now()}-${f.name.replace(/[^a-zA-Z0-9.]/g, '_')}`;
    const task = storage.ref(path).put(f);
    task.on('state_changed',
      snap => { /* could drive a progress bar per-thumb here */ },
      err => toast('Upload failed for ' + f.name + ': ' + err.message, 'error'),
      async () => {
        const url = await task.snapshot.ref.getDownloadURL();
        const i = images.indexOf(images[placeholderIdx]);
        if (i > -1) images[i] = url; else images.push(url);
        renderImages();
        toast(f.name + ' uploaded');
      }
    );
  });
}

// ---------- variants ----------
function renderVariants() {
  $('#variantRows').innerHTML = (current.variants || []).map((v, i) => `
    <div class="dyn-row">
      <input type="text" placeholder="Option value" value="${esc(v.value || '')}" data-f="value" data-i="${i}">
      <input type="text" placeholder="SKU" value="${esc(v.sku || '')}" data-f="sku" data-i="${i}">
      <input type="number" placeholder="Price" value="${v.price || ''}" data-f="price" data-i="${i}">
      <input type="number" placeholder="Stock" value="${v.stock || ''}" data-f="stock" data-i="${i}">
      <button type="button" class="icon-btn btn-icon-only" data-rm="${i}">${icon('trash', 16)}</button>
    </div>`).join('') || '<p class="hint">No variants yet — generate from options above, or add rows manually.</p>';
  wireVariantRows();
}
function wireVariantRows() {
  $$('#variantRows [data-f]').forEach(inp => inp.addEventListener('input', () => {
    current.variants[Number(inp.dataset.i)][inp.dataset.f] = inp.type === 'number' ? Number(inp.value) : inp.value;
  }));
  $$('#variantRows [data-rm]').forEach(b => b.addEventListener('click', () => { current.variants.splice(Number(b.dataset.rm), 1); renderVariants(); }));
}
current.variants = current.variants || [];
renderVariants();
$('#f-opts').addEventListener('change', () => {
  const opts = $('#f-opts').value.split(',').map(s => s.trim()).filter(Boolean);
  current.variants = opts.map(o => ({ value: o, sku: (current.sku || 'SKU') + '-' + o.replace(/\s+/g, ''), price: Number($('#f-price').value) || 0, stock: 0 }));
  renderVariants();
});

// ---------- specifications ----------
function specRow(k = '', v = '', i) {
  return `<div class="dyn-row">
    <input type="text" placeholder="Key (e.g. Material)" value="${esc(k)}" data-sf="k" data-i="${i}">
    <input type="text" placeholder="Value (e.g. Nylon)" value="${esc(v)}" data-sf="v" data-i="${i}">
    <button type="button" class="icon-btn btn-icon-only" data-srm="${i}">${icon('trash', 16)}</button>
  </div>`;
}
current.specifications = current.specifications && current.specifications.length ? current.specifications : [];
function renderSpecs() {
  $('#specRows').innerHTML = current.specifications.map((s, i) => specRow(s.k, s.v, i)).join('') || '<p class="hint">No specifications yet.</p>';
  $$('#specRows [data-sf]').forEach(inp => inp.addEventListener('input', () => { current.specifications[Number(inp.dataset.i)][inp.dataset.sf] = inp.value; }));
  $$('#specRows [data-srm]').forEach(b => b.addEventListener('click', () => { current.specifications.splice(Number(b.dataset.srm), 1); renderSpecs(); }));
}
renderSpecs();
$('#addSpec').addEventListener('click', () => { current.specifications.push({ k: '', v: '' }); renderSpecs(); });

// ---------- features ----------
current.features = current.features && current.features.length ? current.features : [];
function renderFeats() {
  $('#featRows').innerHTML = current.features.map((f, i) => `
    <div class="dyn-row">
      <input type="text" placeholder="Feature (e.g. Waterproof)" value="${esc(f)}" data-ff="${i}">
      <button type="button" class="icon-btn btn-icon-only" data-frm="${i}">${icon('trash', 16)}</button>
    </div>`).join('') || '<p class="hint">No features yet.</p>';
  $$('#featRows [data-ff]').forEach(inp => inp.addEventListener('input', () => { current.features[Number(inp.dataset.ff)] = inp.value; }));
  $$('#featRows [data-frm]').forEach(b => b.addEventListener('click', () => { current.features.splice(Number(b.dataset.frm), 1); renderFeats(); }));
}
renderFeats();
$('#addFeat').addEventListener('click', () => { current.features.push(''); renderFeats(); });

// ---------- save ----------
function collect(active) {
  return {
    ...current,
    name: $('#f-name').value.trim(), sku: $('#f-sku').value.trim(), brand: $('#f-brand').value, cat: $('#f-cat').value, subcat: $('#f-subcat').value.trim(),
    short: $('#f-short').value.trim(), desc: $('#f-full').value.split('\n\n').filter(Boolean),
    mrp: Number($('#f-mrp').value) || 0, price: Number($('#f-price').value) || 0, tax: Number($('#f-tax').value) || 0,
    stock: Number($('#f-stock').value) || 0, low: Number($('#f-low').value) || 5,
    images, optLabel: $('#f-optlabel').value.trim(), opts: $('#f-opts').value.split(',').map(s => s.trim()).filter(Boolean),
    weight: $('#f-weight').value.trim(), warranty: $('#f-warranty').value.trim(),
    seoTitle: $('#f-seotitle').value.trim(), seoDesc: $('#f-seodesc').value.trim(), slug: $('#f-slug').value.trim(),
    active, isFeatured: $('#f-featured').checked, isNew: $('#f-new').checked, isBest: $('#f-best').checked,
    rating: current.rating || 0, reviews: current.reviews || 0
  };
}

function doSave(active, redirect) {
  if (!validateFields($('#pForm'))) { toast('Please fill in the required fields', 'error'); return; }
  const prevStock = current.stock;
  const product = collect(active);
  AdminDB.products.save(product);
  if (typeof prevStock === 'number' && prevStock !== product.stock) {
    AdminDB.stockLog.add({ id: 'sl' + Date.now().toString(36), product: product.name, sku: product.sku, type: 'Adjustment', change: product.stock - prevStock, note: 'Edited in product form', date: new Date().toISOString().slice(0, 10) });
  }
  toast(active ? 'Product published' : 'Draft saved');
  if (redirect) setTimeout(() => location.href = 'products.html', 500);
}
$('#btnDraft').addEventListener('click', () => doSave(false, true));
$('#btnPublish').addEventListener('click', () => doSave(true, true));
$('#pForm').addEventListener('submit', e => e.preventDefault());
