initAdminPage('coupons', 'Coupons');

function render() {
  const list = AdminDB.coupons.all();
  $('#cpTable').innerHTML = `
    <thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Min order</th><th>Max discount</th><th>Validity</th><th>Usage</th><th>Status</th><th></th></tr></thead>
    <tbody>${list.map(c => `
      <tr>
        <td class="cell-title" style="font-family:var(--font-head)">${esc(c.code)}</td>
        <td>${c.type}</td>
        <td>${c.type === 'Percentage' ? c.value + '%' : fmt(c.value)}</td>
        <td>${fmt(c.minOrder)}</td>
        <td>${fmt(c.maxDiscount)}</td>
        <td class="cell-sub">${c.start} → ${c.end}</td>
        <td>${c.used} / ${c.usageLimit}</td>
        <td>${activePill(c.active)}</td>
        <td>
          <div class="row-actions">
            <button class="icon-btn btn-icon-only" data-edit="${c.id}" title="Edit">${icon('edit', 17)}</button>
            <button class="icon-btn btn-icon-only" data-toggle="${c.id}" title="${c.active ? 'Deactivate' : 'Activate'}">${icon(c.active ? 'x' : 'check', 17)}</button>
            <button class="icon-btn btn-icon-only" data-del="${c.id}" title="Delete">${icon('trash', 17)}</button>
          </div>
        </td>
      </tr>`).join('')}</tbody>`;
  $$('#cpTable [data-edit]').forEach(b => b.addEventListener('click', () => openForm(list.find(c => c.id === b.dataset.edit))));
  $$('#cpTable [data-toggle]').forEach(b => b.addEventListener('click', () => { const c = list.find(x => x.id === b.dataset.toggle); c.active = !c.active; AdminDB.coupons.save(c); render(); }));
  $$('#cpTable [data-del]').forEach(b => b.addEventListener('click', () => confirmAction('Delete this coupon?', () => { AdminDB.coupons.remove(b.dataset.del); toast('Coupon deleted'); render(); })));
}

function openForm(c) {
  const editing = !!c;
  c = c || { id: 'cp' + Date.now().toString(36), code: '', type: 'Percentage', value: 10, minOrder: 0, maxDiscount: 0, start: '2026-09-21', end: '2026-10-21', usageLimit: 100, used: 0, active: true };
  const { close } = Modal.open(`
    <div class="admin-card-body">
      <h2 style="margin-bottom:16px">${editing ? 'Edit coupon' : 'Create coupon'}</h2>
      <div class="form-grid">
        <div class="form-field span-2"><label>Coupon code *</label><input type="text" id="m-code" value="${esc(c.code)}" style="text-transform:uppercase" required></div>
        <div class="form-field"><label>Discount type</label><select id="m-type"><option ${c.type === 'Percentage' ? 'selected' : ''}>Percentage</option><option ${c.type === 'Fixed' ? 'selected' : ''}>Fixed</option></select></div>
        <div class="form-field"><label>Discount value *</label><input type="number" id="m-value" value="${c.value}" required></div>
        <div class="form-field"><label>Minimum order (₹)</label><input type="number" id="m-min" value="${c.minOrder}"></div>
        <div class="form-field"><label>Maximum discount (₹)</label><input type="number" id="m-max" value="${c.maxDiscount}"></div>
        <div class="form-field"><label>Start date</label><input type="date" id="m-start" value="${c.start}"></div>
        <div class="form-field"><label>Expiry date</label><input type="date" id="m-end" value="${c.end}"></div>
        <div class="form-field"><label>Usage limit</label><input type="number" id="m-limit" value="${c.usageLimit}"></div>
      </div>
      <label class="switch" style="margin:16px 0"><input type="checkbox" id="m-active" ${c.active ? 'checked' : ''}><span class="switch-track"></span> Active</label>
      <div style="display:flex;gap:10px;justify-content:flex-end"><button class="btn btn-outline" id="m-cancel" type="button">Cancel</button><button class="btn btn-primary" id="m-save" type="button">Save</button></div>
    </div>`, { label: 'Coupon form' });
  $('#m-cancel').addEventListener('click', close);
  $('#m-save').addEventListener('click', () => {
    if (!$('#m-code').value.trim()) { toast('Coupon code is required', 'error'); return; }
    Object.assign(c, {
      code: $('#m-code').value.trim().toUpperCase(), type: $('#m-type').value, value: Number($('#m-value').value),
      minOrder: Number($('#m-min').value), maxDiscount: Number($('#m-max').value),
      start: $('#m-start').value, end: $('#m-end').value, usageLimit: Number($('#m-limit').value)
    });
    AdminDB.coupons.save(c); toast('Coupon saved'); close(); render();
  });
}
$('#btnAdd').addEventListener('click', () => openForm(null));
render();
