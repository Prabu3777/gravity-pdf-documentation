initAdminPage('support', 'Support');

const TICKET_STATUSES = ['Open', 'In Progress', 'Resolved', 'Closed'];

function render() {
  const list = AdminDB.tickets.all();
  $('#ticketBoard').innerHTML = TICKET_STATUSES.map(status => `
    <div class="kanban-col">
      <h3>${status} (${list.filter(t => t.status === status).length})</h3>
      ${list.filter(t => t.status === status).map(t => `
        <div class="kanban-card" data-open="${t.id}" style="cursor:pointer">
          <b>${esc(t.subject)}</b>
          <div class="cell-sub">${esc(t.name)} · ${t.date}</div>
        </div>`).join('')}
    </div>`).join('');
  $$('#ticketBoard [data-open]').forEach(c => c.addEventListener('click', () => openTicket(list.find(t => t.id === c.dataset.open))));
}

function openTicket(t) {
  const { close } = Modal.open(`
    <div class="admin-card-body">
      <h2 style="margin-bottom:4px">${esc(t.subject)}</h2>
      <p class="cell-sub" style="margin-bottom:16px">${esc(t.name)} · ${esc(t.email)} · ${esc(t.phone)} · ${t.date}</p>
      <div style="background:var(--surface-2);border-radius:9px;padding:12px 14px;margin-bottom:16px">${esc(t.message)}</div>
      <div class="form-field" style="margin-bottom:14px"><label>Reply</label><textarea id="m-reply" style="min-height:90px" placeholder="Write a reply…">${esc(t.reply)}</textarea></div>
      <div class="form-field" style="margin-bottom:16px"><label>Status</label><select id="m-status">${TICKET_STATUSES.map(s => `<option ${s === t.status ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
      <div style="display:flex;gap:10px;justify-content:flex-end"><button class="btn btn-outline" id="m-cancel" type="button">Close</button><button class="btn btn-primary" id="m-save" type="button">Save</button></div>
    </div>`, { label: 'Ticket detail', cls: 'modal-lg' });
  $('#m-cancel').addEventListener('click', close);
  $('#m-save').addEventListener('click', () => {
    t.reply = $('#m-reply').value.trim(); t.status = $('#m-status').value;
    AdminDB.tickets.save(t); toast('Ticket updated'); close(); render();
  });
}
render();
