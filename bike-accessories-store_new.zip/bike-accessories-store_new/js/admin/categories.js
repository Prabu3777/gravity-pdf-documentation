initAdminPage('categories', 'Categories');

function render() {
  const list = AdminDB.categories.all();
  $('#catTable').innerHTML = `
    <thead><tr><th></th><th>Category</th><th>Slug</th><th>Description</th><th>Products</th><th>Status</th><th></th></tr></thead>
    <tbody>${list.map(c => `
      <tr>
        <td><img class="cell-img" src="${catImg(c)}" alt=""></td>
        <td class="cell-title">${esc(c.name)}</td>
        <td class="cell-sub">${c.id}</td>
        <td class="cell-sub">${esc(c.desc || '')}</td>
        <td>${AdminDB.products.all().filter(p => p.cat === c.id).length}</td>
        <td>${activePill(c.active !== false)}</td>
        <td>
          <div class="row-actions">
            <button class="icon-btn btn-icon-only" data-edit="${c.id}" title="Edit">${icon('edit', 17)}</button>
            <button class="icon-btn btn-icon-only" data-toggle="${c.id}" title="Toggle active">${icon(c.active === false ? 'check' : 'x', 17)}</button>
            <button class="icon-btn btn-icon-only" data-del="${c.id}" title="Delete">${icon('trash', 17)}</button>
          </div>
        </td>
      </tr>`).join('')}</tbody>`;

  $$('#catTable [data-edit]').forEach(b => b.addEventListener('click', () => openForm(list.find(c => c.id === b.dataset.edit))));
  $$('#catTable [data-toggle]').forEach(b => b.addEventListener('click', () => {
    const c = list.find(x => x.id === b.dataset.toggle); c.active = c.active === false ? true : false; AdminDB.categories.save(c); render();
  }));
  $$('#catTable [data-del]').forEach(b => b.addEventListener('click', () => {
    confirmAction('Delete this category? Products keep their tag but it will disappear from menus.', () => { AdminDB.categories.remove(b.dataset.del); toast('Category deleted'); render(); });
  }));
}

function openForm(c) {
  const editing = !!c;
  c = c || { id: 'cat' + Date.now().toString(36), name: '', desc: '', parent: '', seoTitle: '', seoDesc: '', active: true, glyph: 'bag' };
  const { close } = Modal.open(`
    <div class="admin-card-body">
      <h2 style="margin-bottom:16px">${editing ? 'Edit category' : 'Add category'}</h2>
      <div class="form-grid">
        <div class="form-field span-2"><label>Category name *</label><input type="text" id="m-name" value="${esc(c.name)}" required></div>
        <div class="form-field span-2"><label>Description</label><textarea id="m-desc" style="min-height:70px">${esc(c.desc || '')}</textarea></div>
        <div class="form-field"><label>Parent category</label><select id="m-parent"><option value="">None (top level)</option>${AdminDB.categories.all().filter(x => x.id !== c.id).map(p => `<option value="${p.id}" ${c.parent === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select></div>
        <div class="form-field"><label>SEO title</label><input type="text" id="m-seot" value="${esc(c.seoTitle || '')}"></div>
        <div class="form-field span-2"><label>SEO description</label><textarea id="m-seod" style="min-height:56px">${esc(c.seoDesc || '')}</textarea></div>
      </div>
      <label class="switch" style="margin:16px 0"><input type="checkbox" id="m-active" ${c.active !== false ? 'checked' : ''}><span class="switch-track"></span> Active</label>
      <div style="display:flex;gap:10px;justify-content:flex-end"><button class="btn btn-outline" id="m-cancel" type="button">Cancel</button><button class="btn btn-primary" id="m-save" type="button">Save</button></div>
    </div>`, { label: 'Category form' });
  $('#m-cancel').addEventListener('click', close);
  $('#m-save').addEventListener('click', () => {
    if (!$('#m-name').value.trim()) { toast('Category name is required', 'error'); return; }
    c.name = $('#m-name').value.trim(); c.desc = $('#m-desc').value.trim(); c.parent = $('#m-parent').value;
    c.seoTitle = $('#m-seot').value.trim(); c.seoDesc = $('#m-seod').value.trim(); c.active = $('#m-active').checked;
    AdminDB.categories.save(c); toast('Category saved'); close(); render();
  });
}

$('#btnAdd').addEventListener('click', () => openForm(null));
render();
