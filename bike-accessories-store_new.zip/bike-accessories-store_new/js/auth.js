/* auth.js — Firebase Authentication for the customer site (spec §25).
   Depends on Cart / Wishlist (cart.js / wishlist.js) for the guest→account
   merge on login (spec §23), and keeps the logged-in cart/wishlist synced to
   Firestore in the background on every change so it's available on any
   device, without changing how Cart/Wishlist are called anywhere else. */

const Auth = {
  user: null,
  _syncTimer: null,

  onReady(fn) {
    auth.onAuthStateChanged(async user => {
      this.user = user;
      if (user) await this._mergeGuestData(user.uid);
      emit('auth:change', user);
      fn(user);
    });
  },

  async register(name, email, password) {
    const cred = await auth.createUserWithEmailAndPassword(email, password);
    await cred.user.updateProfile({ displayName: name });
    await db.collection(COL.users).doc(cred.user.uid).set({
      name, email, role: 'customer', createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    return cred.user;
  },

  async login(email, password) {
    return (await auth.signInWithEmailAndPassword(email, password)).user;
  },

  async loginWithGoogle() {
    const cred = await auth.signInWithPopup(new firebase.auth.GoogleAuthProvider());
    const ref = db.collection(COL.users).doc(cred.user.uid);
alert('test')

    if (!(await ref.get()).exists) {
      await ref.set({ name: cred.user.displayName, email: cred.user.email, role: 'customer', createdAt: firebase.firestore.FieldValue.serverTimestamp() });
    }
    return cred.user;
  },

  async resetPassword(email) { return auth.sendPasswordResetEmail(email); },

  async logout() { await auth.signOut(); location.href = 'index.html'; },

  /* Guest cart/wishlist live in localStorage (Cart/Wishlist in cart.js /
     wishlist.js). On login: pull the user's Firestore cart/wishlist, merge in
     whatever was in the guest's localStorage, and write the merged result
     back to BOTH Firestore and localStorage — so Cart.get()/Wishlist.get()
     (still plain synchronous localStorage reads everywhere else in the app)
     immediately show the right thing on this device too. */
  async _mergeGuestData(uid) {
    try {
      const guestCart = Store.get('at_cart', []);
      const remoteCart = await FirebaseDB.loadUserCart(uid);
      const mergedCart = [...remoteCart];
      guestCart.forEach(g => { const ex = mergedCart.find(m => m.k === g.k); if (ex) ex.qty = Math.min(10, ex.qty + g.qty); else mergedCart.push(g); });
      Store.set('at_cart', mergedCart);
      if (guestCart.length || remoteCart.length) await FirebaseDB.saveUserCart(uid, mergedCart);

      const guestWish = Store.get('at_wish', []);
      const remoteWish = await FirebaseDB.loadUserWishlist(uid);
      const mergedWish = Array.from(new Set([...remoteWish, ...guestWish]));
      Store.set('at_wish', mergedWish);
      if (guestWish.length || remoteWish.length) await FirebaseDB.saveUserWishlist(uid, mergedWish);

      emit('store:change');
    } catch (e) { console.error('Cart/wishlist merge failed', e); }
  },

  /* Keep Firestore in sync with every local cart/wishlist change while signed
     in — Cart.set()/Wishlist writes already emit('store:change'); we just
     listen and push (debounced) instead of touching cart.js/wishlist.js. */
  _syncToFirestore() {
    if (!this.user) return;
    clearTimeout(this._syncTimer);
    this._syncTimer = setTimeout(() => {
      const uid = this.user.uid;
      FirebaseDB.saveUserCart(uid, Store.get('at_cart', [])).catch(() => {});
      FirebaseDB.saveUserWishlist(uid, Store.get('at_wish', [])).catch(() => {});
    }, 600);
  }
};

document.addEventListener('store:change', () => Auth._syncToFirestore());

/* Auto-start: every page that loads auth.js gets 'auth:change' fired as soon
   as Firebase resolves the session, without needing to remember to call
   Auth.onReady() itself. */
Auth.onReady(() => {});
