/* search.js — header search overlay with debounced suggestions.
   Backend phase: suggestions come from a cached, limited Firestore query instead of the sample list. */
App.init(() => {
  const btn = $('#searchBtn'), panel = $('#searchPanel'); if (!btn) return;
  const input = $('#searchInput'), box = $('#suggest'), form = $('#searchForm');
  let idx = -1;
  const popular = ['Helmet', 'Saddle bag', 'Rain suit', 'Phone mount', 'Tool kit'];
  const open = () => { panel.hidden = false; btn.setAttribute('aria-expanded', 'true'); input.focus(); draw(''); };
  const close = () => { panel.hidden = true; btn.setAttribute('aria-expanded', 'false'); };
  const score = (p, q) => {
    const hay = [p.name, p.sku, getBrand(p.brand).name, getCat(p.cat).name, p.tags.join(' ')].join(' ').toLowerCase();
    return q.split(/\s+/).filter(Boolean).every(t => hay.includes(t)) ? (p.name.toLowerCase().startsWith(q) ? 2 : 1) : 0;
  };
  const draw = q => {
    q = q.trim().toLowerCase(); idx = -1;
    if (!q) { box.innerHTML = `<p class="suggest-title">Popular searches</p><div class="chip-row">${popular.map(t => `<a class="chip" href="shop.html?q=${encodeURIComponent(t)}">${t}</a>`).join('')}</div>`; return; }
    const r = PRODUCTS.map(p => [p, score(p, q)]).filter(x => x[1]).sort((a, b) => b[1] - a[1]).slice(0, 6).map(x => x[0]);
    box.innerHTML = r.length
      ? `<ul class="suggest-list" role="listbox">${r.map(p => `<li role="option"><a href="product.html?id=${p.id}"><img src="${imgSrc(p)}" alt="" width="48" height="48"><span><b>${esc(p.name)}</b><small>${esc(getBrand(p.brand).name)} in ${esc(getCat(p.cat).name)}</small></span><strong>${fmt(p.price)}</strong></a></li>`).join('')}</ul><a class="link-u" href="shop.html?q=${encodeURIComponent(q)}">See all results for "${esc(q)}"</a>`
      : `<p class="suggest-title">Nothing matched "${esc(q)}". Try a broader word like "bag" or "gloves".</p>`;
  };
  btn.addEventListener('click', () => (panel.hidden ? open() : close()));
  $('#searchClose').addEventListener('click', close);
  input.addEventListener('input', debounce(() => draw(input.value), 180));
  form.addEventListener('submit', e => { e.preventDefault(); const q = input.value.trim(); if (q) location.href = 'shop.html?q=' + encodeURIComponent(q); });
  input.addEventListener('keydown', e => {
    const items = $$('.suggest-list a', box); if (!items.length) return;
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); idx = (idx + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length; items[idx].focus(); }
  });
  box.addEventListener('keydown', e => { if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { const items = $$('.suggest-list a', box); e.preventDefault(); idx = (idx + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length; items[idx].focus(); } });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !panel.hidden) { close(); btn.focus(); } });
  document.addEventListener('click', e => { if (!panel.hidden && !panel.contains(e.target) && !btn.contains(e.target)) close(); });
});
