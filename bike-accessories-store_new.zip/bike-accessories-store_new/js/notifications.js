/* notifications.js — customer notification bell (spec §51). Admin notifications
   use the same collection filtered by { audience: 'admin' } and are rendered
   from js/admin/dashboard.js. Requires a #notifRoot element with a trigger
   button [data-action="notifs"] and a panel [data-panel="notifs"]. */

App.init(() => {
  const trigger = $('[data-action="notifs"]'); if (!trigger) return;
  const badge = $('[data-count="notif"]');
  let unsub = null;

  document.addEventListener('auth:change', user => {
    if (unsub) unsub();
    if (!user) { if (badge) badge.hidden = true; return; }
    unsub = db.collection(COL.notifications).doc(user.uid).collection('items')
      .orderBy('createdAt', 'desc').limit(20)
      .onSnapshot(snap => {
        const items = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        const unread = items.filter(n => !n.read).length;
        if (badge) { badge.textContent = unread; badge.hidden = !unread; }
        const panel = $('[data-panel="notifs"]');
        if (panel) {
          panel.innerHTML = items.map(n => `<li class="notif${n.read ? '' : ' is-unread'}"><b>${esc(n.title)}</b><p>${esc(n.body)}</p></li>`).join('') || '<li class="muted">No notifications yet.</li>';
        }
      }, err => console.error('Notifications listener failed', err));
  });

  trigger.addEventListener('click', async () => {
    const user = Auth.user; if (!user) return;
    const batch = db.batch();
    const snap = await db.collection(COL.notifications).doc(user.uid).collection('items').where('read', '==', false).limit(20).get();
    snap.forEach(d => batch.update(d.ref, { read: true }));
    if (!snap.empty) batch.commit();
  });
});
