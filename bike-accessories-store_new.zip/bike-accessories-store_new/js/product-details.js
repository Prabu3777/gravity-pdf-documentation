/* product-details.js — product page: gallery, variants, tabs, reviews, Q&A, bought-together, related */
App.init(() => {
  const root = $('#pdp'); if (!root) return;
  const p = getProduct(params().id) || getProduct('p12');
  const b = getBrand(p.brand), c = getCat(p.cat), off = pct(p.mrp, p.price), s = stockInfo(p);
  const st = { color: p.colors[0], opt: p.opts[0] || '', qty: 1, img: 0 };
  const maxQty = Math.max(1, Math.min(p.stock, 10));
  const variantText = () => [st.color, st.opt].filter(Boolean).join(' / ');

  /* SEO: dynamic title, description, canonical, Open Graph, structured data */
  const meta = (k, v, prop) => { let m = $(`meta[${prop ? 'property' : 'name'}="${k}"]`); if (!m) { m = document.createElement('meta'); m.setAttribute(prop ? 'property' : 'name', k); document.head.appendChild(m); } m.content = v; };
  document.title = `${p.name} | ${BRAND.name}`;
  meta('description', p.short + ' ' + p.desc[0].slice(0, 110)); meta('og:title', p.name, 1); meta('og:description', p.short, 1); meta('og:type', 'product', 1);
  const can = $('link[rel="canonical"]'); if (can) can.href = location.origin + location.pathname + '?id=' + p.id;
  const ld = document.createElement('script'); ld.type = 'application/ld+json';
  ld.textContent = JSON.stringify({ '@context': 'https://schema.org', '@type': 'Product', name: p.name, sku: p.sku, brand: { '@type': 'Brand', name: b.name }, description: p.short, aggregateRating: { '@type': 'AggregateRating', ratingValue: p.rating, reviewCount: p.reviews }, offers: { '@type': 'Offer', priceCurrency: 'INR', price: p.price, availability: p.stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock' } });
  document.head.appendChild(ld);

  const dist = [5, 4, 3, 2, 1].map(n => Math.max(1, Math.round(100 * Math.exp(-Math.pow(n - (p.rating + .4), 2) / 1.1)))); const dt = dist.reduce((a, x) => a + x, 0);
  const COMP = { helmets: ['gloves', 'jackets'], gloves: ['helmets', 'jackets'], jackets: ['pants', 'gloves'], pants: ['jackets', 'boots'], boots: ['pants', 'rain-gear'], 'saddle-bags': ['rain-gear', 'touring'], 'tank-bags': ['phone-mounts', 'touring'], 'tail-bags': ['touring', 'rain-gear'], backpacks: ['rain-gear', 'tools'], 'phone-mounts': ['bike-lights', 'tank-bags'], 'bike-lights': ['phone-mounts', 'tools'], 'rain-gear': ['boots', 'bike-covers'], 'bike-covers': ['tools', 'touring'], tools: ['touring', 'bike-lights'], touring: ['tools', 'saddle-bags'] };
  const fbt = [p, ...(COMP[p.cat] || []).map(cid => PRODUCTS.filter(x => x.cat === cid && x.stock > 0).sort((a, z) => z.reviews - a.reviews)[0]).filter(Boolean)];
  const related = PRODUCTS.filter(x => x.id !== p.id && (x.cat === p.cat || x.brand === p.brand)).map(x => [x, x.tags.filter(t => p.tags.includes(t)).length]).sort((a, z) => z[1] - a[1]).slice(0, 4).map(x => x[0]);

  root.innerHTML = `
  <nav class="crumbs" aria-label="Breadcrumb"><a href="index.html">Home</a><a href="shop.html">Shop</a><a href="shop.html?cat=${c.id}">${c.name}</a><span aria-current="page">${esc(p.name)}</span></nav>
  <div class="pdp-grid">
    <div class="gallery">
      <ul class="thumbs" role="list">${[0, 1, 2, 3].map(i => `<li><button data-thumb="${i}" aria-label="Show image ${i + 1}" aria-pressed="${i === 0}"><img src="${imgSrc(p, i)}" alt="" width="88" height="88"></button></li>`).join('')}</ul>
      <figure class="gallery-main" id="gMain"><img id="gImg" class="${PHOTOS[p.id] ? 'real-photo' : ''}" src="${imgSrc(p, 0)}" alt="${esc(p.name)}, image 1 of 4" width="640" height="640">
        <button class="round-btn gallery-full" id="gFull" aria-label="View full screen">${icon('maximize', 18)}</button>
        <div class="pcard-badges">${off ? `<span class="badge badge-accent">${off}% off</span>` : ''}${p.isNew ? '<span class="badge badge-dark">New</span>' : ''}</div></figure>
    </div>
    <div class="pdp-info">
      <a class="pcard-brand" href="shop.html?brand=${b.id}">${esc(b.name)}</a>
      <h1>${esc(p.name)}</h1>
      <a class="pcard-rating" href="#pdpTabs" id="toReviews">${stars(p.rating)}<span><b>${p.rating}</b> (${p.reviews} reviews)</span></a>
      <div class="price big"><span class="price-now">${fmt(p.price)}</span>${off ? `<span class="price-mrp">${fmt(p.mrp)}</span><span class="price-off">${off}% off</span>` : ''}</div>
      <p class="muted">Inclusive of all taxes. Free shipping above ${fmt(FREE_SHIP)}.</p>
      <p>${esc(p.short)}</p>
      <span class="stock ${s.cls}">${s.txt}</span>
      <fieldset class="variant"><legend>Colour: <b id="colorName">${esc(st.color)}</b></legend><div class="swatches">${p.colors.map((col, i) => `<label class="swatch"><input type="radio" name="color" value="${esc(col)}" ${i === 0 ? 'checked' : ''}><span style="background:${COLOR_HEX[col] || '#999'}"></span><span class="sr-only">${esc(col)}</span></label>`).join('')}</div></fieldset>
      ${p.opts.length ? `<fieldset class="variant"><legend>${p.optLabel}: <b id="optName">${esc(st.opt)}</b></legend><div class="chip-row">${p.opts.map((o, i) => `<label class="chip-check"><input type="radio" name="opt" value="${esc(o)}" ${i === 0 ? 'checked' : ''}><span>${esc(o)}</span></label>`).join('')}</div></fieldset>` : ''}
      <p class="muted sku">SKU <span id="skuOut">${p.sku}</span></p>
      <div class="buy-row">
        <div class="qty" role="group" aria-label="Quantity"><button id="qMinus" aria-label="Decrease quantity">${icon('minus', 16)}</button><output id="qOut" aria-live="polite">1</output><button id="qPlus" aria-label="Increase quantity">${icon('plus', 16)}</button></div>
        <button class="btn btn-primary btn-lg grow" id="addBtn" ${p.stock <= 0 ? 'disabled' : ''}>${p.stock <= 0 ? 'Out of stock' : 'Add to cart'}</button>
        <button class="btn btn-dark btn-lg grow" id="buyBtn" ${p.stock <= 0 ? 'disabled' : ''}>Buy now</button>
      </div>
      <div class="buy-row sec">
        <button class="btn btn-outline" data-action="wish" data-id="${p.id}" aria-pressed="false">${icon('heart', 18)} Add to wishlist</button>
        <button class="btn btn-outline" data-action="compare" data-id="${p.id}" aria-pressed="false">${icon('compare', 18)} Compare</button>
      </div>
      <form class="pin-check" id="pinForm" novalidate><label for="pin">Check delivery</label><div><input class="input" id="pin" inputmode="numeric" maxlength="6" placeholder="6-digit pincode"><button class="btn btn-outline">Check</button></div><p id="pinMsg" class="muted"></p></form>
      <ul class="trust"><li>${icon('truck', 20)}<span>Delivery in 2 to 7 working days</span></li><li>${icon('refresh', 20)}<span>7-day easy returns</span></li><li>${icon('shield', 20)}<span>${p.warranty} warranty</span></li></ul>
    </div>
  </div>

  <section class="fbt" aria-labelledby="fbtH"><h2 id="fbtH">Frequently bought together</h2>
    <div class="fbt-row">${fbt.map((x, i) => `${i ? '<span class="fbt-plus" aria-hidden="true">+</span>' : ''}<label class="fbt-item"><input type="checkbox" data-fbt="${x.id}" checked ${i === 0 ? 'disabled' : ''}><img src="${imgSrc(x)}" alt="" width="96" height="96"><span><b>${esc(x.name)}</b><small>${fmt(x.price)}</small></span></label>`).join('')}
      <div class="fbt-total"><span>Combined price</span><strong id="fbtTotal"></strong><button class="btn btn-primary" id="fbtAdd">Add all to cart</button></div></div></section>

  <section class="pdp-tabs" id="pdpTabs">
    <div class="tabs" role="tablist" aria-label="Product information">
      ${[['desc', 'Description'], ['spec', 'Specifications'], ['feat', 'Features'], ['rev', `Reviews (${p.reviews})`], ['qa', 'Questions']].map(([k, t]) => `<button class="tab" role="tab" id="t-${k}" aria-controls="pn-${k}">${t}</button>`).join('')}</div>
    <div role="tabpanel" id="pn-desc" aria-labelledby="t-desc" class="tab-panel prose">${p.desc.map(d => `<p>${esc(d)}</p>`).join('')}</div>
    <div role="tabpanel" id="pn-spec" aria-labelledby="t-spec" class="tab-panel" hidden><table class="spec"><tbody>
      ${[['Brand', b.name], ['Material', p.material], ['Weight', p.weight], ['Waterproof', p.waterproof ? 'Yes' : 'No'], [p.optLabel || 'Size', p.opts.join(', ') || 'One size'], ['Mounting or fit', 'Universal'], ['Compatibility', p.compat.join(', ')], ['Warranty', p.warranty], ['SKU', p.sku]].map(([k, v]) => `<tr><th scope="row">${k}</th><td>${esc(v)}</td></tr>`).join('')}</tbody></table></div>
    <div role="tabpanel" id="pn-feat" aria-labelledby="t-feat" class="tab-panel" hidden><ul class="feat-list">${p.features.map(f => `<li>${icon('check', 18)} ${esc(f)}</li>`).join('')}</ul></div>
    <div role="tabpanel" id="pn-rev" aria-labelledby="t-rev" class="tab-panel" hidden>
      <div class="rev-top"><div class="rev-avg"><strong>${p.rating}</strong>${stars(p.rating)}<span class="muted">${p.reviews} reviews</span></div>
        <ul class="rev-bars">${[5, 4, 3, 2, 1].map((n, i) => `<li><span>${n} star</span><div class="meter"><span style="width:${Math.round(dist[i] / dt * 100)}%"></span></div><span>${Math.round(dist[i] / dt * 100)}%</span></li>`).join('')}</ul>
        <form class="rev-form" data-demo-form="Thanks. Reviews open to verified buyers once accounts are connected." novalidate><h3>Write a review</h3>
          <div class="field"><label for="rvT">Title</label><input class="input" id="rvT" required></div>
          <div class="field"><label for="rvB">Your review</label><textarea class="textarea" id="rvB" rows="3" required></textarea></div>
          <button class="btn btn-dark btn-sm" type="submit">Submit review</button><p class="muted small">Only customers who bought this product can review it.</p></form></div>
      <ul class="rev-list">${REVIEWS.slice(0, 4).map(r => `<li><div class="rev-head">${stars(r.rating)}<b>${esc(r.title)}</b></div><p>${esc(r.text)}</p><p class="muted small">${esc(r.name)}, ${esc(r.city)} on ${r.date} ${r.verified ? `<span class="verified">${icon('check', 14)} Verified purchase</span>` : ''}</p></li>`).join('')}</ul></div>
    <div role="tabpanel" id="pn-qa" aria-labelledby="t-qa" class="tab-panel" hidden>
      <ul class="qa-list">${QA.map(x => `<li><p><b>Q: ${esc(x.q)}</b></p>${x.a ? `<p>A: ${esc(x.a)}</p>` : '<p class="muted">Waiting for an answer from our team.</p>'}<p class="muted small">${esc(x.by)} on ${x.date}</p></li>`).join('')}</ul>
      <form class="qa-form" data-demo-form="Question sent. We will answer within a day." novalidate><label class="sr-only" for="qaIn">Ask a question</label><input class="input" id="qaIn" placeholder="Ask a question about this product" required><button class="btn btn-dark" type="submit">Ask</button></form></div>
  </section>

  <section class="related"><div class="section-head"><h2>You may also like</h2><a class="link-u" href="shop.html?cat=${c.id}">More ${esc(c.name.toLowerCase())}</a></div><div class="grid-products">${related.map(productCard).join('')}</div></section>`;

  initTabs($('#pdpTabs'));
  $('#toReviews').addEventListener('click', () => { $('#t-rev').click(); });

  /* gallery */
  const gImg = $('#gImg'), gMain = $('#gMain');
  const setImg = i => { st.img = i; gImg.src = imgSrc(p, i); gImg.alt = `${p.name}, image ${i + 1} of 4`; $$('[data-thumb]').forEach(t => t.setAttribute('aria-pressed', +t.dataset.thumb === i)); };
  $$('[data-thumb]').forEach(t => t.addEventListener('click', () => setImg(+t.dataset.thumb)));
  gMain.addEventListener('mousemove', e => { const r = gMain.getBoundingClientRect(); gImg.style.transformOrigin = `${(e.clientX - r.left) / r.width * 100}% ${(e.clientY - r.top) / r.height * 100}%`; gMain.classList.add('is-zoom'); });
  gMain.addEventListener('mouseleave', () => gMain.classList.remove('is-zoom'));
  $('#gFull').addEventListener('click', () => {
    Modal.open(`<div class="lb"><button class="round-btn lb-nav prev" id="lbPrev" aria-label="Previous image">${icon('left', 22)}</button><img id="lbImg" src="${imgSrc(p, st.img)}" alt="${esc(p.name)} enlarged"><button class="round-btn lb-nav next" id="lbNext" aria-label="Next image">${icon('right', 22)}</button></div>`, { label: 'Image viewer', cls: 'modal-full' });
    const go = d => { setImg((st.img + d + 4) % 4); const im = $('#lbImg'); if (im) im.src = imgSrc(p, st.img); };
    $('#lbPrev').addEventListener('click', () => go(-1)); $('#lbNext').addEventListener('click', () => go(1));
    const key = e => { if (!$('#lbImg')) { document.removeEventListener('keydown', key); return; } if (e.key === 'ArrowLeft') go(-1); if (e.key === 'ArrowRight') go(1); };
    document.addEventListener('keydown', key);
  });

  /* variants and quantity */
  root.addEventListener('change', e => {
    if (e.target.name === 'color') { st.color = e.target.value; $('#colorName').textContent = st.color; }
    if (e.target.name === 'opt') { st.opt = e.target.value; $('#optName').textContent = st.opt; }
    $('#skuOut').textContent = p.sku + (st.opt ? '-' + st.opt.replace(/\s/g, '') : '') + '-' + st.color.slice(0, 3).toUpperCase();
  });
  $('#qMinus').addEventListener('click', () => { st.qty = Math.max(1, st.qty - 1); $('#qOut').textContent = st.qty; });
  $('#qPlus').addEventListener('click', () => { if (st.qty >= maxQty) toast('Maximum ' + maxQty + ' per order for this item.', 'info'); st.qty = Math.min(maxQty, st.qty + 1); $('#qOut').textContent = st.qty; });
  $('#addBtn').addEventListener('click', () => { if (Cart.add(p.id, st.qty, variantText())) toast('Added to cart'); });
  $('#buyBtn').addEventListener('click', () => { if (Cart.add(p.id, st.qty, variantText())) location.href = 'checkout.html'; });
  $('#pinForm').addEventListener('submit', e => {
    e.preventDefault(); const v = $('#pin').value.trim(), m = $('#pinMsg');
    if (!/^\d{6}$/.test(v)) { m.textContent = 'Enter a valid 6-digit pincode.'; m.className = 'err small'; return; }
    const d = new Date(Date.now() + 4 * 864e5); m.className = 'ok small'; m.textContent = 'Delivery to ' + v + ' by ' + d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' }) + '.';
  });

  /* bought together */
  const fbtTotal = () => { const ids = $$('[data-fbt]:checked').map(i => i.dataset.fbt), t = ids.reduce((n, id) => n + getProduct(id).price, 0); $('#fbtTotal').textContent = fmt(t); return ids; };
  fbtTotal(); $$('[data-fbt]').forEach(i => i.addEventListener('change', fbtTotal));
  $('#fbtAdd').addEventListener('click', () => { const ids = fbtTotal(); ids.forEach(id => Cart.add(id, 1, id === p.id ? variantText() : '')); toast(ids.length + ' items added to cart'); });
  syncStates();
});
