/* data.js — SAMPLE DATA for the UI preview only.
   In the backend phase every list below is replaced by Firestore reads. */
const BRAND = { name: 'TN11 BIKERZZ', tagline: 'Gear Up. Explore. Ride More.', email: 'hello@tn11bikerzz.com', phone: '+91 90000 00000', address: 'Store address, City, State - PIN', logo: 'assets/logo.png' };

const BRANDS = [
  { id: 'ridgeback', name: 'Ridgeback', desc: 'Touring luggage built in Pune' },
  { id: 'kestrel', name: 'Kestrel Moto', desc: 'Protective riding gear' },
  { id: 'ironroute', name: 'IronRoute', desc: 'Helmets, tools and electronics' },
  { id: 'trailhawk', name: 'TrailHawk', desc: 'Off-road and adventure kit' },
  { id: 'nomadforge', name: 'Nomad Forge', desc: 'Long-distance touring gear' }
];

const CATEGORIES = [
  { id: 'helmets', name: 'Helmets', glyph: 'helmet', desc: 'Certified protection for every road.' },
  { id: 'gloves', name: 'Riding Gloves', glyph: 'glove', desc: 'Grip, comfort and knuckle armour.' },
  { id: 'jackets', name: 'Riding Jackets', glyph: 'jacket', desc: 'Armoured jackets for all seasons.' },
  { id: 'pants', name: 'Riding Pants', glyph: 'pants', desc: 'Breathable, armoured, hard-wearing.' },
  { id: 'boots', name: 'Riding Boots', glyph: 'boot', desc: 'Ankle support for long days.' },
  { id: 'saddle-bags', name: 'Saddle Bags', glyph: 'bag', desc: 'Waterproof side luggage.' },
  { id: 'tank-bags', name: 'Tank Bags', glyph: 'tank', desc: 'Quick-access magnetic storage.' },
  { id: 'tail-bags', name: 'Tail Bags', glyph: 'roll', desc: 'Big-capacity rear luggage.' },
  { id: 'backpacks', name: 'Backpacks', glyph: 'pack', desc: 'Rider-friendly day carriers.' },
  { id: 'phone-mounts', name: 'Phone Mounts', glyph: 'phone', desc: 'Mounts and USB chargers.' },
  { id: 'bike-lights', name: 'Bike Lights', glyph: 'light', desc: 'See further, be seen sooner.' },
  { id: 'rain-gear', name: 'Rain Gear', glyph: 'rain', desc: 'Stay dry when the sky opens up.' },
  { id: 'bike-covers', name: 'Bike Covers', glyph: 'cover', desc: 'Dust and weather protection.' },
  { id: 'tools', name: 'Tools', glyph: 'tool', desc: 'Roadside kits and repair gear.' },
  { id: 'touring', name: 'Touring Accessories', glyph: 'compass', desc: 'Straps, safety and travel gear.' }
];

const COLOR_HEX = { 'Matte Black': '#1b1d20', Titanium: '#8a8f96', Crimson: '#b3261e', Black: '#16181b', Grey: '#8b8f94', Tan: '#b88a5a', Olive: '#5b6440', Navy: '#1f2e4d', 'Hi-Vis': '#c6e21a', Silver: '#c3c7cc', Orange: '#e8700e' };

/* opts | option label | colours | material | weight | warranty | waterproof | features */
const GROUPS = {
  helmets: ['S,M,L,XL', 'Size', 'Matte Black,Titanium,Crimson', 'ABS shell, EPS liner', '1.4 kg', '2 Years', 0, 'ISI and DOT certified shell|Anti-fog, Pinlock-ready visor|Quick-release ventilation|Removable, washable liner|Low-noise aerodynamic shape'],
  gloves: ['S,M,L,XL', 'Size', 'Black,Grey,Tan', 'Goat leather, mesh', '0.25 kg', '6 Months', 0, 'Knuckle and palm protection|Touchscreen-friendly fingertips|Pre-curved ergonomic fit|Reflective piping|Secure wrist closure'],
  jackets: ['S,M,L,XL,XXL', 'Size', 'Black,Olive,Grey', 'Cordura nylon, CE armour', '2.1 kg', '1 Year', 1, 'CE Level 2 shoulder and elbow armour|Removable thermal liner|Waterproof membrane|Reflective panels|Ventilation zips'],
  pants: ['30,32,34,36,38', 'Waist', 'Black,Olive,Grey', 'Cordura nylon, CE armour', '1.6 kg', '1 Year', 0, 'CE knee and hip armour|Adjustable waist and cuffs|Zippered thigh vents|Reinforced seat panel|Reflective details'],
  boots: ['UK 7,UK 8,UK 9,UK 10,UK 11', 'Size', 'Black,Tan', 'Full-grain leather, TPU', '1.7 kg', '1 Year', 1, 'Reinforced ankle and shin|Oil-resistant grip sole|Waterproof membrane|Quick-lace closure|Gear shift pad'],
  'saddle-bags': ['20L,30L,40L', 'Capacity', 'Black,Olive,Grey', '600D nylon, TPU coating', '1.2 kg', '1 Year', 1, 'Waterproof roll-top closure|UV resistant fabric|Reflective strip|Universal fit straps|Lightweight frame'],
  'tank-bags': ['10L,12L,20L', 'Capacity', 'Black,Grey', '600D nylon, TPU coating', '0.9 kg', '1 Year', 1, 'Strong magnetic base|Clear map pocket|Rain cover included|Shoulder strap|Quick-release buckle'],
  'tail-bags': ['30L,40L,50L', 'Capacity', 'Black,Olive', '840D nylon, TPU coating', '1.5 kg', '1 Year', 1, 'Roll-top waterproof closure|Compression straps|Reflective strip|Fits pillion seat|Removable shoulder strap'],
  backpacks: ['15L,25L,32L', 'Capacity', 'Black,Grey,Olive', '500D nylon, foam back panel', '1.0 kg', '1 Year', 0, 'Padded back and straps|Hydration-bladder sleeve|Helmet carry loop|Rain cover included|Chest and waist straps'],
  'phone-mounts': ['', '', 'Black,Silver', 'Aluminium, silicone', '0.2 kg', '1 Year', 0, 'Fits 4.7 to 7 inch phones|Vibration dampener|One-hand release|360 degree rotation|Universal handlebar clamp'],
  'bike-lights': ['', '', 'Black', 'Die-cast aluminium', '0.6 kg', '1 Year', 1, 'IP67 waterproof|Spot and flood modes|Easy wiring harness|Heat-dissipating body|Universal mounting brackets'],
  'rain-gear': ['M,L,XL,XXL', 'Size', 'Navy,Hi-Vis,Black', 'PU-coated nylon', '0.8 kg', '6 Months', 1, 'Fully seam-sealed|Packs into a small pouch|Reflective piping|Adjustable hood, cuffs and hem|Zip and storm flap'],
  'bike-covers': ['M,L,XL', 'Size', 'Grey,Black', 'Polyester, PU coating', '0.9 kg', '6 Months', 1, 'Water and dust proof|Lock-loop and wind straps|Elasticated hem|Heat-resistant exhaust patch|Carry pouch included'],
  tools: ['', '', 'Black', 'Chrome vanadium steel', '1.1 kg', '2 Years', 0, 'Hardened steel bits|Compact roll case|Fits most motorcycles|Tyre lever included|Corrosion resistant'],
  touring: ['', '', 'Black,Orange', 'Nylon, steel hooks', '0.4 kg', '6 Months', 0, 'High-strength construction|Reflective elements|Compact and light|Universal use|Easy stowing']
};

const COMPAT = ['Universal', 'Royal Enfield', 'KTM / Duke', 'Honda', 'Yamaha', 'Bajaj / TVS'];

/* name, category, brand, mrp, price, rating, reviews, stock, flags (F featured, B best seller, N new) */
const RAW = [
  ['Voyager Modular Helmet', 'helmets', 'ironroute', 12999, 9499, 4.7, 312, 24, 'FB'],
  ['Ridgeline Full-Face Helmet', 'helmets', 'kestrel', 8999, 6799, 4.5, 208, 6, 'N'],
  ['Scout Dual-Sport Helmet', 'helmets', 'trailhawk', 10499, 7999, 4.6, 145, 0, ''],
  ['Summit Touring Gloves', 'gloves', 'kestrel', 3999, 2799, 4.6, 421, 40, 'B'],
  ['Ridge Mesh Riding Gloves', 'gloves', 'ironroute', 2499, 1699, 4.3, 176, 58, 'N'],
  ['Expedition Riding Jacket', 'jackets', 'ridgeback', 15999, 11999, 4.8, 264, 12, 'FB'],
  ['Urban Commuter Jacket', 'jackets', 'trailhawk', 8999, 6299, 4.4, 133, 3, ''],
  ['Trail Armoured Riding Pants', 'pants', 'ironroute', 9499, 6999, 4.5, 98, 15, ''],
  ['Cargo Touring Pants', 'pants', 'nomadforge', 7999, 5799, 4.4, 64, 22, 'N'],
  ['Grit Adventure Boots', 'boots', 'trailhawk', 11999, 8999, 4.7, 187, 9, 'F'],
  ['Roadster Short Boots', 'boots', 'kestrel', 6499, 4699, 4.2, 91, 30, ''],
  ['Adventure Waterproof Saddle Bag', 'saddle-bags', 'ridgeback', 3499, 2499, 4.8, 536, 45, 'FB'],
  ['Pannier Duo Set', 'saddle-bags', 'nomadforge', 8999, 6499, 4.6, 158, 14, ''],
  ['Magnetic Tank Bag', 'tank-bags', 'ridgeback', 2999, 2199, 4.5, 302, 33, 'B'],
  ['Tank Bag Pro', 'tank-bags', 'kestrel', 4499, 3299, 4.6, 120, 8, 'N'],
  ['Expedition Tail Bag', 'tail-bags', 'nomadforge', 5999, 4299, 4.7, 244, 19, 'FB'],
  ['Roll-Top Tail Bag', 'tail-bags', 'ridgeback', 4299, 3099, 4.4, 87, 26, ''],
  ['Summit Rider Backpack', 'backpacks', 'trailhawk', 4999, 3599, 4.5, 213, 28, ''],
  ['Hydra Hydration Pack', 'backpacks', 'ironroute', 3299, 2399, 4.3, 76, 4, 'N'],
  ['Grip Pro Phone Mount', 'phone-mounts', 'kestrel', 1999, 1299, 4.5, 689, 120, 'B'],
  ['Dual USB-C Bike Charger', 'phone-mounts', 'ironroute', 1499, 999, 4.4, 402, 85, 'N'],
  ['Beam X Auxiliary Light Pair', 'bike-lights', 'trailhawk', 3499, 2499, 4.6, 331, 37, 'F'],
  ['Halo LED Fog Lights', 'bike-lights', 'kestrel', 2999, 2099, 4.3, 118, 52, ''],
  ['Monsoon Rain Suit', 'rain-gear', 'ridgeback', 3999, 2799, 4.5, 275, 44, 'BF'],
  ['Storm Shield Boot Covers', 'rain-gear', 'nomadforge', 1299, 899, 4.2, 66, 60, ''],
  ['All-Weather Bike Cover', 'bike-covers', 'ironroute', 1999, 1399, 4.4, 154, 70, ''],
  ['Roadside Tool Kit 32-in-1', 'tools', 'ironroute', 2499, 1799, 4.6, 227, 41, 'N'],
  ['Tyre Repair and Inflator Kit', 'tools', 'kestrel', 2299, 1599, 4.5, 143, 5, ''],
  ['Ratchet Bungee Strap Set', 'touring', 'nomadforge', 999, 699, 4.7, 388, 150, 'B'],
  ['Reflective Safety Vest', 'touring', 'trailhawk', 899, 599, 4.3, 92, 75, 'N']
];

const PRODUCTS = RAW.map((r, i) => {
  const [name, cat, brand, mrp, price, rating, reviews, stock, fl] = r;
  const g = GROUPS[cat], c = CATEGORIES.find(x => x.id === cat), n = i + 1;
  const opts = g[0] ? g[0].split(',') : [];
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  const bname = BRANDS.find(b => b.id === brand).name;
  const compat = ['Universal', COMPAT[1 + (i % 5)]];
  const waterproof = !!g[6] || /Waterproof|Rain/.test(name);
  return {
    id: 'p' + String(n).padStart(2, '0'), slug, name, cat, brand, mrp, price, rating, reviews, stock, low: 5,
    sku: 'AT-' + cat.slice(0, 3).toUpperCase() + '-' + (100 + n),
    isFeatured: fl.includes('F'), isBest: fl.includes('B'), isNew: fl.includes('N'), active: true,
    created: '2026-' + String(9 - Math.floor((RAW.length - i) / 8)).padStart(2, '0') + '-' + String(1 + (i * 3) % 27).padStart(2, '0'),
    optLabel: g[1], opts, colors: g[2].split(','), material: g[3], weight: g[4], warranty: g[5], waterproof, compat,
    features: g[7].split('|'),
    short: `${c.desc} By ${bname}.`,
    desc: [`${name} is engineered by ${bname} for riders who cover real distance. Every seam, buckle and fastener is tested on Indian roads, from monsoon highways to high-altitude passes, so it keeps performing trip after trip.`, `Designed to work with the rest of your setup: it pairs cleanly with other ${bname} gear and fits a wide range of motorcycles. Backed by a ${g[5].toLowerCase()} warranty.`],
    tags: [cat, brand, ...(waterproof ? ['waterproof'] : []), ...(fl.includes('N') ? ['new'] : [])]
  };
});

const COLLECTIONS = [
  { id: 'weekend-ride', name: 'Weekend ride', desc: 'Light kit for quick escapes.', cats: ['tank-bags', 'phone-mounts', 'gloves'], glyph: 'compass' },
  { id: 'long-distance', name: 'Long distance', desc: 'Comfort and cargo for big mileage.', cats: ['tail-bags', 'saddle-bags', 'jackets'], glyph: 'roll' },
  { id: 'adventure-touring', name: 'Adventure touring', desc: 'Built for the unpaved.', cats: ['boots', 'pants', 'touring'], glyph: 'boot' },
  { id: 'monsoon-ready', name: 'Monsoon ready', desc: 'Dry, visible and covered.', cats: ['rain-gear', 'bike-covers', 'bike-lights'], glyph: 'rain' },
  { id: 'daily-commute', name: 'Daily commute', desc: 'Everyday essentials.', cats: ['helmets', 'backpacks', 'phone-mounts'], glyph: 'pack' },
  { id: 'off-road', name: 'Off-road', desc: 'Protection and repair for the trail.', cats: ['helmets', 'boots', 'tools'], glyph: 'tool' }
];

const REVIEWS = [
  { name: 'Arjun K.', city: 'Bengaluru', rating: 5, date: '12 Sep 2026', title: 'Survived 2,400 km of Ladakh', text: 'Rain, dust and river crossings. Nothing leaked and the straps never slipped. Easily the best luggage I have owned.', product: 'p12', verified: true },
  { name: 'Meera S.', city: 'Pune', rating: 5, date: '03 Sep 2026', title: 'Finally a jacket that fits', text: 'The armour sits properly and the vents actually work in humid weather. Sizing is accurate.', product: 'p06', verified: true },
  { name: 'Rahul D.', city: 'Chennai', rating: 4, date: '28 Aug 2026', title: 'Solid for the price', text: 'Good build and quick delivery. The visor could use a stronger click but it is a small thing.', product: 'p01', verified: true },
  { name: 'Sanjay P.', city: 'Hyderabad', rating: 5, date: '19 Aug 2026', title: 'Phone has not moved once', text: 'Ran it over broken roads for a week. Grip is firm and one-hand release is handy at fuel stops.', product: 'p20', verified: true },
  { name: 'Divya R.', city: 'Kochi', rating: 4, date: '07 Aug 2026', title: 'Kept me dry in the ghats', text: 'Seams held through hours of heavy rain. Packs down small too.', product: 'p24', verified: false }
];

const QA = [
  { q: 'Will this fit a Royal Enfield Himalayan?', a: 'Yes. It uses universal straps and fits the Himalayan without a rack.', by: 'Vikram', date: '10 Sep 2026' },
  { q: 'Is a rain cover included in the box?', a: 'The product itself is waterproof, so a separate rain cover is not needed.', by: 'Ananya', date: '02 Sep 2026' },
  { q: 'How long is the warranty claim process?', a: '', by: 'Karthik', date: '18 Sep 2026' }
];

const FAQS = [
  { q: 'How long does delivery take?', a: 'Most orders reach metro cities in 2 to 4 working days and the rest of India in 4 to 7 working days.' },
  { q: 'Can I return an item?', a: 'Yes. Unused items in original packaging can be returned within 7 days of delivery. Helmets and innerwear are exchange-only for hygiene reasons.' },
  { q: 'How do I know which size to pick?', a: 'Each product page lists its size guide. If you are between sizes, choose the larger one for jackets and the smaller one for helmets.' },
  { q: 'Which payment methods do you accept?', a: 'UPI, credit and debit cards, net banking and popular wallets, processed securely by Razorpay.' },
  { q: 'Do you offer warranty?', a: 'Most products carry a 6 month to 2 year manufacturer warranty. Check the specifications tab on the product page.' },
  { q: 'How can I track my order?', a: 'Open Orders in your account to see a live timeline for every order, including courier tracking once it ships.' }
];

const ORDER_FLOW = ['Pending', 'Confirmed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];

const ADDRESSES = [
  { id: 'a1', name: 'Rider Sample', phone: '90000 00000', line: '14, Sample Street', area: 'Sample Nagar', city: 'Chennai', state: 'Tamil Nadu', pin: '600001', country: 'India', def: true },
  { id: 'a2', name: 'Rider Sample', phone: '90000 00000', line: 'Flat 3B, Example Residency', area: 'Example Colony', city: 'Bengaluru', state: 'Karnataka', pin: '560001', country: 'India', def: false }
];

const ORDERS = [
  { id: 'AT-100533', date: '20 Sep 2026', status: 'Confirmed', pay: 'Paid', method: 'UPI', items: [['p01', 1, 'L'], ['p04', 1, 'M']] },
  { id: 'AT-100517', date: '17 Sep 2026', status: 'Shipped', pay: 'Paid', method: 'Card', items: [['p06', 1, 'L']] },
  { id: 'AT-100482', date: '9 Sep 2026', status: 'Delivered', pay: 'Paid', method: 'UPI', items: [['p12', 1, '30L'], ['p29', 2, '']] }
];

const NOTIFICATIONS = [
  { t: 'Order shipped', d: 'AT-100517 is on its way with the courier.', time: '2 hours ago', icon: 'truck' },
  { t: 'Payment successful', d: 'We received your payment for AT-100533.', time: 'Yesterday', icon: 'check' },
  { t: 'Order delivered', d: 'AT-100482 was delivered. Tell others what you think.', time: '12 Sep', icon: 'package' }
];

/* Real product photography, where we have it. Everything else keeps the
   illustrated placeholder tile until real photos are shot for the rest of the catalog. */
const PHOTOS = { p01: 'assets/sample-helmet.png', p06: 'assets/sample-jacket.png' };

const getProduct = id => PRODUCTS.find(p => p.id === id);
const getBrand = id => BRANDS.find(b => b.id === id);
const getCat = id => CATEGORIES.find(c => c.id === id);
