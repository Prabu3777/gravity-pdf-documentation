/* checkout.js — 5-step checkout UI wired to Razorpay via the createRazorpayOrder
   and verifyRazorpayPayment Cloud Functions (see functions/index.js). Order
   creation, stock checks and coupon validation all happen server-side. */
App.init(() => {
  const form = $('#coForm'); if (!form) return;
  const steps = $$('.co-panel', form), stepper = $$('#stepper li'), back = $('#coBack'), next = $('#coNext'), sumEl = $('#coSummary');
  let cur = 0, ship = 'standard';
  const shipCost = () => { const s = Cart.summary(0); return ship === 'express' ? 299 : (s.subtotal - s.discount >= FREE_SHIP ? 0 : SHIP_FEE); };
  const sum = () => Cart.summary(shipCost());

  const drawSummary = () => {
    const s = sum();
    sumEl.innerHTML = `<h2>Your order</h2><ul class="co-items">${s.lines.map(l => `<li><img src="${imgSrc(l.p)}" alt="" width="56" height="56"><span><b>${esc(l.p.name)}</b><small>${l.variant ? esc(l.variant) + ', ' : ''}Qty ${l.qty}</small></span><strong>${fmt(l.total)}</strong></li>`).join('')}</ul>${summaryRows(s)}`;
  };
  const drawReview = () => {
    const s = sum(), f = new FormData(form);
    $('#reviewBox').innerHTML = `<div class="review-cols">
      <div><h3>Contact</h3><p>${esc(f.get('name') || '')}<br>${esc(f.get('email') || '')}<br>${esc(f.get('phone') || '')}</p></div>
      <div><h3>Ship to</h3><p>${esc(f.get('line') || '')}, ${esc(f.get('area') || '')}<br>${esc(f.get('city') || '')}, ${esc(f.get('state') || '')} ${esc(f.get('pin') || '')}</p></div>
      <div><h3>Delivery</h3><p>${ship === 'express' ? 'Express, 2 to 3 working days' : 'Standard, 5 to 7 working days'}</p></div></div>
      <ul class="co-items">${s.lines.map(l => `<li><img src="${imgSrc(l.p)}" alt="" width="56" height="56"><span><b>${esc(l.p.name)}</b><small>${l.variant ? esc(l.variant) + ', ' : ''}Qty ${l.qty}</small></span><strong>${fmt(l.total)}</strong></li>`).join('')}</ul>`;
    $('#payAmt').textContent = fmt(s.total);
  };
  const go = n => {
    cur = n; steps.forEach((p, i) => p.hidden = i !== n);
    stepper.forEach((li, i) => { li.classList.toggle('is-done', i < n); li.classList.toggle('is-current', i === n); if (i === n) li.setAttribute('aria-current', 'step'); else li.removeAttribute('aria-current'); });
    back.hidden = n === 0; next.hidden = n === 4;
    next.textContent = n === 3 ? 'Continue to payment' : 'Continue';
    if (n === 3) drawReview(); drawSummary();
    steps[n].querySelector('h2').focus();
  };
  const empty = () => { $('#coWrap').innerHTML = emptyState({ ico: 'cart', title: 'Your next adventure starts here.', text: 'Your cart is empty, so there is nothing to check out yet.', btn: 'Start shopping', href: 'shop.html' }); };
  if (!Cart.lines().length && !params().result) { empty(); return; }

  next.addEventListener('click', () => { if (validateFields(steps[cur])) go(cur + 1); });
  back.addEventListener('click', () => go(cur - 1));
  $$('input[name="ship"]').forEach(r => r.addEventListener('change', () => { ship = r.value; drawSummary(); }));
  $$('[data-edit]').forEach(b => b.addEventListener('click', () => go(+b.dataset.edit)));
  form.addEventListener('submit', e => e.preventDefault());

  const result = (kind, extra) => {
    const num = (extra && extra.orderNumber) || 'AT-' + (100534 + Math.floor(Math.random() * 90));
    const T = {
      success: ['check', 'Order placed. Thank you!', `Your order <b>${num}</b> is confirmed. We have sent the details to your email and will notify you when it ships.`, [['View order', 'orders.html', 'btn-primary'], ['Keep shopping', 'shop.html', 'btn-outline']]],
      failed: ['x', 'Payment failed', 'Your bank declined the payment and you have not been charged. Try another method or check your card details.', [['Try again', 'checkout.html', 'btn-primary'], ['Back to cart', 'cart.html', 'btn-outline']]],
      cancelled: ['x', 'Payment cancelled', 'You closed the payment window. Your cart is saved, so you can pick up where you left off.', [['Return to checkout', 'checkout.html', 'btn-primary'], ['Back to cart', 'cart.html', 'btn-outline']]],
      pending: ['clock', 'Payment pending', 'Your bank is still confirming the payment. We will email you as soon as it clears, usually within 15 minutes.', [['View orders', 'orders.html', 'btn-primary'], ['Keep shopping', 'shop.html', 'btn-outline']]]
    }[kind];
    if (kind === 'success') Cart.clear();
    $('#coWrap').innerHTML = `<div class="result ${kind}"><div class="empty-art">${icon(T[0], 40)}</div><h1 tabindex="-1" id="resH">${T[1]}</h1><p>${T[2]}</p><div class="row">${T[3].map(([t, h, c]) => `<a class="btn ${c}" href="${h}">${t}</a>`).join('')}</div></div>`;
    $('#resH').focus();
  };

  async function payNow(e) {
    const btn = e.currentTarget;
    if (!Auth.user) { toast('Please sign in to place your order.', 'error'); location.href = 'login.html'; return; }
    if (typeof Razorpay === 'undefined') { toast('Payment could not load. Check your connection and try again.', 'error'); return; }
    btn.classList.add('is-loading');
    const f = new FormData(form);
    const address = { name: f.get('name') || '', phone: f.get('phone') || '', email: f.get('email') || '', line: f.get('line') || '', area: f.get('area') || '', city: f.get('city') || '', state: f.get('state') || '', pin: f.get('pin') || '', country: 'India' };
    const items = Cart.get().map(i => ({ productId: i.id, variant: i.variant || '', qty: i.qty }));
    const couponCode = Cart.coupon() || undefined;

    try {
      const createOrder = firebase.functions().httpsCallable('createRazorpayOrder');
      const { data: order } = await createOrder({ items, address, couponCode });
      const rzp = new Razorpay({
        key: RAZORPAY_KEY_ID, amount: order.amount, currency: order.currency, order_id: order.razorpayOrderId,
        name: BRAND.name, description: 'Order payment', image: BRAND.logo,
        prefill: { name: address.name, email: address.email, contact: address.phone },
        theme: { color: '#F2A900' },
        handler: async resp => {
          try {
            const verify = firebase.functions().httpsCallable('verifyRazorpayPayment');
            await verify({ orderId: order.orderId, razorpay_order_id: resp.razorpay_order_id, razorpay_payment_id: resp.razorpay_payment_id, razorpay_signature: resp.razorpay_signature });
            result('success', { orderNumber: order.orderId });
          } catch (err) { result('failed'); }
        },
        modal: { ondismiss: () => { btn.classList.remove('is-loading'); result('cancelled'); } }
      });
      rzp.on('payment.failed', () => result('failed'));
      rzp.open();
    } catch (err) {
      btn.classList.remove('is-loading');
      toast(err.message || 'Could not start payment. Please try again.', 'error');
    }
  }
  $('#payBtn').addEventListener('click', payNow);
  if (params().result) { result(params().result); return; }
  go(0);
});
