/* compare.js — compare up to 4 products, highlight differences */
const Compare = {
  KEY: 'at_compare', MAX: 4,
  get() { return Store.get(Compare.KEY, []); },
  has(id) { return Compare.get().includes(id); },
  toggle(id) {
    let l = Compare.get();
    if (l.includes(id)) { l = l.filter(x => x !== id); toast('Removed from compare', 'info'); }
    else if (l.length >= Compare.MAX) { toast('You can compare up to ' + Compare.MAX + ' products.', 'error'); return; }
    else { l.push(id); toast('Added to compare'); }
    Store.set(Compare.KEY, l); emit('store:change');
  }
};
App.init(() => {
  const el = $('#compareRoot'); if (!el) return;
  const draw = () => {
    const l = Compare.get().map(getProduct).filter(Boolean);
    if (l.length < 2) { el.innerHTML = emptyState({ ico: 'compare', title: l.length ? 'Add one more product to compare.' : 'Nothing to compare yet.', text: 'Use the compare icon on any product card to pick up to four items.', btn: 'Browse gear', href: 'shop.html' }); return; }
    const rows = [
      ['Price', p => fmt(p.price)], ['Brand', p => getBrand(p.brand).name], ['Rating', p => p.rating + ' (' + p.reviews + ')'],
      ['Material', p => p.material], ['Weight', p => p.weight], ['Capacity or size', p => p.opts.join(', ') || 'One size'],
      ['Waterproof', p => (p.waterproof ? 'Yes' : 'No')], ['Colours', p => p.colors.join(', ')], ['Compatibility', p => p.compat.join(', ')],
      ['Warranty', p => p.warranty], ['Features', p => p.features.slice(0, 3).join('; ')]
    ];
    el.innerHTML = `<p class="muted">Rows with differences are highlighted.</p><div class="table-scroll"><table class="cmp"><thead><tr><th scope="col"><span class="sr-only">Attribute</span></th>${l.map(p => `<th scope="col"><a href="product.html?id=${p.id}"><img src="${imgSrc(p)}" alt="" width="160" height="160"><span>${esc(p.name)}</span></a><div class="cmp-actions"><button class="btn btn-primary btn-sm" data-action="add-cart" data-id="${p.id}" ${p.stock <= 0 ? 'disabled' : ''}>Add to cart</button><button class="link-u" data-cmp-rm="${p.id}">Remove</button></div></th>`).join('')}</tr></thead>
    <tbody>${rows.map(([t, f]) => { const v = l.map(f), diff = new Set(v).size > 1; return `<tr class="${diff ? 'diff' : ''}"><th scope="row">${t}</th>${v.map(x => `<td>${esc(x)}</td>`).join('')}</tr>`; }).join('')}</tbody></table></div>`;
  };
  draw();
  el.addEventListener('click', e => { const r = e.target.closest('[data-cmp-rm]'); if (r) { Compare.toggle(r.dataset.cmpRm); draw(); } });
});
