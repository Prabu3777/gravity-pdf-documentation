/* products.js — product card, quick view, shop listing (search, filters, sort, pagination) */
function stockInfo(p) {
  if (p.stock <= 0) return { cls: 'out', txt: 'Out of stock' };
  if (p.stock <= (p.low || 5)) return { cls: 'low', txt: 'Only ' + p.stock + ' left' };
  return { cls: 'in', txt: 'In stock' };
}

function productCard(p) {
  const off = pct(p.mrp, p.price), s = stockInfo(p), b = getBrand(p.brand);
  return `<article class="pcard" data-id="${p.id}">
    <div class="pcard-media">
      <a href="product.html?id=${p.id}" tabindex="-1" aria-hidden="true"><img class="${PHOTOS[p.id] ? 'real-photo' : ''}" src="${imgSrc(p)}" alt="" loading="lazy" width="400" height="400"></a>
      <div class="pcard-badges">${off ? `<span class="badge badge-accent">${off}% off</span>` : ''}${p.isNew ? '<span class="badge badge-dark">New</span>' : ''}</div>
      <button class="round-btn pcard-wish" data-action="wish" data-id="${p.id}" aria-pressed="false" aria-label="Add ${esc(p.name)} to wishlist">${icon('heart', 18)}</button>
      <div class="pcard-quick">
        <button class="btn btn-light btn-sm" data-action="quickview" data-id="${p.id}">Quick view</button>
        <button class="sq-btn" data-action="compare" data-id="${p.id}" aria-pressed="false" aria-label="Compare ${esc(p.name)}">${icon('compare', 18)}</button>
      </div>
    </div>
    <div class="pcard-body">
      <span class="pcard-brand">${esc(b.name)}</span>
      <h3 class="pcard-name"><a href="product.html?id=${p.id}">${esc(p.name)}</a></h3>
      <div class="pcard-rating">${stars(p.rating)}<span><b>${p.rating}</b> (${p.reviews})</span></div>
      <div class="price"><span class="price-now">${fmt(p.price)}</span>${off ? `<span class="price-mrp">${fmt(p.mrp)}</span><span class="price-off">${off}% off</span>` : ''}</div>
      <span class="stock ${s.cls}">${s.txt}</span>
    </div>
    <button class="btn btn-outline btn-sm btn-block pcard-add" data-action="add-cart" data-id="${p.id}" ${p.stock <= 0 ? 'disabled' : ''}>${p.stock <= 0 ? 'Sold out' : 'Add to cart'}</button>
  </article>`;
}

function openQuickView(id) {
  const p = getProduct(id); if (!p) return;
  const off = pct(p.mrp, p.price), s = stockInfo(p);
  Modal.open(`<div class="qv">
    <div class="qv-media"><img class="${PHOTOS[p.id] ? 'real-photo' : ''}" src="${imgSrc(p)}" alt="${esc(p.name)}"></div>
    <div class="qv-body">
      <span class="pcard-brand">${esc(getBrand(p.brand).name)}</span>
      <h2>${esc(p.name)}</h2>
      <div class="pcard-rating">${stars(p.rating)}<span><b>${p.rating}</b> (${p.reviews} reviews)</span></div>
      <div class="price"><span class="price-now">${fmt(p.price)}</span>${off ? `<span class="price-mrp">${fmt(p.mrp)}</span><span class="price-off">${off}% off</span>` : ''}</div>
      <p>${esc(p.short)} ${esc(p.desc[0])}</p>
      <span class="stock ${s.cls}">${s.txt}</span>
      <div class="qv-actions">
        <button class="btn btn-primary" data-action="add-cart" data-id="${p.id}" ${p.stock <= 0 ? 'disabled' : ''}>Add to cart</button>
        <a class="btn btn-outline" href="product.html?id=${p.id}">View details</a>
      </div>
    </div></div>`, { label: p.name + ' quick view', cls: 'modal-lg' });
}

/* ---------- Shop page ---------- */
App.init(() => {
  const grid = $('#shopGrid'); if (!grid) return;
  const P = params();
  const S = {
    q: P.q || '', cats: new Set(P.cat ? P.cat.split(',') : []), brands: new Set(P.brand ? P.brand.split(',') : []),
    min: 0, max: 20000, rating: 0, avail: '', colors: new Set(), sizes: new Set(), materials: new Set(), compat: new Set(), wp: false,
    sort: P.sort || 'featured', flag: P.filter || '', coll: P.collection || '', page: 1
  };
  const coll = COLLECTIONS.find(c => c.id === S.coll);
  if (coll) coll.cats.forEach(c => S.cats.add(c));
  $('#shopSearch').value = S.q; $('#sortSel').value = S.sort;

  const uniq = a => [...new Set(a)];
  const F = {
    colors: uniq(PRODUCTS.flatMap(p => p.colors)),
    sizes: uniq(PRODUCTS.flatMap(p => p.opts)),
    materials: uniq(PRODUCTS.map(p => p.material)).sort()
  };
  const facetChecks = (key, items, labelFn = x => x, countFn) => items.map(v => `<label class="check"><input type="checkbox" data-f="${key}" value="${esc(v)}"> <span>${esc(labelFn(v))}</span>${countFn ? `<em>${countFn(v)}</em>` : ''}</label>`).join('');
  const details = (t, body, open = true) => `<details class="facet" ${open ? 'open' : ''}><summary>${t}</summary><div class="facet-body">${body}</div></details>`;

  $('#filterBody').innerHTML =
    details('Category', facetChecks('cats', CATEGORIES.map(c => c.id), id => getCat(id).name, id => PRODUCTS.filter(p => p.cat === id).length)) +
    details('Brand', facetChecks('brands', BRANDS.map(b => b.id), id => getBrand(id).name, id => PRODUCTS.filter(p => p.brand === id).length)) +
    details('Price', `<div class="price-range"><label class="sr-only" for="pMin">Minimum price</label><input class="input" id="pMin" type="number" min="0" placeholder="Min" inputmode="numeric"><span>to</span><label class="sr-only" for="pMax">Maximum price</label><input class="input" id="pMax" type="number" min="0" placeholder="Max" inputmode="numeric"></div>`) +
    details('Rating', [['0', 'Any rating'], ['4', '4 stars and up'], ['3', '3 stars and up']].map(([v, t]) => `<label class="check"><input type="radio" name="rating" data-f="rating" value="${v}" ${v === '0' ? 'checked' : ''}> <span>${t}</span></label>`).join('')) +
    details('Availability', [['', 'All'], ['in', 'In stock'], ['out', 'Out of stock']].map(([v, t]) => `<label class="check"><input type="radio" name="avail" data-f="avail" value="${v}" ${v === '' ? 'checked' : ''}> <span>${t}</span></label>`).join('')) +
    details('Colour', `<div class="swatches">${F.colors.map(c => `<label class="swatch" title="${esc(c)}"><input type="checkbox" data-f="colors" value="${esc(c)}"><span style="background:${COLOR_HEX[c] || '#999'}"></span><span class="sr-only">${esc(c)}</span></label>`).join('')}</div>`, false) +
    details('Size or capacity', `<div class="chip-row">${F.sizes.map(v => `<label class="chip-check"><input type="checkbox" data-f="sizes" value="${esc(v)}"><span>${esc(v)}</span></label>`).join('')}</div>`, false) +
    details('Material', facetChecks('materials', F.materials), false) +
    details('Waterproof', `<label class="check"><input type="checkbox" data-f="wp"> <span>Waterproof only</span></label>`, false) +
    details('Compatibility', facetChecks('compat', COMPAT), false);

  const syncInputs = () => {
    $$('#filterBody input[data-f]').forEach(i => {
      const k = i.dataset.f;
      if (i.type === 'checkbox') i.checked = k === 'wp' ? S.wp : S[k].has(i.value);
    });
    $('#pMin').value = S.min || ''; $('#pMax').value = S.max < 20000 ? S.max : '';
  };

  const matchQ = (p, q) => {
    const hay = [p.name, p.sku, getBrand(p.brand).name, getCat(p.cat).name, p.tags.join(' ')].join(' ').toLowerCase();
    return q.toLowerCase().split(/\s+/).filter(Boolean).every(t => hay.includes(t));
  };
  const filtered = () => {
    let l = PRODUCTS.filter(p => p.active &&
      (!S.cats.size || S.cats.has(p.cat)) && (!S.brands.size || S.brands.has(p.brand)) &&
      p.price >= S.min && p.price <= S.max && p.rating >= S.rating &&
      (S.avail === '' || (S.avail === 'in' ? p.stock > 0 : p.stock <= 0)) &&
      (!S.colors.size || p.colors.some(c => S.colors.has(c))) && (!S.sizes.size || p.opts.some(c => S.sizes.has(c))) &&
      (!S.materials.size || S.materials.has(p.material)) && (!S.wp || p.waterproof) &&
      (!S.compat.size || p.compat.some(c => S.compat.has(c))) && (!S.q || matchQ(p, S.q)) &&
      (S.flag !== 'new' || p.isNew) && (S.flag !== 'best' || p.isBest) && (S.flag !== 'featured' || p.isFeatured) && (S.flag !== 'offers' || pct(p.mrp, p.price) >= 30));
    const sorts = {
      featured: (a, b) => (b.isFeatured - a.isFeatured) || (b.reviews - a.reviews),
      newest: (a, b) => b.created.localeCompare(a.created) || (b.isNew - a.isNew),
      'price-asc': (a, b) => a.price - b.price, 'price-desc': (a, b) => b.price - a.price,
      rating: (a, b) => b.rating - a.rating || b.reviews - a.reviews, selling: (a, b) => b.reviews - a.reviews
    };
    return l.sort(sorts[S.sort] || sorts.featured);
  };

  const chips = () => {
    const c = [];
    S.cats.forEach(v => c.push(['cats', v, getCat(v).name])); S.brands.forEach(v => c.push(['brands', v, getBrand(v).name]));
    S.colors.forEach(v => c.push(['colors', v, v])); S.sizes.forEach(v => c.push(['sizes', v, v])); S.materials.forEach(v => c.push(['materials', v, v])); S.compat.forEach(v => c.push(['compat', v, v]));
    if (S.min || S.max < 20000) c.push(['price', '', `${fmt(S.min)} to ${S.max < 20000 ? fmt(S.max) : 'any'}`]);
    if (S.rating) c.push(['rating', '', S.rating + ' stars and up']); if (S.avail) c.push(['avail', '', S.avail === 'in' ? 'In stock' : 'Out of stock']);
    if (S.wp) c.push(['wp', '', 'Waterproof']); if (S.q) c.push(['q', '', '"' + S.q + '"']);
    $('#activeChips').innerHTML = c.length ? c.map(([k, v, t]) => `<button class="chip is-active" data-rm="${k}" data-v="${esc(v)}">${esc(t)} ${icon('x', 14)}<span class="sr-only">Remove filter</span></button>`).join('') + '<button class="link-u" data-rm="all">Clear all</button>' : '';
  };

  const syncUrl = () => {
    const u = new URLSearchParams();
    if (S.q) u.set('q', S.q); if (S.cats.size && !coll) u.set('cat', [...S.cats].join(',')); if (S.brands.size) u.set('brand', [...S.brands].join(','));
    if (S.sort !== 'featured') u.set('sort', S.sort); if (S.flag) u.set('filter', S.flag); if (coll) u.set('collection', coll.id);
    history.replaceState(null, '', location.pathname + (u.toString() ? '?' + u : ''));
  };

  const titles = { new: ['New arrivals', 'The latest gear, just landed.'], best: ['Best sellers', 'What riders keep coming back for.'], offers: ['Offers', 'Products with 30% off or more.'], featured: ['Featured gear', 'Hand-picked by our team.'] };
  const render = () => {
    const list = filtered(), per = 12, pages = Math.max(1, Math.ceil(list.length / per));
    S.page = Math.min(S.page, pages);
    const [t, sub] = S.q ? ['Results for "' + S.q + '"', ''] : coll ? [coll.name, coll.desc] : titles[S.flag] || (S.cats.size === 1 ? [getCat([...S.cats][0]).name, getCat([...S.cats][0]).desc] : ['All gear', 'Everything you need for the road ahead.']);
    $('#shopTitle').textContent = t; $('#shopSub').textContent = sub; document.title = t + ' | ' + BRAND.name;
    $('#resultCount').innerHTML = `<b>${list.length}</b> ${list.length === 1 ? 'product' : 'products'}`;
    grid.innerHTML = list.length ? list.slice((S.page - 1) * per, S.page * per).map(productCard).join('') : `<div class="grid-span">${emptyState({ ico: 'search', title: 'No gear matched', text: 'Try removing a filter or searching for something broader, like "bag" or "helmet".', btn: 'Clear filters', href: 'shop.html' })}</div>`;
    $('#pager').innerHTML = pages > 1 ? Array.from({ length: pages }, (_, i) => `<button class="${i + 1 === S.page ? 'is-current' : ''}" data-page="${i + 1}" aria-label="Page ${i + 1}" ${i + 1 === S.page ? 'aria-current="page"' : ''}>${i + 1}</button>`).join('') : '';
    chips(); syncInputs(); syncStates(); syncUrl();
  };
  const refresh = (ms = 240) => { grid.innerHTML = skeletonCards(8); clearTimeout(refresh.t); refresh.t = setTimeout(render, ms); };

  $('#filters').addEventListener('change', e => {
    const i = e.target, k = i.dataset.f; if (!k) return; S.page = 1;
    if (k === 'rating') S.rating = +i.value; else if (k === 'avail') S.avail = i.value; else if (k === 'wp') S.wp = i.checked;
    else i.checked ? S[k].add(i.value) : S[k].delete(i.value);
    if (coll && k === 'cats') { S.coll = ''; }
    refresh();
  });
  const price = () => { S.min = +$('#pMin').value || 0; S.max = +$('#pMax').value || 20000; S.page = 1; refresh(); };
  $('#pMin').addEventListener('change', price); $('#pMax').addEventListener('change', price);
  $('#sortSel').addEventListener('change', e => { S.sort = e.target.value; S.page = 1; refresh(120); });
  $('#shopSearch').addEventListener('input', debounce(e => { S.q = e.target.value.trim(); S.page = 1; refresh(120); }, 300));
  $('#pager').addEventListener('click', e => { const b = e.target.closest('[data-page]'); if (!b) return; S.page = +b.dataset.page; render(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
  $('#activeChips').addEventListener('click', e => {
    const b = e.target.closest('[data-rm]'); if (!b) return; const k = b.dataset.rm, v = b.dataset.v;
    if (k === 'all') { location.href = 'shop.html'; return; }
    if (S[k] instanceof Set) S[k].delete(v); else if (k === 'price') { S.min = 0; S.max = 20000; } else if (k === 'rating') S.rating = 0; else if (k === 'avail') S.avail = ''; else if (k === 'wp') S.wp = false; else if (k === 'q') { S.q = ''; $('#shopSearch').value = ''; }
    refresh();
  });
  const drawer = on => { $('#filters').classList.toggle('is-open', on); $('#filterScrim').classList.toggle('is-on', on); document.body.classList.toggle('no-scroll', on); };
  $('#filterToggle').addEventListener('click', () => drawer(true));
  ['filterClose', 'filterApply'].forEach(id => $('#' + id).addEventListener('click', () => drawer(false)));
  $('#filterScrim').addEventListener('click', () => drawer(false));
  refresh(320);
});
