/* coupons.js — coupon application backed by the Cloud Function `validateCoupon`
   (spec §24: "Coupon validation must not rely only on frontend."). The local
   COUPONS object in cart.js still gives an instant preview/estimate, but the
   authoritative discount is whatever this function returns, and checkout.js
   re-validates again at order-creation time via createOrder. */

const CouponsAPI = {
  async validate(code, subtotal) {
    try {
      const validateCoupon = firebase.functions().httpsCallable('validateCoupon');
      const res = await validateCoupon({ code, subtotal });
      return res.data; // { ok, discount, label, message }
    } catch (e) {
      return { ok: false, message: e.message || 'Could not validate coupon right now.' };
    }
  }
};
