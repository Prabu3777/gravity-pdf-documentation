/* wishlist.js — wishlist store (guest = localStorage; logged-in = Firestore in the backend phase) + page */
const Wishlist = {
  KEY: 'at_wish',
  get() { return Store.get(Wishlist.KEY, []); },
  has(id) { return Wishlist.get().includes(id); },
  toggle(id) {
    let l = Wishlist.get();
    if (l.includes(id)) { l = l.filter(x => x !== id); toast('Removed from wishlist', 'info'); } else { l.push(id); toast('Added to wishlist'); }
    Store.set(Wishlist.KEY, l); emit('store:change');
  },
  remove(id) { Store.set(Wishlist.KEY, Wishlist.get().filter(x => x !== id)); emit('store:change'); }
};

function renderWishlist(el) {
  const l = Wishlist.get().map(getProduct).filter(Boolean);
  if (!l.length) { el.innerHTML = emptyState({ ico: 'heart', title: 'Save your favorite gear for your next ride.', text: 'Tap the heart on any product to keep it here.', btn: 'Browse gear', href: 'shop.html' }); return; }
  el.innerHTML = `<div class="grid-products">${l.map(p => productCard(p).replace('</article>', `<button class="link-u wish-rm" data-wrm="${p.id}">Remove from wishlist</button></article>`)).join('')}</div>`;
  syncStates();
}
App.init(() => {
  const el = $('#wishRoot'); if (!el) return;
  renderWishlist(el);
  el.addEventListener('click', e => {
    const r = e.target.closest('[data-wrm]'); if (r) { Wishlist.remove(r.dataset.wrm); renderWishlist(el); return; }
    const w = e.target.closest('[data-action="wish"]'); if (w) setTimeout(() => renderWishlist(el), 0);
  });
  const mv = $('#wishMoveAll');
  if (mv) mv.addEventListener('click', () => { let n = 0; Wishlist.get().forEach(id => { if (Cart.add(id, 1)) n++; }); toast(n + ' items moved to cart'); });
});
