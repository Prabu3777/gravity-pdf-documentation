/* firebase-db.js — Firestore reads/writes for catalog + storefront data.
   Load order on customer pages: utils.js, firebase-config.js, firebase-db.js,
   then data.js (kept only as a same-shape OFFLINE FALLBACK so pages still render
   if Firestore is unreachable), then the page's own script, then navbar.js/main.js.

   Pattern used everywhere below: fetch from Firestore, and on any error or an
   empty collection (Firestore not seeded yet) fall back to the local arrays from
   data.js so the UI never breaks. Run scripts/seed.js once against your project
   to replace the fallback with real data. */

const FirebaseDB = {
  _cache: {},

  async getProducts() {
    if (this._cache.products) return this._cache.products;
    try {
      const snap = await db.collection(COL.products).where('active', '==', true).get();
      if (snap.empty) throw new Error('empty');
      this._cache.products = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } catch (e) { this._cache.products = PRODUCTS; }
    return this._cache.products;
  },

  async getProduct(id) {
    try {
      const doc = await db.collection(COL.products).doc(id).get();
      if (!doc.exists) throw new Error('missing');
      return { id: doc.id, ...doc.data() };
    } catch (e) { return getProduct(id); }
  },

  async getCategories() {
    try {
      const snap = await db.collection(COL.categories).where('active', '==', true).orderBy('order').get();
      if (snap.empty) throw new Error('empty');
      return snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } catch (e) { return CATEGORIES; }
  },

  async getBrands() {
    try {
      const snap = await db.collection(COL.brands).where('active', '==', true).get();
      if (snap.empty) throw new Error('empty');
      return snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } catch (e) { return BRANDS; }
  },

  async getCollections() {
    try {
      const snap = await db.collection(COL.collections).get();
      if (snap.empty) throw new Error('empty');
      return snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } catch (e) { return COLLECTIONS; }
  },

  /* ---- Reviews (spec §16) ---- */
  async getReviews(productId) {
    try {
      const snap = await db.collection(COL.reviews).where('productId', '==', productId).where('status', '==', 'approved').orderBy('createdAt', 'desc').get();
      return snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } catch (e) { return REVIEWS.filter(r => r.product === productId); }
  },
  async submitReview(productId, { rating, title, text }) {
    const user = auth.currentUser;
    if (!user) throw new Error('Sign in to leave a review.');
    return db.collection(COL.reviews).add({
      productId, userId: user.uid, name: user.displayName || 'Rider', rating, title, text,
      status: 'pending', verified: false, createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  },

  /* ---- Q&A (spec §17) ---- */
  async getQuestions(productId) {
    const snap = await db.collection(COL.questions).where('productId', '==', productId).orderBy('createdAt', 'desc').get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  },
  async askQuestion(productId, text) {
    const user = auth.currentUser;
    if (!user) throw new Error('Sign in to ask a question.');
    return db.collection(COL.questions).add({
      productId, userId: user.uid, by: user.displayName || 'Rider', q: text, a: '',
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  },

  /* ---- Carts / wishlists synced to Firestore for logged-in users (spec §21, §23) ---- */
  async saveUserCart(uid, items) { return db.collection(COL.carts).doc(uid).set({ items, updatedAt: firebase.firestore.FieldValue.serverTimestamp() }); },
  async loadUserCart(uid) { const doc = await db.collection(COL.carts).doc(uid).get(); return doc.exists ? doc.data().items || [] : []; },
  async saveUserWishlist(uid, ids) { return db.collection(COL.wishlists).doc(uid).set({ ids, updatedAt: firebase.firestore.FieldValue.serverTimestamp() }); },
  async loadUserWishlist(uid) { const doc = await db.collection(COL.wishlists).doc(uid).get(); return doc.exists ? doc.data().ids || [] : []; },

  /* ---- Orders (spec §30) — creation always goes through the Cloud Function below,
     never written directly from the client, so price/stock/coupon get verified server-side. */
  async getUserOrders(uid) {
    const snap = await db.collection(COL.orders).where('userId', '==', uid).orderBy('createdAt', 'desc').get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  },
  async getOrder(orderId) {
    const doc = await db.collection(COL.orders).doc(orderId).get();
    return doc.exists ? { id: doc.id, ...doc.data() } : null;
  },

  /* ---- FAQs / pages / settings / banners for storefront chrome ---- */
  async getFaqs() {
    try { const snap = await db.collection(COL.faqs).where('active', '==', true).orderBy('order').get(); if (snap.empty) throw 0; return snap.docs.map(d => d.data()); }
    catch (e) { return FAQS; }
  },
  async getBanners() {
    const snap = await db.collection(COL.banners).where('active', '==', true).orderBy('order').get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  },
  async getSettings() {
    const doc = await db.collection(COL.settings).doc('store').get();
    return doc.exists ? doc.data() : null;
  },

  /* ---- Newsletter (spec §6, footer) ---- */
  async subscribeNewsletter(email) {
    return db.collection(COL.newsletterSubscribers).doc(email.toLowerCase()).set({ email, subscribedAt: firebase.firestore.FieldValue.serverTimestamp() });
  },

  /* ---- Support tickets (spec §50) ---- */
  async submitSupportTicket({ name, email, phone, subject, message }) {
    return db.collection(COL.supportTickets).add({ name, email, phone, subject, message, status: 'Open', createdAt: firebase.firestore.FieldValue.serverTimestamp() });
  }
};
