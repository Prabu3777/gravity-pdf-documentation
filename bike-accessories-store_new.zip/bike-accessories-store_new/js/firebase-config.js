/* firebase-config.js — Firebase SDK initialisation.
   Loaded via CDN compat scripts (no build step needed) on every page that needs
   Firebase: add these three <script> tags BEFORE this file, and this file BEFORE
   auth.js / firebase-db.js / any page script that touches Firebase:

   <script src="https://www.gstatic.com/firebasejs/10.13.0/firebase-app-compat.js"></script>
   <script src="https://www.gstatic.com/firebasejs/10.13.0/firebase-auth-compat.js"></script>
   <script src="https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore-compat.js"></script>
   <script src="https://www.gstatic.com/firebasejs/10.13.0/firebase-storage-compat.js"></script>
   <script src="https://www.gstatic.com/firebasejs/10.13.0/firebase-functions-compat.js"></script>
   <script src="https://www.gstatic.com/firebasejs/10.13.0/firebase-analytics-compat.js"></script>
   <script src="js/firebase-config.js"></script>

   Get these values from: Firebase Console → Project settings → General →
   "Your apps" → Web app → SDK setup and configuration. */
 const firebaseConfig = {
    apiKey: "AIzaSyBhcM4YVJ8_sFHNwKUkKslij_RqjFeaLjU",
    authDomain: "bike-11453.firebaseapp.com",
    projectId: "bike-11453",
    storageBucket: "bike-11453.firebasestorage.app",
    messagingSenderId: "1009167916273",
    appId: "1:1009167916273:web:bd8f399a586819bb725d50",
    measurementId: "G-E9FG1CKN23"
  };

/* Public-safe Razorpay key id (the secret key stays server-side only, in
   Cloud Functions config — see functions/index.js). Replace with your live
   or test key id from the Razorpay dashboard. */
const RAZORPAY_KEY_ID = 'rzp_test_REPLACE_WITH_YOUR_KEY_ID';

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();
const fx = firebase.functions();
/* Analytics only runs where the browser allows it (blocked by most ad/privacy
   blockers) and only over https/localhost — guarded so it never breaks the
   rest of the app if it fails to load. */
let analytics = null;
try { if (firebase.analytics && firebaseConfig.measurementId) analytics = firebase.analytics(); } catch (e) {}

/* Local emulator support for development. Set at_use_emulator=1 in localStorage
   (e.g. from the browser console) to point at `firebase emulators:start`. */
try {
  if (Store.get('at_use_emulator', false)) {
    auth.useEmulator('http://localhost:9099');
    db.useEmulator('localhost', 8080);
    storage.useEmulator('localhost', 9199);
  }
} catch (e) {}

/* Firestore collection name constants, used across js/*.js and js/admin/*.js
   so every module agrees on where data lives (matches section 54 of the spec). */
const COL = {
  users: 'users', products: 'products', categories: 'categories', brands: 'brands',
  collections: 'collections', carts: 'carts', wishlists: 'wishlists', orders: 'orders',
  payments: 'payments', coupons: 'coupons', reviews: 'reviews', questions: 'questions',
  inventoryTransactions: 'inventoryTransactions', banners: 'banners', notifications: 'notifications',
  faqs: 'faqs', supportTickets: 'supportTickets', newsletterSubscribers: 'newsletterSubscribers',
  settings: 'settings', pages: 'pages'
};
