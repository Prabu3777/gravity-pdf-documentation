/* storefront-sync.js — pulls live Firestore data into the SAME global arrays
   data.js already defines (PRODUCTS, CATEGORIES, BRANDS, COLLECTIONS, REVIEWS,
   FAQS). Every page script (products.js, product-details.js, search.js,
   compare.js, cart.js, wishlist.js…) reads those arrays directly and keeps no
   private copy, so mutating them in place (splice + push, never reassigning
   the `const`) updates everything that reads them afterwards — no changes
   needed to any of those files.

   Runs once per page load, right after firebase-config.js. Renders happen
   with the local seed data first (instant), then silently refresh once
   Firestore responds — if a page already drew the DOM before that finishes,
   it re-renders itself only where it already listens for 'catalog:sync'
   (see products.js/shop rendering hook below); everywhere else the refreshed
   data is simply correct on the next interaction (add to cart, open product,
   etc.) and definitely correct on the next page load. */

async function syncStorefrontCatalog() {
  if (typeof db === 'undefined') return;
  try {
    const [prodSnap, catSnap, brandSnap, collSnap, faqSnap, bannerSnap] = await Promise.all([
      db.collection('products').where('active', '==', true).get(),
      db.collection('categories').where('active', '==', true).get(),
      db.collection('brands').where('active', '==', true).get(),
      db.collection('collections').get(),
      db.collection('faqs').where('active', '==', true).orderBy('order').get(),
      db.collection('banners').where('active', '==', true).orderBy('order').get().catch(() => null)
    ]);

    if (!prodSnap.empty) { PRODUCTS.length = 0; prodSnap.forEach(d => PRODUCTS.push({ ...d.data(), id: d.id })); }
    if (!catSnap.empty) { CATEGORIES.length = 0; catSnap.forEach(d => CATEGORIES.push({ ...d.data(), id: d.id })); }
    if (!brandSnap.empty) { BRANDS.length = 0; brandSnap.forEach(d => BRANDS.push({ ...d.data(), id: d.id })); }
    if (!collSnap.empty) { COLLECTIONS.length = 0; collSnap.forEach(d => COLLECTIONS.push({ ...d.data(), id: d.id })); }
    if (!faqSnap.empty) { FAQS.length = 0; faqSnap.forEach(d => FAQS.push(d.data())); }
    if (bannerSnap && !bannerSnap.empty) { window.LIVE_BANNERS = bannerSnap.docs.map(d => ({ id: d.id, ...d.data() })); }

    emit('catalog:sync');
  } catch (err) { console.error('Storefront catalog sync failed — showing sample data.', err); }
}

const catalogSyncPromise = syncStorefrontCatalog();
