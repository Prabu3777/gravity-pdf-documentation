/* orders.js — order history and order details with status timeline (sample orders) */
function orderCalc(o) {
  const lines = o.items.map(([id, q, v]) => { const p = getProduct(id); return { p, q, v, total: p.price * q }; });
  const sub = lines.reduce((n, l) => n + l.total, 0), ship = sub >= FREE_SHIP ? 0 : SHIP_FEE, tax = Math.round(sub * GST / (100 + GST));
  return { lines, sub, ship, tax, total: sub + ship };
}
const statusClass = s => ({ Delivered: 'ok', Shipped: 'info', 'Out for Delivery': 'info', Confirmed: 'info', Packed: 'info', Pending: 'warn', Cancelled: 'danger', Returned: 'danger', Refunded: 'muted' }[s] || 'muted');

function orderRows() {
  return `<ul class="order-list">${ORDERS.map(o => { const c = orderCalc(o); return `<li class="order-card">
    <div class="order-head"><div><b>${o.id}</b><span class="muted">Placed ${o.date}</span></div><span class="badge badge-${statusClass(o.status)}">${o.status}</span><strong>${fmt(c.total)}</strong></div>
    <div class="order-thumbs">${c.lines.map(l => `<img src="${imgSrc(l.p)}" alt="${esc(l.p.name)}" width="64" height="64">`).join('')}<span class="muted">${c.lines.map(l => esc(l.p.name)).join(', ')}</span></div>
    <a class="btn btn-outline btn-sm" href="order-details.html?id=${o.id}">View details</a></li>`; }).join('')}</ul>`;
}
function drawOrders() {
  const list = $('#ordersList'); if (list) list.innerHTML = ORDERS.length ? orderRows() : emptyState({ ico: 'package', title: 'No orders yet', text: 'Your placed orders will show up here.', btn: 'Start shopping', href: 'shop.html' });
  const det = $('#orderDetail'); if (!det) return;
  const o = ORDERS.find(x => x.id === params().id) || ORDERS[0];
  if (!o) { det.innerHTML = emptyState({ ico: 'package', title: 'No orders yet', text: 'Place an order to see its details here.', btn: 'Start shopping', href: 'shop.html' }); return; }
  const c = orderCalc(o), idx = ORDER_FLOW.indexOf(o.status), a = o.address || ADDRESSES[0];
  const dates = ['20 Sep', '20 Sep', '21 Sep', '22 Sep', '24 Sep', '25 Sep'];
  det.innerHTML = `
    <div class="od-head"><div><h1>Order ${o.id}</h1><p class="muted">Placed ${o.date}</p></div><span class="badge badge-${statusClass(o.status)} lg">${o.status}</span></div>
    <ol class="timeline" aria-label="Order progress">${ORDER_FLOW.map((s, i) => `<li class="${i < idx ? 'is-done' : i === idx ? 'is-current' : ''}" ${i === idx ? 'aria-current="step"' : ''}><span class="dot">${i <= idx ? icon('check', 14) : ''}</span><b>${s}</b><small>${i <= idx ? dates[i] : 'Expected soon'}</small></li>`).join('')}</ol>
    <div class="od-grid">
      <section><h2>Items</h2><ul class="co-items lg">${c.lines.map(l => `<li><img src="${imgSrc(l.p)}" alt="" width="72" height="72"><span><b><a href="product.html?id=${l.p.id}">${esc(l.p.name)}</a></b><small>${l.v ? esc(l.v) + ', ' : ''}Qty ${l.q}, SKU ${l.p.sku}</small></span><strong>${fmt(l.total)}</strong></li>`).join('')}</ul>
        <div class="row">${o.status === 'Delivered' ? `<a class="btn btn-outline btn-sm" href="product.html?id=${c.lines[0].p.id}#pdpTabs">Write a review</a><button class="btn btn-outline btn-sm" data-demo-toast="Contact support to request a return.">Return items</button>` : `<button class="btn btn-outline btn-sm" data-demo-toast="Contact support to cancel this order.">Cancel order</button>`}<button class="btn btn-ghost btn-sm" data-demo-toast="Invoice download coming soon.">Download invoice</button></div></section>
      <aside class="od-side">
        <div class="box"><h3>Shipping address</h3><p>${esc(a.name || '')}<br>${esc(a.line || '')}${a.area ? ', ' + esc(a.area) : ''}<br>${esc(a.city || '')}, ${esc(a.state || '')} ${esc(a.pin || '')}<br>${esc(a.country || '')}</p></div>
        <div class="box"><h3>Payment</h3><p>${esc(o.method)}, <span class="ok">${esc(o.pay)}</span></p>${summaryRows({ count: c.lines.reduce((n, l) => n + l.q, 0), subtotal: c.sub, savings: 0, discount: 0, shipping: c.ship, tax: c.tax, total: c.total })}</div>
      </aside></div>`;
  det.addEventListener('click', e => { const b = e.target.closest('[data-demo-toast]'); if (b) toast(b.dataset.demoToast, 'info'); });
}
App.init(() => {
  if (!$('#ordersList') && !$('#orderDetail')) return;
  drawOrders();
  document.addEventListener('orders:sync', drawOrders);
});
