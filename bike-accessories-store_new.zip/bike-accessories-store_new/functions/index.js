/* functions/index.js — all server-side logic the spec requires to never live
   in frontend JS (spec §29, §56, §57, §58): Razorpay order creation + payment
   verification, admin role assignment via custom claims, coupon validation,
   and stock-safe order creation using a Firestore transaction.

   Setup:
     firebase functions:config:set razorpay.key_id="rzp_xxx" razorpay.key_secret="xxx"
     firebase deploy --only functions
   (Or, on newer CLI versions, use `firebase functions:secrets:set` instead of
   functions:config and read them via defineSecret — swap the two lines below
   marked CONFIG if your Firebase CLI version has deprecated functions:config.) */

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const Razorpay = require('razorpay');
const crypto = require('crypto');

admin.initializeApp();
const db = admin.firestore();

function razorpayClient() {
  const cfg = functions.config().razorpay || {}; // CONFIG
  return new Razorpay({ key_id: cfg.key_id, key_secret: cfg.key_secret });
}

function requireAuth(context) {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Sign in required.');
  return context.auth.uid;
}

async function requireAdmin(context) {
  if (!context.auth || context.auth.token.admin !== true) {
    throw new functions.https.HttpsError('permission-denied', 'Admin access required.');
  }
}

/* ---------------------------------------------------------------------- */
/* Admin role management — the ONLY way `admin: true` ever gets set.       */
/* First admin: deploy, then call this once from the Firebase console      */
/* Functions shell (or a temporary trusted script) rather than the app.    */
/* ---------------------------------------------------------------------- */
exports.setAdminClaim = functions.https.onCall(async (data, context) => {
  await requireAdmin(context);
  const { uid, admin: makeAdmin } = data;
  await admin.auth().setCustomUserClaims(uid, { admin: !!makeAdmin });
  await db.collection('users').doc(uid).set({ role: makeAdmin ? 'admin' : 'customer' }, { merge: true });
  return { ok: true };
});

/* ---------------------------------------------------------------------- */
/* Coupons (spec §24) — server is the source of truth, never the client.   */
/* ---------------------------------------------------------------------- */
exports.validateCoupon = functions.https.onCall(async (data) => {
  const code = (data.code || '').trim().toUpperCase();
  const subtotal = Number(data.subtotal) || 0;
  const doc = await db.collection('coupons').doc(code).get();
  if (!doc.exists) return { ok: false, message: 'That code is not valid.' };
  const c = doc.data();
  const now = Date.now();
  if (c.active === false) return { ok: false, message: 'This coupon is no longer active.' };
  if (c.startDate && now < c.startDate.toMillis()) return { ok: false, message: 'This coupon is not active yet.' };
  if (c.endDate && now > c.endDate.toMillis()) return { ok: false, message: 'This coupon has expired.' };
  if (c.usageLimit && (c.usedCount || 0) >= c.usageLimit) return { ok: false, message: 'This coupon has been fully redeemed.' };
  if (subtotal < (c.minOrder || 0)) return { ok: false, message: `Add ${c.minOrder - subtotal} more to use this code.` };
  const discount = c.type === 'percent'
    ? Math.min(Math.round(subtotal * c.value / 100), c.maxDiscount || Infinity)
    : c.value;
  return { ok: true, discount, label: c.label || code };
});

/* ---------------------------------------------------------------------- */
/* Order creation + Razorpay order (spec §29, §57) — runs in a transaction  */
/* so stock is checked and reserved atomically, preventing overselling.    */
/* ---------------------------------------------------------------------- */
exports.createRazorpayOrder = functions.https.onCall(async (data, context) => {
  const uid = requireAuth(context);
  const { items, address, couponCode } = data; // items: [{ productId, variant, qty }], address: { name, phone, email, line, area, city, state, pin, country }
  if (!Array.isArray(items) || !items.length) throw new functions.https.HttpsError('invalid-argument', 'Cart is empty.');

  const orderRef = db.collection('orders').doc();
  const total = await db.runTransaction(async (tx) => {
    let subtotal = 0;
    const snapshotItems = [];
    for (const it of items) {
      const pRef = db.collection('products').doc(it.productId);
      const pDoc = await tx.get(pRef);
      if (!pDoc.exists || pDoc.data().active === false) throw new functions.https.HttpsError('not-found', `Product ${it.productId} is unavailable.`);
      const p = pDoc.data();
      if ((p.stock || 0) < it.qty) throw new functions.https.HttpsError('failed-precondition', `${p.name} only has ${p.stock} left in stock.`);
      tx.update(pRef, { stock: admin.firestore.FieldValue.increment(-it.qty) });
      const lineTotal = p.sellingPrice * it.qty;
      subtotal += lineTotal;
      snapshotItems.push({ productId: it.productId, name: p.name, sku: p.sku, variant: it.variant || '', qty: it.qty, unitPrice: p.sellingPrice, discount: 0, total: lineTotal, image: (p.images && p.images[0]) || '' });
    }

    let discount = 0, appliedCoupon = null;
    if (couponCode) {
      const cRef = db.collection('coupons').doc(couponCode.toUpperCase());
      const cDoc = await tx.get(cRef);
      if (cDoc.exists && cDoc.data().active !== false && subtotal >= (cDoc.data().minOrder || 0)) {
        const c = cDoc.data();
        discount = c.type === 'percent' ? Math.min(Math.round(subtotal * c.value / 100), c.maxDiscount || Infinity) : c.value;
        appliedCoupon = couponCode.toUpperCase();
        tx.update(cRef, { usedCount: admin.firestore.FieldValue.increment(1) });
      }
    }

    const settingsDoc = await tx.get(db.collection('settings').doc('store'));
    const settings = settingsDoc.exists ? settingsDoc.data() : {};
    const afterDiscount = subtotal - discount;
    const shipping = afterDiscount >= (settings.freeShippingThreshold || 2999) ? 0 : (settings.shippingCharge || 149);
    const taxRate = settings.taxPercent || 18;
    const tax = Math.round(afterDiscount * taxRate / (100 + taxRate));
    const grandTotal = afterDiscount + shipping;

    tx.set(orderRef, {
      orderNumber: 'AT-' + Date.now().toString().slice(-8),
      userId: uid, items: snapshotItems, subtotal, discount, coupon: appliedCoupon, tax, shipping, total: grandTotal,
      paymentStatus: 'Pending', orderStatus: 'Pending', shippingAddress: address || {},
      createdAt: admin.firestore.FieldValue.serverTimestamp(), updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    return grandTotal;
  });

  const rpOrder = await razorpayClient().orders.create({
    amount: Math.round(total * 100), currency: 'INR', receipt: orderRef.id
  });
  await orderRef.update({ razorpayOrderId: rpOrder.id });
  return { orderId: orderRef.id, razorpayOrderId: rpOrder.id, amount: rpOrder.amount, currency: rpOrder.currency };
});

/* ---------------------------------------------------------------------- */
/* Payment verification (spec §29) — signature check happens ONLY here.    */
/* ---------------------------------------------------------------------- */
exports.verifyRazorpayPayment = functions.https.onCall(async (data, context) => {
  const uid = requireAuth(context);
  const { orderId, razorpay_order_id, razorpay_payment_id, razorpay_signature } = data;

  const cfg = functions.config().razorpay || {}; // CONFIG
  const expected = crypto.createHmac('sha256', cfg.key_secret).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
  if (expected !== razorpay_signature) {
    await db.collection('orders').doc(orderId).update({ paymentStatus: 'Failed', updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    throw new functions.https.HttpsError('permission-denied', 'Payment signature verification failed.');
  }

  const orderRef = db.collection('orders').doc(orderId);
  const orderDoc = await orderRef.get();
  if (!orderDoc.exists || orderDoc.data().userId !== uid) throw new functions.https.HttpsError('not-found', 'Order not found.');

  await orderRef.update({ paymentStatus: 'Paid', orderStatus: 'Confirmed', razorpayPaymentId: razorpay_payment_id, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  await db.collection('payments').add({
    orderId, userId: uid, razorpayOrderId: razorpay_order_id, razorpayPaymentId: razorpay_payment_id,
    amount: orderDoc.data().total, status: 'Paid', createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  return { ok: true };
});

/* ---------------------------------------------------------------------- */
/* Notifications (spec §51) — fire automatically on state changes.         */
/* ---------------------------------------------------------------------- */
exports.onOrderStatusChange = functions.firestore.document('orders/{orderId}').onUpdate(async (change) => {
  const before = change.before.data(), after = change.after.data();
  if (before.orderStatus === after.orderStatus && before.paymentStatus === after.paymentStatus) return null;
  const title = before.paymentStatus !== after.paymentStatus && after.paymentStatus === 'Paid' ? 'Payment successful' : `Order ${after.orderStatus}`;
  const body = `${after.orderNumber}: ${after.orderStatus}${after.paymentStatus === 'Paid' ? ', payment received' : ''}.`;
  return db.collection('notifications').doc(after.userId).collection('items').add({
    title, body, read: false, createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
});

exports.onLowStock = functions.firestore.document('products/{productId}').onUpdate(async (change) => {
  const before = change.before.data(), after = change.after.data();
  const threshold = after.lowStockThreshold || 5;
  if (after.stock > threshold || before.stock <= threshold) return null;
  const admins = await admin.auth().listUsers().then(r => r.users.filter(u => u.customClaims && u.customClaims.admin));
  const batch = db.batch();
  admins.forEach(u => {
    const ref = db.collection('notifications').doc(u.uid).collection('items').doc();
    batch.set(ref, { title: after.stock === 0 ? 'Out of stock' : 'Low stock', body: `${after.name} — ${after.stock} left.`, read: false, createdAt: admin.firestore.FieldValue.serverTimestamp() });
  });
  return batch.commit();
});
