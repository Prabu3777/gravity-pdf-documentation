/* scripts/seed.js — pushes realistic demo data into Firestore (spec §71:
   5 brands, 15 categories, 30 products with images/prices/discounts/stock/
   ratings/descriptions/specs/features), plus sample collections, reviews,
   FAQs and one store settings doc. Safe to re-run — it overwrites by id.

   Usage:
     cd scripts
     npm init -y && npm install firebase-admin
     # Download a service account key from Firebase Console → Project settings
     # → Service accounts → Generate new private key, save as service-account.json
     # next to this file (keep it out of git — it's a secret).
     node seed.js
*/
const admin = require('firebase-admin');
const serviceAccount = require('./service-account.json');

admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
const db = admin.firestore();

const BRANDS = [
  { id: 'ridgeback', name: 'Ridgeback', description: 'Touring luggage built in Pune', website: '', active: true },
  { id: 'kestrel', name: 'Kestrel Moto', description: 'Protective riding gear', website: '', active: true },
  { id: 'ironroute', name: 'IronRoute', description: 'Helmets, tools and electronics', website: '', active: true },
  { id: 'trailhawk', name: 'TrailHawk', description: 'Off-road and adventure kit', website: '', active: true },
  { id: 'nomadforge', name: 'Nomad Forge', description: 'Long-distance touring gear', website: '', active: true }
];

const CATEGORIES = [
  { id: 'helmets', name: 'Helmets', glyph: 'helmet', desc: 'Certified protection for every road.' },
  { id: 'gloves', name: 'Riding Gloves', glyph: 'glove', desc: 'Grip, comfort and knuckle armour.' },
  { id: 'jackets', name: 'Riding Jackets', glyph: 'jacket', desc: 'Armoured jackets for all seasons.' },
  { id: 'pants', name: 'Riding Pants', glyph: 'pants', desc: 'Breathable, armoured, hard-wearing.' },
  { id: 'boots', name: 'Riding Boots', glyph: 'boot', desc: 'Ankle support for long days.' },
  { id: 'saddle-bags', name: 'Saddle Bags', glyph: 'bag', desc: 'Waterproof side luggage.' },
  { id: 'tank-bags', name: 'Tank Bags', glyph: 'tank', desc: 'Quick-access magnetic storage.' },
  { id: 'tail-bags', name: 'Tail Bags', glyph: 'roll', desc: 'Big-capacity rear luggage.' },
  { id: 'backpacks', name: 'Backpacks', glyph: 'pack', desc: 'Rider-friendly day carriers.' },
  { id: 'phone-mounts', name: 'Phone Mounts', glyph: 'phone', desc: 'Mounts and USB chargers.' },
  { id: 'bike-lights', name: 'Bike Lights', glyph: 'light', desc: 'See further, be seen sooner.' },
  { id: 'rain-gear', name: 'Rain Gear', glyph: 'rain', desc: 'Stay dry when the sky opens up.' },
  { id: 'bike-covers', name: 'Bike Covers', glyph: 'cover', desc: 'Dust and weather protection.' },
  { id: 'tools', name: 'Tools', glyph: 'tool', desc: 'Roadside kits and repair gear.' },
  { id: 'touring', name: 'Touring Accessories', glyph: 'compass', desc: 'Straps, safety and travel gear.' }
];

const GROUPS = {
  helmets: ['S,M,L,XL', 'Size', 'Matte Black,Titanium,Crimson', 'ABS shell, EPS liner', '1.4 kg', '2 Years', 0, 'ISI and DOT certified shell|Anti-fog, Pinlock-ready visor|Quick-release ventilation|Removable, washable liner|Low-noise aerodynamic shape'],
  gloves: ['S,M,L,XL', 'Size', 'Black,Grey,Tan', 'Goat leather, mesh', '0.25 kg', '6 Months', 0, 'Knuckle and palm protection|Touchscreen-friendly fingertips|Pre-curved ergonomic fit|Reflective piping|Secure wrist closure'],
  jackets: ['S,M,L,XL,XXL', 'Size', 'Black,Olive,Grey', 'Cordura nylon, CE armour', '2.1 kg', '1 Year', 1, 'CE Level 2 shoulder and elbow armour|Removable thermal liner|Waterproof membrane|Reflective panels|Ventilation zips'],
  pants: ['30,32,34,36,38', 'Waist', 'Black,Olive,Grey', 'Cordura nylon, CE armour', '1.6 kg', '1 Year', 0, 'CE knee and hip armour|Adjustable waist and cuffs|Zippered thigh vents|Reinforced seat panel|Reflective details'],
  boots: ['UK 7,UK 8,UK 9,UK 10,UK 11', 'Size', 'Black,Tan', 'Full-grain leather, TPU', '1.7 kg', '1 Year', 1, 'Reinforced ankle and shin|Oil-resistant grip sole|Waterproof membrane|Quick-lace closure|Gear shift pad'],
  'saddle-bags': ['20L,30L,40L', 'Capacity', 'Black,Olive,Grey', '600D nylon, TPU coating', '1.2 kg', '1 Year', 1, 'Waterproof roll-top closure|UV resistant fabric|Reflective strip|Universal fit straps|Lightweight frame'],
  'tank-bags': ['10L,12L,20L', 'Capacity', 'Black,Grey', '600D nylon, TPU coating', '0.9 kg', '1 Year', 1, 'Strong magnetic base|Clear map pocket|Rain cover included|Shoulder strap|Quick-release buckle'],
  'tail-bags': ['30L,40L,50L', 'Capacity', 'Black,Olive', '840D nylon, TPU coating', '1.5 kg', '1 Year', 1, 'Roll-top waterproof closure|Compression straps|Reflective strip|Fits pillion seat|Removable shoulder strap'],
  backpacks: ['15L,25L,32L', 'Capacity', 'Black,Grey,Olive', '500D nylon, foam back panel', '1.0 kg', '1 Year', 0, 'Padded back and straps|Hydration-bladder sleeve|Helmet carry loop|Rain cover included|Chest and waist straps'],
  'phone-mounts': ['', '', 'Black,Silver', 'Aluminium, silicone', '0.2 kg', '1 Year', 0, 'Fits 4.7 to 7 inch phones|Vibration dampener|One-hand release|360 degree rotation|Universal handlebar clamp'],
  'bike-lights': ['', '', 'Black', 'Die-cast aluminium', '0.6 kg', '1 Year', 1, 'IP67 waterproof|Spot and flood modes|Easy wiring harness|Heat-dissipating body|Universal mounting brackets'],
  'rain-gear': ['M,L,XL,XXL', 'Size', 'Navy,Hi-Vis,Black', 'PU-coated nylon', '0.8 kg', '6 Months', 1, 'Fully seam-sealed|Packs into a small pouch|Reflective piping|Adjustable hood, cuffs and hem|Zip and storm flap'],
  'bike-covers': ['M,L,XL', 'Size', 'Grey,Black', 'Polyester, PU coating', '0.9 kg', '6 Months', 1, 'Water and dust proof|Lock-loop and wind straps|Elasticated hem|Heat-resistant exhaust patch|Carry pouch included'],
  tools: ['', '', 'Black', 'Chrome vanadium steel', '1.1 kg', '2 Years', 0, 'Hardened steel bits|Compact roll case|Fits most motorcycles|Tyre lever included|Corrosion resistant'],
  touring: ['', '', 'Black,Orange', 'Nylon, steel hooks', '0.4 kg', '6 Months', 0, 'High-strength construction|Reflective elements|Compact and light|Universal use|Easy stowing']
};

const RAW = [
  ['Voyager Modular Helmet', 'helmets', 'ironroute', 12999, 9499, 4.7, 312, 24, 'FB'],
  ['Ridgeline Full-Face Helmet', 'helmets', 'kestrel', 8999, 6799, 4.5, 208, 6, 'N'],
  ['Scout Dual-Sport Helmet', 'helmets', 'trailhawk', 10499, 7999, 4.6, 145, 0, ''],
  ['Summit Touring Gloves', 'gloves', 'kestrel', 3999, 2799, 4.6, 421, 40, 'B'],
  ['Ridge Mesh Riding Gloves', 'gloves', 'ironroute', 2499, 1699, 4.3, 176, 58, 'N'],
  ['Expedition Riding Jacket', 'jackets', 'ridgeback', 15999, 11999, 4.8, 264, 12, 'FB'],
  ['Urban Commuter Jacket', 'jackets', 'trailhawk', 8999, 6299, 4.4, 133, 3, ''],
  ['Trail Armoured Riding Pants', 'pants', 'ironroute', 9499, 6999, 4.5, 98, 15, ''],
  ['Cargo Touring Pants', 'pants', 'nomadforge', 7999, 5799, 4.4, 64, 22, 'N'],
  ['Grit Adventure Boots', 'boots', 'trailhawk', 11999, 8999, 4.7, 187, 9, 'F'],
  ['Roadster Short Boots', 'boots', 'kestrel', 6499, 4699, 4.2, 91, 30, ''],
  ['Adventure Waterproof Saddle Bag', 'saddle-bags', 'ridgeback', 3499, 2499, 4.8, 536, 45, 'FB'],
  ['Pannier Duo Set', 'saddle-bags', 'nomadforge', 8999, 6499, 4.6, 158, 14, ''],
  ['Magnetic Tank Bag', 'tank-bags', 'ridgeback', 2999, 2199, 4.5, 302, 33, 'B'],
  ['Tank Bag Pro', 'tank-bags', 'kestrel', 4499, 3299, 4.6, 120, 8, 'N'],
  ['Expedition Tail Bag', 'tail-bags', 'nomadforge', 5999, 4299, 4.7, 244, 19, 'FB'],
  ['Roll-Top Tail Bag', 'tail-bags', 'ridgeback', 4299, 3099, 4.4, 87, 26, ''],
  ['Summit Rider Backpack', 'backpacks', 'trailhawk', 4999, 3599, 4.5, 213, 28, ''],
  ['Hydra Hydration Pack', 'backpacks', 'ironroute', 3299, 2399, 4.3, 76, 4, 'N'],
  ['Grip Pro Phone Mount', 'phone-mounts', 'kestrel', 1999, 1299, 4.5, 689, 120, 'B'],
  ['Dual USB-C Bike Charger', 'phone-mounts', 'ironroute', 1499, 999, 4.4, 402, 85, 'N'],
  ['Beam X Auxiliary Light Pair', 'bike-lights', 'trailhawk', 3499, 2499, 4.6, 331, 37, 'F'],
  ['Halo LED Fog Lights', 'bike-lights', 'kestrel', 2999, 2099, 4.3, 118, 52, ''],
  ['Monsoon Rain Suit', 'rain-gear', 'ridgeback', 3999, 2799, 4.5, 275, 44, 'BF'],
  ['Storm Shield Boot Covers', 'rain-gear', 'nomadforge', 1299, 899, 4.2, 66, 60, ''],
  ['All-Weather Bike Cover', 'bike-covers', 'ironroute', 1999, 1399, 4.4, 154, 70, ''],
  ['Roadside Tool Kit 32-in-1', 'tools', 'ironroute', 2499, 1799, 4.6, 227, 41, 'N'],
  ['Tyre Repair and Inflator Kit', 'tools', 'kestrel', 2299, 1599, 4.5, 143, 5, ''],
  ['Ratchet Bungee Strap Set', 'touring', 'nomadforge', 999, 699, 4.7, 388, 150, 'B'],
  ['Reflective Safety Vest', 'touring', 'trailhawk', 899, 599, 4.3, 92, 75, 'N']
];

const COLLECTIONS = [
  { id: 'weekend-ride', name: 'Weekend ride', desc: 'Light kit for quick escapes.', cats: ['tank-bags', 'phone-mounts', 'gloves'], glyph: 'compass' },
  { id: 'long-distance', name: 'Long distance', desc: 'Comfort and cargo for big mileage.', cats: ['tail-bags', 'saddle-bags', 'jackets'], glyph: 'roll' },
  { id: 'adventure-touring', name: 'Adventure touring', desc: 'Built for the unpaved.', cats: ['boots', 'pants', 'touring'], glyph: 'boot' },
  { id: 'monsoon-ready', name: 'Monsoon ready', desc: 'Dry, visible and covered.', cats: ['rain-gear', 'bike-covers', 'bike-lights'], glyph: 'rain' },
  { id: 'daily-commute', name: 'Daily commute', desc: 'Everyday essentials.', cats: ['helmets', 'backpacks', 'phone-mounts'], glyph: 'pack' },
  { id: 'off-road', name: 'Off-road', desc: 'Protection and repair for the trail.', cats: ['helmets', 'boots', 'tools'], glyph: 'tool' }
];

const FAQS = [
  { q: 'How long does delivery take?', a: 'Most orders reach metro cities in 2 to 4 working days and the rest of India in 4 to 7 working days.', active: true, order: 1 },
  { q: 'Can I return an item?', a: 'Yes. Unused items in original packaging can be returned within 7 days of delivery. Helmets and innerwear are exchange-only for hygiene reasons.', active: true, order: 2 },
  { q: 'How do I know which size to pick?', a: 'Each product page lists its size guide. If you are between sizes, choose the larger one for jackets and the smaller one for helmets.', active: true, order: 3 },
  { q: 'Which payment methods do you accept?', a: 'UPI, credit and debit cards, net banking and popular wallets, processed securely by Razorpay.', active: true, order: 4 },
  { q: 'Do you offer warranty?', a: 'Most products carry a 6 month to 2 year manufacturer warranty. Check the specifications tab on the product page.', active: true, order: 5 },
  { q: 'How can I track my order?', a: 'Open Orders in your account to see a live timeline for every order, including courier tracking once it ships.', active: true, order: 6 }
];

function buildProducts() {
  return RAW.map((r, i) => {
    const [name, cat, brand, mrp, price, rating, reviews, stock, fl] = r;
    const g = GROUPS[cat], c = CATEGORIES.find(x => x.id === cat), n = i + 1;
    const opts = g[0] ? g[0].split(',') : [];
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const bname = BRANDS.find(b => b.id === brand).name;
    const waterproof = !!g[6] || /Waterproof|Rain/.test(name);
    const id = 'p' + String(n).padStart(2, '0');
    const created = '2026-' + String(9 - Math.floor((RAW.length - i) / 8)).padStart(2, '0') + '-' + String(1 + (i * 3) % 27).padStart(2, '0');
    return {
      id, slug, name, sku: 'AT-' + cat.slice(0, 3).toUpperCase() + '-' + (100 + n),
      // Fields the storefront (products.js, product-details.js, cart.js, main.js)
      // reads directly — MUST keep these exact names.
      cat, brand, mrp, price, rating, reviews, stock, low: 5, active: true, created,
      isFeatured: fl.includes('F'), isBest: fl.includes('B'), isNew: fl.includes('N'),
      optLabel: g[1], opts, colors: g[2] ? g[2].split(',') : [], material: g[3], weight: g[4], warranty: g[5],
      waterproof, compat: ['Universal'], features: g[7].split('|'),
      short: `${c.desc} By ${bname}.`,
      desc: [`${name} is engineered by ${bname} for riders who cover real distance, tested from monsoon highways to high-altitude passes.`, `Backed by a ${g[5].toLowerCase()} warranty and built to work with the rest of your ${bname} kit.`],
      tags: [cat, brand, ...(waterproof ? ['waterproof'] : []), ...(fl.includes('N') ? ['new'] : [])],
      images: [], variants: [],
      // spec §69 aliases, used by functions/index.js and admin/product-form.js
      brandId: brand, categoryId: cat, sellingPrice: price, discount: Math.round((1 - price / mrp) * 100), tax: 18,
      lowStockThreshold: 5, specifications: { Material: g[3], Weight: g[4], Warranty: g[5], Waterproof: waterproof ? 'Yes' : 'No', Mounting: 'Universal' },
      reviewCount: reviews, isBestSeller: fl.includes('B'), isNewArrival: fl.includes('N'),
      shortDescription: `${c.desc} By ${bname}.`,
      description: `${name} is engineered by ${bname} for riders who cover real distance, tested from monsoon highways to high-altitude passes. Backed by a ${g[5].toLowerCase()} warranty.`,
      createdAt: admin.firestore.FieldValue.serverTimestamp(), updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };
  });
}

async function run() {
  const batch = () => db.batch();
  let b = batch(), n = 0;
  const commitEvery = async () => { if (++n % 400 === 0) { await b.commit(); b = batch(); } };

  for (const brand of BRANDS) { b.set(db.collection('brands').doc(brand.id), brand); await commitEvery(); }
  for (const cat of CATEGORIES) { b.set(db.collection('categories').doc(cat.id), { ...cat, active: true, order: CATEGORIES.indexOf(cat) }); await commitEvery(); }
  for (const p of buildProducts()) { b.set(db.collection('products').doc(p.id), p); await commitEvery(); }
  for (const c of COLLECTIONS) { b.set(db.collection('collections').doc(c.id), c); await commitEvery(); }
  for (const f of FAQS) { b.set(db.collection('faqs').doc(), f); await commitEvery(); }

  b.set(db.collection('settings').doc('store'), {
    storeName: 'TN11 BIKERZZ', currency: 'INR', taxPercent: 18, shippingCharge: 149, freeShippingThreshold: 2999,
    email: 'hello@tn11bikerzz.com', phone: '+91 90000 00000'
  });

  await b.commit();
  console.log('Seed complete: 5 brands, 15 categories, 30 products, 6 collections, 6 FAQs, store settings.');
}

run().catch(err => { console.error(err); process.exit(1); });
