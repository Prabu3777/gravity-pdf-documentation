# Backend integration — what was added and how to deploy it

## Update 3: your project pinned, analytics added, admin double-logging bug fixed

- **`.firebaserc`** now points at your actual project (`bike-11453`), so
  `firebase deploy` etc. work immediately without an extra `firebase use --add`.
- **Analytics wired in** (`firebase-analytics-compat.js` + `firebase.analytics()`
  in `js/firebase-config.js`, guarded with try/catch so it never breaks
  anything if a blocker stops it from loading), matching the config you sent.
- **Found and fixed a double-logging bug**: adjusting stock from the
  Inventory screen was writing two stock-log entries for the same change
  (one from `AdminDB.products.save()`, one from `inventory.js` itself).
  Removed the automatic one and added an explicit, correctly-labelled entry
  to the full product editor (`product-form.js`) instead, so every stock
  change is logged exactly once with an accurate note either way.
- Re-checked every remaining admin module (categories, brands, collections,
  inventory, analytics) against the new Firestore-backed `AdminDB` — all
  clean, no other mismatches found.

### Still-known limitations (unchanged from before)
- Analytics dashboard's "today/this week" figures compare against hardcoded
  2026‑09 demo dates rather than the real current date — cosmetic only, the
  underlying revenue numbers themselves are correct.
- Customer order-history pricing recalculates from current product price
  rather than the price paid at checkout (admin order view already uses the
  correct historical price).
- Saved-address add/edit/remove is still the local sample list.

## Update 2: full storefront wired, real Razorpay checkout, live products

Your Firebase project config (`bike-11453`) was already in `js/firebase-config.js`
from your upload, so this pass wires the **entire customer-facing site** to
it, not just admin:

- **All 14 remaining customer pages** (home, shop, product, cart, checkout,
  wishlist, compare, account, orders, order details, about, contact, FAQ,
  404) now load the Firebase SDK + `firebase-db.js` + `auth.js` +
  `storefront-sync.js`, same pattern as login/register before.
- **`js/storefront-sync.js`** (new): pulls live products/categories/brands/
  collections/FAQs from Firestore into the exact same arrays `data.js`
  already defines, in place — so `products.js`, `product-details.js`,
  `search.js`, `compare.js`, `main.js` all show real Firestore data with
  zero changes to any of those files.
- **Found and fixed a real field-mismatch bug**: `scripts/seed.js` was
  writing products/categories/collections with the spec's field names
  (`sellingPrice`, `categoryId`, `isBestSeller`, `glyph`-less categories…)
  but the actual frontend code reads different, shorter names (`price`,
  `cat`, `isBest`, `glyph`, `opts`, `desc[]`, etc). Re-seeding now writes
  **both** sets of field names on every document, so the storefront renders
  correctly *and* the spec-named fields stay available for the Cloud
  Functions/admin. **Re-run `node scripts/seed.js` to pick up this fix** if
  you seeded before this update.
- **`imgSrc()` in `utils.js`** now shows a product's real uploaded photos
  (`p.images[]`, from the admin product editor → Firebase Storage) when
  present, falling back to the illustrated placeholder tile otherwise —
  previously uploaded images were never actually displayed anywhere.
- **Checkout is real now.** `checkout.js` calls `createRazorpayOrder`,
  opens the actual Razorpay Checkout widget (added to `checkout.html`),
  and calls `verifyRazorpayPayment` on success — stock, coupon and price are
  all re-checked server-side, matching spec §29/§57. Set your Razorpay test
  key id in `js/firebase-config.js` (`RAZORPAY_KEY_ID`) and your secret via
  `firebase functions:config:set razorpay.key_id=... razorpay.key_secret=...`.
- **Cart/wishlist now really sync**: `auth.js` merges a guest cart/wishlist
  into the account's Firestore copy on login (and now correctly writes the
  merged result back to this device's local storage too — the first version
  of this had a bug where the merge never became visible locally), and keeps
  pushing changes to Firestore in the background on every `store:change`.
- **Order history is real**: `js/orders-sync.js` (new) replaces the sample
  `ORDERS` data with the signed-in customer's actual Firestore orders,
  mapped into the same shape `orders.js` already renders.
- **Account page** now requires sign-in (redirects to `login.html`),
  shows the real signed-in name/email/phone, saves profile edits back to
  Firestore, and shows real notifications when there are any.
- **Contact form and newsletter signup** now write to Firestore
  (`supportTickets`, `newsletterSubscribers`) instead of just showing a
  toast.
- **Admin**: banners, static pages, and the homepage section order now sync
  to/from Firestore too (previously local-only). Support tickets submitted
  through the contact form now show up in the admin Support screen.

### Known limitation, left as-is given scope
Order line-item pricing on the customer order-history page is recalculated
from the *current* product price (`orderCalc()` in `js/orders.js`) rather
than the price actually paid at checkout — the real historical price is
already stored correctly in Firestore (`items[].unitPrice`) and used by the
admin order view; wiring the customer page to use it too is a small, same-
pattern follow-up if you want it. Saved-address management (add/edit/remove)
is still the local sample list — no Firestore-backed address book yet.

---

## Update 1: admin panel completed, links fixed, UI polished

**The big bug:** every admin page (`admin/*.html`) was loading its scripts from
the wrong path — `src="js/admin-auth.js"` etc, which resolves to
`admin/js/admin-auth.js` (doesn't exist), instead of `../js/admin/admin-auth.js`
(where the files actually are). So **no admin page was actually running its
JavaScript at all** before this fix — the sidebar, dashboard, product table,
everything, was silently broken. This is fixed across all 20 admin pages.

**AdminDB now talks to Firestore.** `js/admin/admin-data.js` still exposes the
exact same synchronous API every `admin/*.js` page already calls
(`AdminDB.products.all()`, `.save()`, `.remove()`, etc — zero changes needed to
any of those 20 page files), but now:
- On load it renders instantly from the local cache (fast, works offline),
  then fetches live data from Firestore in the background and updates the
  cache for the next page load.
- Every `save()`/`remove()` updates the cache immediately AND pushes the same
  write to Firestore, so changes persist and sync across admin sessions.
- Covered: products, categories, brands, collections, coupons, reviews, FAQs,
  orders (mapped from the real order/user documents the Cloud Functions
  create), customers (derived from `users` + their orders), and store
  settings. Banners, homepage section order, static pages, support tickets and
  the stock log are still local-only — same pattern, not yet wired.
- A small pill in the top bar shows **Synced** / **Cached data** / **Offline
  preview** so you can see at a glance whether a page is showing live
  Firestore data or the local fallback.

**Product image upload now really uploads.** `product-form.html`'s image
picker uploads straight to Firebase Storage (`products/{id}/images/…`) and
stores the resulting download URL — no more base64-only placeholder.

**Admin login** (`js/admin/admin-auth.js`) now keeps a small local session
cache so the sidebar/guard logic doesn't need to change, while re-verifying
the real Firebase ID token + `admin` claim in the background and signing out
if it's ever invalid.

**UI polish** in `css/admin.css`: sidebar links get a hover slide + glow on
the active item, stat cards lift with an accent top-bar on hover, the topbar
gets a blurred sticky background and a focus ring on search, and tables get a
shaded header row with a smoother row-hover transition.

---

The site you uploaded was a **complete frontend**: every page, the admin
panel screens, and all styling were done, but every data file openly said
*"SAMPLE DATA / DEMO ONLY — backend phase replaces this with Firestore"*.
This pass adds that backend layer.

## New files

| File | Purpose |
|---|---|
| `js/firebase-config.js` | Firebase SDK init — **put your project's config here** |
| `js/firebase-db.js` | Firestore reads/writes for products, categories, reviews, Q&A, carts, wishlists, orders, FAQs, support |
| `js/auth.js` | Real Firebase Authentication: register, login, Google login, password reset, guest→account cart/wishlist merge |
| `js/admin/admin-auth.js` (rewritten) | Real Firebase Auth + `admin` custom claim check, replacing the demo `admin123` login |
| `js/reviews.js` | Renders + submits reviews and Q&A on product.html |
| `js/coupons.js` | Calls the server-side `validateCoupon` function instead of trusting the frontend |
| `js/notifications.js` | Live notification bell via a Firestore listener |
| `functions/index.js` | Cloud Functions: Razorpay order creation + payment verification, admin claim assignment, coupon validation, stock-safe order creation (Firestore transaction), auto notifications on order status / low stock |
| `firestore.rules` | Security rules per spec §56 — customers can never write prices, stock, coupons, orders or their own role |
| `storage.rules` | Only admins can upload product/brand/category/banner images |
| `firestore.indexes.json` | Composite indexes the above queries need |
| `firebase.json` | Hosting + Firestore + Storage + Functions + emulator config |
| `scripts/seed.js` | Pushes the same 5 brands / 15 categories / 30 products / 6 collections / 6 FAQs into Firestore (spec §71) |

`login.html`, `register.html`, and `admin/login.html` are already wired to
these — use them as the pattern for the rest.

## Deploy steps

1. **Create a Firebase project** at console.firebase.google.com. Enable
   **Authentication** (Email/Password + Google), **Firestore**, **Storage**,
   and **Functions** (needs the Blaze plan — Functions require it).
2. Copy the web app config into `js/firebase-config.js` (replace the
   `REPLACE_WITH_...` placeholders).
3. Install the CLI and log in: `npm install -g firebase-tools && firebase login`,
   then `firebase use --add` and pick your project.
4. Set your Razorpay keys for Functions:
   `firebase functions:config:set razorpay.key_id="rzp_xxx" razorpay.key_secret="xxx"`
5. Deploy rules + functions:
   `firebase deploy --only firestore:rules,storage:rules,functions`
6. Seed the catalog: `cd scripts && npm install firebase-admin`, drop a
   downloaded service-account key in as `service-account.json`, `node seed.js`.
7. Make your own account the first admin: sign up once through
   `register.html`, then call `setAdminClaim` for that uid from the Firebase
   console's Functions shell (`firebase functions:shell`) — after that, use
   the admin panel itself to promote further admins.
8. `firebase deploy --only hosting` to publish the static site (or keep
   using it locally/on Claude's preview — Firebase Hosting is optional; any
   static host works since there's no build step).

## What still needs wiring (same pattern as login/register)

The remaining ~27 customer/admin pages still read/write `localStorage` via
`data.js` and `admin-data.js`. To finish connecting them:

- Add the four Firebase `<script>` tags + `firebase-config.js` + `firebase-db.js`
  (+ `auth.js` on customer pages) before each page's own script, exactly as
  in `login.html`.
- Swap direct references to `PRODUCTS` / `CATEGORIES` / etc. in `products.js`,
  `product-details.js`, `search.js`, `compare.js` for `await FirebaseDB.getProducts()`
  and friends — the function signatures are drop-in replacements.
- Replace `Cart`/`Wishlist`'s pure-`localStorage` reads with a check for
  `Auth.user`: if signed in, read/write through `FirebaseDB.loadUserCart` /
  `saveUserCart` instead of `Store`.
- Checkout (`checkout.js`) should call the `createRazorpayOrder` callable
  function, open Razorpay Checkout with the returned order, then call
  `verifyRazorpayPayment` on success — never write the order to Firestore
  directly from the browser.
- Every `admin/*.js` file's `AdminDB` calls become the matching
  `db.collection(...)` reads/writes shown in `firebase-db.js` — same shape,
  now with the admin-only rules in `firestore.rules` enforcing that a
  non-admin session can't touch them.

This is intentionally left as a repeatable, page-by-page swap rather than a
rewrite of all 27 files, since the data flow is identical every time.
